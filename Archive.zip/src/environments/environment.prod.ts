/* tslint:disable */
import { enableProdMode, NgModuleRef } from '@angular/core';
import { disableDebugTools } from '@angular/platform-browser';
import { Environment } from './model';

enableProdMode();

export const environment: Environment = {
  production: true,
  apiUrl: 'http://127.0.0.1:8402',
  showDevModule: false,

  RULE_URL: '/ace/rules',
  RULE_EXPORT_URL: '/ace/rules/export',
  REF_TABLE_URL: '/ace/table',
  GROUP_URL: '/ace/grouping',
  DATA_URL: '/ace/data',

  /* RULE_URL: 'http://127.0.0.1:8402/ace/rules',
  RULE_EXPORT_URL:  'http://127.0.0.1:8402/ace/rules/export',
  REF_TABLE_URL: 'http://127.0.0.1:8402/ace/table',
  GROUP_URL: 'http://127.0.0.1:8402/ace/grouping',
  DATA_URL: 'http://127.0.0.1:8402/ace/data',*/

  /** Angular debug tools in the dev console
   * https://github.com/angular/angular/blob/86405345b781a9dc2438c0fbe3e9409245647019/TOOLS_JS.md
   * @param modRef
   * @return {any}
   */
  decorateModuleRef(modRef: NgModuleRef<any>) {
    disableDebugTools();
    return modRef;
  },
  ENV_PROVIDERS: [

  ]
};
