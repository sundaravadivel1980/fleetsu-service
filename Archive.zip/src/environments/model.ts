import { NgModuleRef } from '@angular/core';

export interface Environment {
  production: boolean;
  apiUrl: string;
  RULE_URL: string;
  RULE_EXPORT_URL: string;
  REF_TABLE_URL: string;
  GROUP_URL: string;
  DATA_URL: string;
  ENV_PROVIDERS: any;
  showDevModule: boolean;
  decorateModuleRef(modRef: NgModuleRef<any>): NgModuleRef<any>;
}
