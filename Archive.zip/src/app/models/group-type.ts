
import { AutoCompleteChip } from '../models/ui-model';

export class GroupType {
    public static getGroups(typeName: string, groupTypes: any ) {
        let returnValues = [];
        if (groupTypes && groupTypes.length > 0) {
            groupTypes.forEach(groupType  => {
                if (groupType.name === typeName) {
                    returnValues =  groupType.groupings;
                }
            });
        }
        return returnValues;
    }

    public static getGroupList(typeName: string, groupTypes: any ) {
        return this.getGroups(typeName, groupTypes).map( item => {
            return { id: item.code, value: item.description
                // + ' (' + item['values'].map( val => { return val.code; }).join(',')  + ')'
            };
        });
    }
}
