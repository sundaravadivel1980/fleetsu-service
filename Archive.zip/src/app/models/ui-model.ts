
export class IdValue {
    public id: string;
    public value: string;
}

export class ComboBox extends IdValue {
    // empty
}

export class AutoCompleteChip extends IdValue {
   public displayText: string;
}
