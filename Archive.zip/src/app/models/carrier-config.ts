import { CarrierPreference, Values } from '@dxc/tr-ux-ace-services/dist/lib';
import { IdValue, ComboBox } from '../models/ui-model';
import { ClassRow } from 'src/app/models/rule-form.model';

export class CarrierConfig {

    public static getCarrierPreferenceValues(name: string, carrierPreferenceList: CarrierPreference[]) {
        let returnValues = [];
        if (carrierPreferenceList && carrierPreferenceList.length > 0) {
            carrierPreferenceList.forEach(carrierPreference => {
                if (carrierPreference.name === name) {
                    returnValues = carrierPreference.values;
                }
            });
        }
        return returnValues;
    }

    public static getCarrierPreferenceValue(name: string, carrierPreferenceList: CarrierPreference[]): string {
        let returnValue = null;
        if (carrierPreferenceList && carrierPreferenceList.length > 0) {
            carrierPreferenceList.forEach(carrierPreference => {
                if (carrierPreference.name === name) {
                    const returnValues = carrierPreference.values;
                    returnValue = returnValues[0].data[0];
                }
            });
        }
        return returnValue;
    }

    public static getCarrierPreference(name: string, carrierPreferenceList: CarrierPreference[]) {
        if (carrierPreferenceList && carrierPreferenceList.length > 0) {
            carrierPreferenceList.forEach(carrierPreference => {
                if (carrierPreference.name === name) {
                    return carrierPreference;
                }
            });
        }
    }

    public static getCabinList(name: string, carrierPreferenceList: CarrierPreference[]): IdValue[] {
        return this.getCarrierPreferenceValues(name, carrierPreferenceList).map(item => {
            return { id: item['data'][0], value: item['data'][1] };
        }) as IdValue[];
    }

    public static getBookingClassesList(name: string, carrierPreferenceList: CarrierPreference[]): ClassRow[] {
        return this.getCarrierPreferenceValues(name, carrierPreferenceList).map((item, index) => {
            return {
                id: index === 0 ? 'firstRow' : index === 1 ? 'secondRow' : index === 2 ? 'thirdRow' : 'fourthRow',
                value: item['data']
            };
        }) as ClassRow[];
    }

}
