import { Injectable } from '@angular/core';

import { HttpErrorResponse } from '@angular/common/http';

import { AutoCompleteChip } from 'src/app/models/ui-model';

import { TranslateService } from '@ngx-translate/core';
import {
  AirportsService, StartupService, AirlineRs, GroupingRs, CityAirportRs,
  TableStructureRs, TableStructure,
  CarrierPreferencesRs, CurrencyRs, CountryRs,
  CarrierPreference, Airline, CityAirport, Currency, Country,
  ReferenceTablesService, GroupingService
} from '@dxc/tr-ux-ace-services/dist/lib';

import { environment } from '../environments/environment';
import { CarrierConfig } from './models/carrier-config';
import { AppConstants, CarrierPrefConstants, TABLE_NAME } from './app.constants';
import { MessageTranslationService } from './services/message-translation.service';
import { AppUtil } from 'src/app/utility/app-util';

@Injectable()
export class AppSingletonService {
  public counter = 0;
  public ruleJsonStore: any;
  public airportJsonStore: any;
  public configJsonStore: any;
  public carrierDateFormat: string;
  public carrierCurrency: string;
  public marketSearchStore: any;
  public currentApp: string = 'Rule Engine';
  public groupTypes: any;
  public referenceTables: TableStructure [];
  public carrierPreferences: CarrierPreference[];
  public airlines: AutoCompleteChip [];
  public countires: AutoCompleteChip [];
  public currencies: AutoCompleteChip [];
  public airports: AutoCompleteChip [];
  public equipmentCodeList: AutoCompleteChip [];
  public equipmentConfigList: AutoCompleteChip [];
  public marketGroups: AutoCompleteChip [] = [];
  public locationGroups: AutoCompleteChip [] = [];
  public flightGroups: AutoCompleteChip [] = [];
  public carrierGroups: AutoCompleteChip [] = [];
  public posGroups: AutoCompleteChip [] = [];
  public businessIds: AutoCompleteChip [] = [];
  public userTypes: AutoCompleteChip [] = [];

  constructor(
    public translate: TranslateService,
    private startupService: StartupService,
    private airportsService: AirportsService,
    private refTable: ReferenceTablesService,
    private groupService: GroupingService,
    private messageService: MessageTranslationService) {
  }

  public loadAll() {
    this.loadCarrierPreferences();
    this.loadAirports();
    this.loadGroups();
    this.loadTables();
    this.loadAirlines();
    this.loadCountries();
    this.loadCurrencies();
    this.loadEquipmentData();
    this.loadBuisnessIdAndUserType();
  }

  public loadCarrierPreferences() {
    const carrierPreferenceURL = environment.DATA_URL + '/carrierPreferences';
    this.startupService.getCarrierPreferences(carrierPreferenceURL).subscribe(
      (response: CarrierPreferencesRs) => {
        this.carrierPreferences = response.carrierPreference;

        const dateFormatValues = CarrierConfig.getCarrierPreferenceValues(CarrierPrefConstants.DATE_FORMAT, response.carrierPreference);
        if (dateFormatValues[0]) {
          this.carrierDateFormat = dateFormatValues[0].data[0];
          const currencyValues = CarrierConfig.getCarrierPreferenceValues(CarrierPrefConstants.CURRENCY, response.carrierPreference);
          this.carrierCurrency = currencyValues[0].data[0];
        }

      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadAirports() {
    const airportsURL = environment.DATA_URL + '/cityAirport';
    this.startupService.getCityAirports(airportsURL).subscribe(
      (response: CityAirportRs) => {
        this.airports = this.getAiportsDropdownList(response.cityAirport);
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadAirlines() {
    const airlineURL = environment.DATA_URL + '/airline';
    this.startupService.getCarriers(airlineURL).subscribe(
      (response: AirlineRs) => {
        this.airlines = this.getAirlines(response.airline);
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadGroups() {
    const groupingURL = environment.GROUP_URL;
    this.groupService.getGroupsByStatusAndType(groupingURL, 'ACTIV', null).subscribe(
      (response: any) => {
        if (response.rsStandardPayload.success === true) {
          this.createGroupsAutoCompleteChips(response);
        } else {
          this.messageService.serviceError(environment.REF_TABLE_URL, response.rsStandardPayload);
        }
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadCurrencies() {
    const currencyURL = environment.DATA_URL + '/currency';
    this.startupService.getCurrencies(currencyURL).subscribe(
      (response: CurrencyRs) => {
        this.currencies = this.getCurrencyList(response.currency);
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadCountries() {
    const countryURL = environment.DATA_URL + '/country';
    this.startupService.getCountries(countryURL).subscribe(
      (response: CountryRs) => {
        this.countires = this.getCountryList(response.country);
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadTables() {
    const referenceTablesURL = environment.REF_TABLE_URL + '/structure';
    this.startupService.getReferenceTables(referenceTablesURL).subscribe(
      (response: TableStructureRs) => {
        this.referenceTables = response.tableStructure;
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadEquipmentData() {
    const listOfEquipCode = [];
    const listOfEquipConfig = [];
    const url = environment.REF_TABLE_URL;
    this.refTable.getTableByName(url, TABLE_NAME.EQUIPMENT).subscribe( // 13 is equipment table id
      (data) => {
        if (data.rsStandardPayload.success === true) {
          if (data['row']) {
            data['row'].forEach(
              row => {
                listOfEquipCode.push(
                  { id: row.column[0].toUpperCase(),
                    value: row.column[1],
                    displayText: row.column[1]
                  } as AutoCompleteChip);
                listOfEquipConfig.push(
                 { id: row.column[2].toUpperCase(),
                  value: row.column[3],
                  displayText: row.column[3]
                 } as AutoCompleteChip);
              }
            );
            this.equipmentCodeList = listOfEquipCode;
            this.equipmentConfigList = listOfEquipConfig;
        }
       } else {
          this.messageService.serviceError(environment.REF_TABLE_URL, data.rsStandardPayload);
       }
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public loadBuisnessIdAndUserType() {
    const businessIdArray = [];
    this.refTable.getTableByName(environment.REF_TABLE_URL, TABLE_NAME.BUSINESS_ID).subscribe(
      (response) => {
        if (response.rsStandardPayload.success === true) {
          if (response['row']) {
            response['row'].forEach(row => {
              businessIdArray.push(
                { id: row['column'][0].toUpperCase(), value: row['column'][1], displayText: row['column'][1]} as AutoCompleteChip
              );
            });
            this.businessIds = businessIdArray;
          }
        } else {
          this.messageService.serviceError(environment.REF_TABLE_URL, response.rsStandardPayload);
        }
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );

    const userTypeArray = [];
    this.refTable.getTableByName(environment.REF_TABLE_URL, TABLE_NAME.USER_TYPE).subscribe(
      (response) => {
        if (response.rsStandardPayload.success === true) {
          if (response['row']) {
            response['row'].forEach(row => {
              userTypeArray.push({ id: row['column'][0].toUpperCase(), value: row['column'][1], displayText: row['column'][1] } as AutoCompleteChip);
            });
            this.userTypes = userTypeArray;
          }
        } else {
          this.messageService.serviceError(environment.REF_TABLE_URL, response.rsStandardPayload);
        }
      },
      (error: HttpErrorResponse) => {
        this.messageService.httpError(error);
      }
    );
  }

  public isRequiredCondition(action: string, condition: string) {
    const requiredConditions = this.configJsonStore[action + '_default']['data'];
    const emptyArray = AppUtil.isEmptyArray(requiredConditions);
    if (!emptyArray && requiredConditions.join().indexOf(condition) !== -1) {
         return true;
    } else {
         return false;
    }
  }

  public getCombinedAirportsAndLocations() {
    if (this.locationGroups.length > 0) {
      return this.airports.concat(this.locationGroups) as AutoCompleteChip[];
    } else {
      return this.airports;
    }
  }

  public getCombinedCarrierAndCarrierGroups() {
    if (this.carrierGroups.length > 0) {
      return this.airlines.concat(this.carrierGroups) as AutoCompleteChip[];
    } else {
      return this.airlines;
    }
  }

  private getAirlines(airlinesList): AutoCompleteChip[] {
    const returnValue = [];
    for (const airline of airlinesList) {
        if (airline['carrier'] && airline['name']) {
            returnValue.push({ id: airline.carrier, value: airline.carrier + ' - ' + airline.name, displayText: airline.carrier});
        }
    }
    return returnValue as AutoCompleteChip[];
  }

  private getCountryList(countryList): AutoCompleteChip[] {
    // {addlTxt: "INCLUDES ST EUSTATIUS AND SABA ISLAND", code: "BQ", name: "BONAIRE"}//
      const returnValue = [];
      for (const country of countryList) {
          if (country['code'] && country['name']) {
              returnValue.push({ id: country.code, value: country.code + ' - ' + country.name, displayText: country.code });
          }
      }
      return returnValue as AutoCompleteChip[];
  }

  private getCurrencyList(currencyList): AutoCompleteChip[] {
      // {code: "ANG", countryCode: "CW", decimalPlaces: 0, name: "NETHERLANDS ANTILLIAN GUILDER"}
      const returnValue = [];
      for (const currency of currencyList) {
          if (currency['code'] && currency['name']) {
              returnValue.push({ id: currency.code, value: currency.code + ' - ' + currency.name, displayText: currency.code });
          }
      }
      return returnValue as AutoCompleteChip[];
  }

  private getAiportsDropdownList(airportsList): AutoCompleteChip[] {
    if (airportsList.length > 0) {
      // {airport: "ANGAMA", city: "MAASAI MARA", code: "ANA", country: "KENYA", timeZone: "KE1"}
      const airportList = airportsList.map(airport => {
        return { id: airport.code,
                 value: airport.code + ' - ' + airport.city + ' (' + airport.airport + ')' + ', ' + airport.country,
                 displayText: airport.code
              };
      });
      airportList.unshift({id: '***', value: 'All Airports'});
      return airportList as AutoCompleteChip[];
    }
  }

  private createGroupsAutoCompleteChips(response) {
    if (response['grouping'] && response['grouping'].length > 0) {
      response['grouping'].forEach(data => {
        if (data.type === 'MARKET') {
          this.marketGroups.push({ id: data.gid.toString(), value: data.name, displayText: data.name} as AutoCompleteChip);
        } else if (data.type === 'POS') {
          this.posGroups.push({ id: data.gid.toString(), value: data.name, displayText: data.name} as AutoCompleteChip);
        } else if (data.type === 'CARRIER') {
          this.carrierGroups.push({ id: data.gid.toString(), value: data.name, displayText: data.name} as AutoCompleteChip);
        } else if (data.type === 'FLIGHT') {
          this.flightGroups.push({ id: data.gid.toString(), value: data.name, displayText: data.name} as AutoCompleteChip);
        } else if (data.type === 'LOCATION') {
          this.locationGroups.push({ id: data.gid.toString(), value: data.name, displayText: data.name} as AutoCompleteChip);
        }
      });
    }
  }
}
