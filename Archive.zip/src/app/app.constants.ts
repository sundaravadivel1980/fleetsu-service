import { ComboBox } from 'src/app/models/ui-model';

export const AppConstants = {
    ACTION_CLASS_CLOSSURE: 'CLSCLO',
    ACTION_CLASS_SUPPRESSION: 'CLSSUP',
    ACTION_BID_PRICE_ADJ: 'BPRADJ',
    ACTION_BASE_FARE_ADJ: 'MKFRAJ',
    ACTION_AVAIL_ADJ: 'AVLADJ',
    ACTION_REMOVE_JOUNEY_USER: 'JOURNY',
    ACTION_PARTIAL_CANCELLATION: 'PARCAN',

    GROUP_TYPES: [
        { id: 'CARRIER', value: 'Airlines' },
        { id: 'LOCATION', value: 'Locations' },
        { id: 'MARKET', value: 'Markets' },
        { id: 'FLIGHT', value: 'Flights' },
        { id: 'POS', value: 'POS' },
    ] as ComboBox[]
};

export const ConditionConstants = {
    MARKET: 'MARKET',
    CLASSES:  'CLASSES',
    LOADFACTOR: 'LOADFACTOR',
    CARRIER: 'CARRIER',
    FLIGHT: 'FLIGHT',
    EQUIP: 'EQUIP',
    POC: 'POC',
    POS: 'POS' ,
    CONNPOINT: 'CONNPOINT',
    ROUTING:  'ROUTING',
    CLASSBKG: 'CLASSBKG',
    DEPTDATE: 'DEPTDATE',
    SELLDATE: 'SELLDATE',
    DEPTTIME: 'DEPTTIME',
    ARRTIME:  'ARRTIME',
    TIMEOUTDEPT: 'TIMEOUTDEPT',
    TIMETODEPT:  'TIMETODEPT' ,
    CLASSAVL: 'CLASSAVL'
};

/**
 * Mapping of condition object name in the schema and the condition constant.
 * Used to get the constant of the condition to verify the condition is a
 * carrrier preferred required or optional constant
 */
export const CONDITION_MAP = {
    marketCondition: 'MARKET',
    classCondition:  'CLASSES',
    loadFactorCondition: 'LOADFACTOR',
    carrierCondition: 'CARRIER',
    flightCondition: 'FLIGHT',
    equipmentCondition: 'EQUIP',
    pointOfCommencementCondition: 'POC',
    pointOfSaleCondition: 'POS' ,
    connectionPointCondition: 'CONNPOINT',
    routingCondition:  'ROUTING',
    classBookingCondition: 'CLASSBKG',
    departureDateCondition: 'DEPTDATE',
    sellingDateTimeCondition: 'SELLDATE',
    departureTimeCondition: 'DEPTTIME',
    arrivalTimeCondition:  'ARRTIME',
    timeOutsideDepartureCondition: 'TIMEOUTDEPT',
    timeToDepartureCondition:  'TIMETODEPT' ,
    classAvailabilityCondition: 'CLASSAVL'
};

export const CarrierPrefConstants = {
    PERCENTAGE_RESTRICTION: 'Percentage Restriction',
    AMOUNT_RESTRICTION: 'Amount Restriction',
    AMOUNT_DECIMAL_RESTRICTION: 'Decimal Restriction',
    SEATS_RESTRICTION: 'Seats Restriction',
    MAX_SEATS_RESTRICTION: 'Maximum Seats Restriction',
    MAX_SEATS_INCREASE_OR_DECREASE: 'Maximum Seats Increase or Decrease',
    NO_OF_CONNECTIONS_RESTRICTION: 'No Of Connections Restrictions',
    ANY_CONNECTION_POINTS_RESTRICTION: 'Any Connection Points Restriction',
    IN_SEQUENCE_CONNECTION_POINT_RESTRICTION: 'In Sequence Connection Point Restriction',
    CLASSES_SECTION_CLASSES: 'Class Classes',
    CLASS_AVAILABILITY_SECTION_CLASSES: 'Class Availability Classes',
    CLASS_BOOKING_SECTION_CLASSES: 'Class Booking Classes',
    DATE_FORMAT: 'GUI Date Format',
    CURRENCY: 'Currency',
    CABIN_TYPES: 'Cabin Types',
    MAX_POS_GROUP: 'Maximum POS Group',
    MAX_BUSI_ID: 'Maximum Business Id',
    MAX_AIRLINE_CODE: 'Maximum Airline Code',
    MAX_IATA_NUMBER: 'Maximum IATA Number',
    MAX_PSEUDO_CITY: 'Maximum Pseudo City',
    MAX_COUNTRY_CODE: 'Maximum Country Code',
    MAX_GEO_CITY: 'Maximum Geographical City',
    MAX_OA_CITY: 'Maximum OA City Code',
    MAX_ORIGINATING_SYSTEM: 'Maximum Originating System Code',
    MAX_CURRENCY_CODE: 'Maximum Currency Code',
    MAX_COMM_NUMBER: 'Maximum Communication Number',
    MAX_INHOUSE_CODE: 'Maximum InHouse Code',
    MAX_USER_TYPE: 'Maximum User Type'
};

export const DateConstants = {
    SUPPORTED_FORMATS: [
        {format: 'dd-mmm-yyyy', regex: /^(0?[1-9]|[12][0-9]|3[01])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{4}$/},
        {format: 'dd-mmm-yy', regex: /^(0?[1-9]|[12][0-9]|3[01])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{2}$/},
        {format: 'dd/mm/yyyy', regex: /^(0?[1-9]|[12][0-9]|3[01])[\/](0?[1-9]|1[012])[\/]\d{4}$/},
        {format: 'mm/dd/yyyy', regex: /^(0?[1-9]|1[012])[\/](0?[1-9]|[12][0-9]|3[01])[\/]\d{4}$/},
    ],
    DD_MMM_YYYY: 'dd-mmm-yyyy',
    DD_MMM_YY: 'dd-mmm-yy',
    DD_MM_YYYY: 'dd/mm/yyyy',
    MM_DD_YYYY: 'mm/dd/yyyy',
    REGEX_DD_MMM_YYYY: /^(0?[1-9]|[12][0-9]|3[01])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{4}$/,
    REGEX_DD_MMM_YY: /^(0?[1-9]|[12][0-9]|3[01])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{2}$/,
    REGEX_DD_MM_YYYY: /^(0?[1-9]|[12][0-9]|3[01])[\/](0?[1-9]|1[012])[\/]\d{4}$/,
    REGEX_MM_DD_YYYY: /^(0?[1-9]|1[012])[\/](0?[1-9]|[12][0-9]|3[01])[\/]\d{4}$/,
    APP_DATE_FORMATS: {
        parse: {
            dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
        },
        display: {
            dateInput: 'input',
            monthYearLabel: { year: 'numeric', month: 'numeric' },
            dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
            monthYearA11yLabel: { year: 'numeric', month: 'long' },
        }
    }
};

export const REGEX_CONSTANTS = {
    RANGE_999: /^[0-9]{0,3}-[0-9]{1,3}$/,
    RANGE_9999: /^[0-9]{0,4}-[0-9]{1,4}$/,
    NUMBER_999: /^[0-9]{0,3}$/,
    NUMBER_9999: /^[0-9]{0,4}$/,
    ALPHA_25: /^[a-zA-Z0-9]{0,25}$/,
    ALPHA_9: /^[a-zA-Z0-9]{0,9}$/,
    ALPHA_10_WILD: /^[a-zA-Z0-9*]{0,10}$/,
    IATA_NUMBER_8: /^[0-9]{8}$/,
    IATA_NUMBER_WILDCARD: /^[0-9*]{7,8}$/
};

export const TransactionType = {
    SELL: 'SELL',
    AVAIL: 'AVAIL',
    WAITLISTCLEARANCE: 'WAITLISTCLEARANCE',
    ALL: 'ALL'
};

export const RuleStatus = {
    ACTIVE: 'ACTIV',
    INACTIVE: 'INACT',
    SIMULATION: 'SIMUL'
};

export const GroupStatus = {
    ACTIVE: 'ACTIV',
    INACTIVE: 'INACT',
    SIMULATION: 'SIMUL',
    STATUSARRAY: [
        { id: 'ACTIV', value: 'Active' },
        { id: 'INACT', value: 'Inactive' },
        { id: 'SIMUL', value: 'Simulated' }
    ] as ComboBox[]
};

/**
 * Reference table name mapping
 */
export const TABLE_NAME = {
    USER_TYPE: 'User Type',
    BUSINESS_ID: 'Business ID',
    EQUIPMENT: 'Equipment',
    SWT: 'SWT',
    OPQ: 'OPQ',
    MAT: 'MAT',
    LNK: 'LNK',
    DOM: 'DOM',
    BCL: 'BCL',
    CARRIER_PREFERENCE: 'Carrier Preferences'
};

export const baseFareConstants = {
    adjustBookingClasses: [
        ['**'],
        ['F', 'A', 'O', 'FN', 'ON'],
        ['P', 'J', 'C', 'D', 'I', 'Z', 'R', 'PN', 'JN', 'IN', 'ZN', 'RN'],
        ['Y', 'B', 'M', 'E', 'U', 'H', 'Q', 'V', 'W', 'S', 'T', 'L', 'K', 'G', 'N', 'X', 'YN', 'HN', 'IN', 'ZN', 'XN']
      ],
      threeCabinFirstClassList: ['F', 'FN', 'A', 'O', 'ON'],
      threeCabinBusinessClassList: ['J', 'JN', 'C', 'D', 'Z', 'ZN', 'P', 'PN', 'R', 'RN', 'I', 'IN'],
      threeCabinEconClassList: ['Y', 'YN', 'B', 'M', 'E', 'U', 'H', 'HN', 'Q', 'V', 'W', 'S', 'T', 'L', 'K', 'S', 'N', 'X', 'XN'],
      weekList: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
      carrierMap: {
        '1A': 'Amadeus',
        '1B': 'Abacus International',
        '1F': 'Infinite Travel',
        '1G': 'Travelport Global',
        '1P': 'Worldspan',
        '1S': 'Sabre',
        '1V': 'Galileo International',
        'CM': 'COPA Airlines',
        'NW': 'NorthWest',
        'Q1': 'ITA (old)',
        'AM': 'Aero Mexico',
        'AZ': 'Alitalia',
        'UX': 'Air Europa',
        'KL': 'KLM Royal Dutch Airlines',
        'DL': 'Delta Airlines',
        '1E': 'TravelSky',
        'SU': 'AEROFLOT Russian Airlines',
        'KE': 'Korean Airlines',
        'UA': 'United Airlines',
        'F1': 'Farelogix',
        '0A': 'StarNet',
        '1U': 'ITA',
        'CA': 'Air China',
        '1J': 'AXESS International Network',
        'Z2': 'Flyaway',
        'WP': 'Island Air',
        'NH': 'ANA All Nippon Airways',
        'HA': 'Hawaiian Airlines',
        '9K': 'Cape Air',
        'SDN': 'SDN',
        'SHA': 'United'
    },
};
