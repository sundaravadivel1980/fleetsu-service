import { NativeDateAdapter } from '@angular/material';
import { AppSingletonService } from '../app-singleton.service';
import { Inject } from '@angular/core';
import { DateConstants } from '../app.constants';

export class DateFormat extends NativeDateAdapter {
    public useUtcForDisplay = true;
    constructor(@Inject(AppSingletonService) private appSingletonService: AppSingletonService) {
        super('en-us');
    }
    public parse(value: any): Date | null {
        if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
            const str = value.split('/');
            const year = Number(str[2]);
            if (this.appSingletonService.carrierDateFormat === DateConstants.DD_MM_YYYY) {
                const month = Number(str[1]) - 1;
                const date = Number(str[0]);
                return new Date(year, month, date);
            } else {
                const date = Number(str[1]);
                const month = Number(str[0]) - 1;
                return new Date(year, month, date);
            }
        }
        const timestamp = typeof value === 'number' ? value : Date.parse(value);
        return isNaN(timestamp) ? null : new Date(timestamp);
    }

    public validateDate(value, index, date, formArray, carrierPrefDate) {
        if (carrierPrefDate === DateConstants.DD_MMM_YYYY) {
            value = value.toLocaleLowerCase();
            if (!DateConstants.REGEX_DD_MMM_YYYY.test(value)) {
                formArray.controls[index].get(date)
                    .setErrors({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.dd-mmm-yyyy' });
            }
        } else if (carrierPrefDate === DateConstants.DD_MM_YYYY) {
            if (!DateConstants.REGEX_DD_MM_YYYY.test(value)) {
                formArray.controls[index].get(date)
                    .setErrors({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.dd/mm/yyyy' });
            }
        } else if (carrierPrefDate === DateConstants.MM_DD_YYYY) {
            if (!DateConstants.REGEX_MM_DD_YYYY.test(value.toLowerCase())) {
                formArray.controls[index].get(date)
                    .setErrors({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.mm/dd/yyyy' });
            }
        } else if (carrierPrefDate === DateConstants.DD_MMM_YY) {
            if (!DateConstants.REGEX_DD_MMM_YY.test(value.toLowerCase())) {
                formArray.controls[index].get(date)
                    .setErrors({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.dd-mmm-yy' });
            }
        } else {
            formArray.controls[index].get(date)
                    .setErrors({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.not.supported' });
        }

    }

    public format(date: Date, displayFormat: string): string {
        const day = date.getDate();
        const year = date.getFullYear();
        if (displayFormat === 'input') {
            if (this.appSingletonService.carrierDateFormat === DateConstants.DD_MMM_YYYY) {
                const month = super.getMonthNames('short')[date.getMonth()];
                return `${day}-${month}-${year}`;
            } else if (this.appSingletonService.carrierDateFormat === DateConstants.DD_MMM_YY) {
                const month = super.getMonthNames('short')[date.getMonth()];
                const formattedYear = year.toString().substr(2, 2);
                return `${day}-${month}-${formattedYear}`;
            } else if (this.appSingletonService.carrierDateFormat === DateConstants.DD_MM_YYYY) {
                const month = date.getMonth() + 1;
                return `${day}/${month}/${year}`;
            } else if (this.appSingletonService.carrierDateFormat === DateConstants.MM_DD_YYYY) {
                const month = date.getMonth() + 1;
                return `${month}/${day}/${year}`;
            }

        } else {
            const month = super.getMonthNames('short')[date.getMonth()];
            return `${month} ${year}`;
        }
    }
}
