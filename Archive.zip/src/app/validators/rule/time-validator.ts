import { ValidationErrors, FormGroup, Validator, Validators, AbstractControl } from '@angular/forms';
import { AppValidator } from 'src/app/validators/app-validator';
import { FormControlComparator } from 'src/app/validators/form-control-comparator';
import { start } from 'repl';
import { TimeComparator } from 'src/app/validators/time-comparator';

export class TimeValidator extends AppValidator {

    public constructor() {
        super();
    }

    // Start time minutes validation
    public validateStartTimeMinutes(formGroup: FormGroup): ValidationErrors | null {
        const comparator = new TimeComparator();
        const startHours = formGroup.parent ? formGroup.parent.get('startHours') : null;
        const endHours = formGroup.parent ? formGroup.parent.get('endHours') : null;
        const endMinutes = formGroup.parent ? formGroup.parent.get('endMinutes') : null;
        const startMinutes = formGroup;
        if (startMinutes.value > 60) {
            return super.error('acegui.rules.messages.time.minutes.validation');
        } else if (formGroup.parent) {
            // checks if the hours are equal and startminute is greater than end minutes
            if (comparator.equals(startHours, endHours) && comparator.compareTo(startMinutes, endMinutes) === 1) {
                return super.error('acegui.rules.messages.start.minute.valid');
            } else {
                // Nullify error based on condition since required is used
                if (endMinutes.getError('customError') && endMinutes.value < 60) {
                    endMinutes.setErrors(null);
                }
                if (startMinutes.getError('customError')) {
                    return null;
                }
            }
        }
    }

    // start time hours validation
    public validateStartTimeHours(formGroup: FormGroup): ValidationErrors | null {
        const comparator = new TimeComparator();
        const startHours = formGroup;
        const endHours = formGroup.parent ? formGroup.parent.get('endHours') : null;
        const endMinutes = formGroup.parent ? formGroup.parent.get('endMinutes') : null;
        const startMinutes = formGroup.parent ? formGroup.parent.get('startMinutes') : null;
        if (startHours.value > 24) {
            return super.error('acegui.rules.messages.time.hours.validation');
        } else if (formGroup.parent) {
            // condition satisfies if the start hours is less than end hours
            if (comparator.compareTo(startHours, endHours) === -1) {
                // Method null all the error fields if start date is less than end date
                comparator.nullifyError(formGroup);
            } else if (comparator.equals(startHours, endHours) &&
                !(comparator.isNullOrBlank(startMinutes) && comparator.isNullOrBlank(endMinutes))) {
                // Triggers minute field validation if the start date and end date is equal
                super.triggerFieldValidation(startMinutes);
                super.triggerFieldValidation(endMinutes);
                // condition satisfies if the start hours is greater than end hours
            } else if (comparator.compareTo(startHours, endHours) === 1) {
                return super.error('acegui.rules.messages.start.hour.valid');
            }
        }
    }

    // end time hours validation
    public validateEndTimeHours(formGroup: FormGroup) {
        const comparator = new TimeComparator();
        const startHours = formGroup.parent ? formGroup.parent.get('startHours') : null;
        const endHours = formGroup;
        const endMinutes = formGroup.parent ? formGroup.parent.get('endMinutes') : null;
        const startMinutes = formGroup.parent ? formGroup.parent.get('startMinutes') : null;
        if (endHours.value > 24) {
            return super.error('acegui.rules.messages.time.hours.validation');
        } else if (formGroup.parent) {
            // condition satisfies if the start hours is less than end hours
            if (comparator.compareTo(startHours, formGroup) === -1) {
                // Method null all the error fields if start date is less than end date
                comparator.nullifyError(formGroup);
            } else if (comparator.equals(startHours, endHours) &&
                !(comparator.isNullOrBlank(startMinutes) && comparator.isNullOrBlank(endMinutes))) {
                // Triggers minute field validation if the start date and end date is equal
                super.triggerFieldValidation(startMinutes);
                super.triggerFieldValidation(endMinutes);
                // condition satisfies if the start hours is greater than end hours
            } else if (comparator.compareTo(startHours, formGroup) === 1) {
                return super.error('acegui.rules.messages.end.hour.valid');
            }
        }
    }

    // end time minutes validation
    public validateEndTimeMinutes(formGroup: FormGroup) {
        const comparator = new TimeComparator();
        const startHours = formGroup.parent ? formGroup.parent.get('startHours') : null;
        const endHours = formGroup.parent ? formGroup.parent.get('endHours') : null;
        const endMinutes = formGroup;
        const startMinutes = formGroup.parent ? formGroup.parent.get('startMinutes') : null;
        if (endMinutes.value > 60) {
            return super.error('acegui.rules.messages.time.minutes.validation');
        } else if (formGroup.parent) {
            // checks if the hours are equal and startminute is greater than end minutes
            if (comparator.equals(startHours, endHours) && comparator.compareTo(startMinutes, endMinutes) === 1) {
                return super.error('acegui.rules.messages.end.minutes.valid');
            } else {
                // Nullify error based on condition since required is used
                if (startMinutes.getError('customError') && startMinutes.value < 60) {
                    startMinutes.setErrors(null);
                }
                if (endMinutes.getError('customError')) {
                    return null;
                }
            }
        }
    }

}
