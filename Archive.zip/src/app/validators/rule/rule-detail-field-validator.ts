import { AbstractControl, FormControl } from '@angular/forms/src/model';
import { AppSingletonService } from 'src/app/app-singleton.service';
import { Injectable } from '@angular/core';
import { AppValidator } from 'src/app/validators/app-validator';
import { REGEX_CONSTANTS, DateConstants } from 'src/app/app.constants';

/**
 * Common validations for rule detail page
 *
 */
export class RuleDetailFieldValidator extends AppValidator {

    constructor() {
        super();
    }

    /**
     * Validates the integer based on carrier preference. Will not accept decimals
     */
    public validateNumberRange(carrierPef: string) {
        if (carrierPef) {
            const startValue = carrierPef.split('-')[0];
            const endValue = carrierPef.split('-')[1];
            return (c: FormControl) => {
                if (c.value) {
                    const formValue = (c.value || c.value === 0) ? c.value.toString() : '';
                    if ((c.value < Number(startValue) || c.value > Number(endValue) // When the given value not in the range
                            || formValue % 1 !== 0) // when user given decimal
                            && formValue.length) {
                        return { patternErrors: true, errorMsg: 'Enter the value between ' + startValue + ' to ' + endValue };
                    }
                }
            };
        }
    }

    /**
     * Validates the routing connection count
     */
    public validateConnectionCount(carrierPrefRouting: string) {
        if (carrierPrefRouting) {
            return (c: FormControl) => {
                if (c.value) {
                    const maxValue = Math.max.apply(null, c.value.split(','));
                    if (maxValue > carrierPrefRouting) {
                        return { routingConnectError: true, routingErrorMsg: 'Enter upto ' + carrierPrefRouting  + ' connections'};
                    }
                }
            };
        }
    }

    /**
     * Validates the amount based on carrier preference
     *
     * @param amountCarrierPref
     * @param decimalCarrierPref
     */
    public validateAmount(amountCarrierPref: string, decimalCarrierPref: string) {
        if (amountCarrierPref) {
            const startValue = amountCarrierPref.split('-')[0];
            const endValue = amountCarrierPref.split('-')[1];

            // This anonymous function will be executed when user type something in the field
            return (c: FormControl) => {
                if (c.value) {
                    const amount = c.value.toString();
                    let integerValue = null;
                    let fractionalValue = null;

                    if (amount.indexOf('.') !== -1) {
                        integerValue = Number(amount.split('.')[0]);
                        fractionalValue = amount.split('.')[1];
                    } else {
                        integerValue = Number(amount);
                    }

                    let error = false;
                    if (integerValue < Number(startValue) || integerValue > Number(endValue)) {
                        // Return error if the integer value is greater than the preferred value
                        error = true;
                    }
                    if (decimalCarrierPref && (fractionalValue  && fractionalValue.length > Number(decimalCarrierPref))) {
                        error = true;
                    }

                    if (error) {
                        // Dislay the error 'Enter the value 0-99999 with upto 3 decimals' always.
                        // Single error message when interger value is not correct and/or fractional value is not correct
                        let errorMessage = 'Enter the value ' + amountCarrierPref;
                        if (decimalCarrierPref) {
                            errorMessage = errorMessage + ' with upto ' + decimalCarrierPref + ' decimals';
                        }
                        return {
                            patternErrors: true,
                            errorMsg: errorMessage
                        };
                    }
                }
            };
        }
    }

    public checkPercentage(c: FormControl) {
        const { parent, value } = c;
        if (parent) {
            const percentageValue = parent.get('numbers');
            if (!percentageValue.value && value) {
                super.triggerFieldValidation(percentageValue);
                percentageValue.setErrors({ percentageError: true, errorMsg: 'acegui.rules.messages.avail.adjust.max.error' });
            } else {
                percentageValue.setErrors(null);
            }
            if (!c.errors) {
                return null;
            }
        }
    }

    public validatePercentage(c: FormControl) {
        const { parent, value } = c;
        if (parent) {
            const maxIncreaseDecrease = parent.get('increaseSeats');
            if (!value && maxIncreaseDecrease.value) {
                return { percentageError: true, errorMsg: 'acegui.rules.messages.avail.adjust.max.error' };
            }
        }
    }

    public validateGSARange(c: FormControl) {
        if (c.value) {
            const { value } = c;
            const rangeRegex = REGEX_CONSTANTS.RANGE_999;
            // Checks if the value is in the range (1-999)
            if (!value.match(rangeRegex)) {
                return { patternErrors: true, errorMsg: 'Enter the value in range ex: 1-999' };
            }
            // Check if the start value is less than the end value
            if (value.match(rangeRegex)) {
                if (Number(value.split('-')[0]) > Number(value.split('-')[1]) || Number(value.split('-')[0]) === 0) {
                    return { patternErrors: true, errorMsg: 'acegui.rules.messages.start.end.gsa' };
                }
            }
        }
    }

    public validateGSANumber(c: FormControl) {
       // empty
    }

    public validateDate(carrierPrefDate: string) {
        console.log(DateConstants.SUPPORTED_FORMATS);
        return (c: FormControl) => {
            if (c.value) {
                let regEx = null;
                if (carrierPrefDate) {
                    for (const supportedFormat of DateConstants.SUPPORTED_FORMATS) {
                        if (supportedFormat.format === carrierPrefDate) {
                            regEx = supportedFormat.regex;
                        }
                    }
                }
                if (!regEx) {
                    return ({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.not.supported' });
                } else {
                    if (!regEx.test(c.value)) {
                        return ({ formatError: true, errorMsg: 'acegui.rules.messages.date.format.not.valid' });
                    }
                }
            }
        };
    }
}
