import { AbstractControl, FormGroup } from '@angular/forms';

export class FormControlComparator {

    constructor() {
        // empty
    }
    public equals(field1: AbstractControl, field2: AbstractControl) {
        const parsedValue1 = field1.value ? parseInt(field1.value, 10) : '';
        const parsedValue2 = field2.value ? parseInt(field2.value, 10) : '';
        if ((!parsedValue1 && parsedValue1 !== 0) || (!parsedValue2 && parsedValue2 !== 0)) {
            return false;
        }
        return parsedValue1 === parsedValue2;
    }

    public compareTo(field1: AbstractControl, field2: AbstractControl) {
        const parsedValue1 = field1.value ? parseInt(field1.value, 10) : '';
        const parsedValue2 = field2.value ? parseInt(field2.value, 10) : '';
        if ((!parsedValue1 && parsedValue1 !== 0) || (!parsedValue2 && parsedValue2 !== 0) ) {
            return false;
        }
        if (parsedValue1 > parsedValue2) {
            return 1;
        } else if (parsedValue1 < parsedValue2) {
            return -1;
        } else if (parsedValue1 === parsedValue2) {
            return 0;
        }
    }

    public isNullOrBlank(field: AbstractControl) {
        if (field && field.value) {
            return false;
        } else {
            return true;
        }
    }
}
