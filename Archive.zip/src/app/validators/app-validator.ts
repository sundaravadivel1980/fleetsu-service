import { ValidationErrors, FormGroup, Validator, Validators, AbstractControl } from '@angular/forms';

export class AppValidator {

    public constructor() {
        // empty
    }

    public triggerFieldValidation(absControl: AbstractControl) {
        absControl.markAsUntouched({ onlySelf: true });
        absControl.markAsDirty({ onlySelf: true });
        absControl.updateValueAndValidity();
    }

    public setRequired(absControl: AbstractControl) {
        absControl.setValidators([Validators.required]);
        absControl.markAsUntouched({ onlySelf: true });
        absControl.markAsDirty({ onlySelf: true });
        // absControl.setErrors({required: 'error.required.field'});
        absControl.updateValueAndValidity();
    }

    /**
     * To set the custom error for the field. If we any specific error constsant other than customError, create a separate method
     * @param key
     */
    protected error(key: string) {
        return {
            customError: key
        };
    }
}
