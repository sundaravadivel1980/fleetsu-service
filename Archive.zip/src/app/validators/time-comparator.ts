import { AbstractControl, FormGroup } from '@angular/forms';
import { FormControlComparator } from 'src/app/validators/form-control-comparator';

export class TimeComparator extends FormControlComparator  {

    public constructor() {
        super();
    }

    // Need to implement after creating formcontrol for time
    public compareTime(startTime: AbstractControl, endTime: AbstractControl) {
        // This method should expect all the four values. The method should return null if one of the value is not present
        // return 1 if the starttime is greater than end time

        if (this.isStartAndEndTimeExists(startTime, endTime)) {
            return null;
        }

        if (startTime.value > endTime.value) {
            // return 1
        } else if (startTime.value === endTime.value) {
            return 0;
        }
    }

    // Need to implement after creating formcontrol for time
    public  isStartAndEndTimeExists(startTime: AbstractControl, endTime: AbstractControl) {
        // Check the all the 4 values exists
    }

    // Need to implement after creating formcontrol for time
    public removeTimeFieldError(time: AbstractControl) {
        // nullfy the error
    }

    public nullifyError(formGroup: FormGroup) {
        const startHours = formGroup.parent ? formGroup.parent.get('startHours') : null;
        const endHours = formGroup.parent ? formGroup.parent.get('endHours') : null;
        const endMinutes = formGroup.parent ? formGroup.parent.get('endMinutes') : null;
        const startMinutes = formGroup.parent ? formGroup.parent.get('startMinutes') : null;
        if (endMinutes.getError('customError')) {
            endMinutes.setErrors(null);
        }
        if (startMinutes.getError('customError')) {
            startMinutes.setErrors(null);
        }
        if (endHours.getError('customError')) {
            endHours.setErrors(null);
        }
        if (startHours.getError('customError')) {
            startHours.setErrors(null);
        }
    }
}
