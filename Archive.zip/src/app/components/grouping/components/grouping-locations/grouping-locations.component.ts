import { Component, OnInit, Input } from '@angular/core';
import { AutoCompleteChip } from '../../../../models/ui-model';
import { FormGroup, FormControl, FormGroupDirective, FormControlDirective, FormArray, FormBuilder } from '@angular/forms';
import { GroupType } from '../../../../models/group-type';
import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { InitMethods } from '../../grouping-detail/grouping-detail-form-utils';

@Component({
    selector: 'grouping-locations',
    templateUrl: 'grouping-locations.component.html',
    styleUrls: ['grouping-locations.component.scss'],
})
export class GroupingLocationsComponent implements OnInit {
    @Input() public action: FormGroup;
    public listOfAirport: AutoCompleteChip[];
    public countryCodes: AutoCompleteChip[];

    constructor(private singletonService: AppSingletonService, private formbuilder: FormBuilder) {
    }
    public ngOnInit() {
        this.countryCodes = this.singletonService.countires;
        this.listOfAirport = this.singletonService.airports;
    }

    public addUnit(): void {
        const control = this.action.get('location') as FormArray;
        control.push(InitMethods.initLocationsUnit(this.formbuilder));
    }

    public removeUnit(i): void {
        const control = this.action.get('location') as FormArray;
        control.removeAt(i);
    }
}
