import { Component, OnInit, Input } from '@angular/core';
import { AutoCompleteChip } from '../../../../models/ui-model';
import { FormGroup, FormControl, FormGroupDirective, FormControlDirective, FormArray, FormBuilder } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { InitMethods } from '../../grouping-detail/grouping-detail-form-utils';

@Component({
    selector: 'grouping-flights',
    templateUrl: 'grouping-flights.component.html',
    styleUrls: ['grouping-flights.component.scss'],
})
export class GroupingFlightsComponent implements OnInit {
    @Input() public action: FormGroup;
    public airlinesList: AutoCompleteChip[];

    constructor(private singletonService: AppSingletonService, private formbuilder: FormBuilder) {
    }

    public ngOnInit() {
        this.airlinesList = this.singletonService.airports;
    }

    public addUnit(): void {
        const control = this.action.get('flight') as FormArray;
        control.push(InitMethods.initFlightsUnit(this.formbuilder));
    }

    public removeUnit(i): void {
        const control = this.action.get('flight') as FormArray;
        control.removeAt(i);
    }
}
