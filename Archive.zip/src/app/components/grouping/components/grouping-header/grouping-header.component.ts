import { Component, OnInit, Input } from '@angular/core';
import { ComboBox } from '../../../../models/ui-model';
import { FormGroup } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { GroupStatus, AppConstants } from 'src/app/app.constants';

@Component({
    selector: 'grouping-header',
    templateUrl: 'grouping-header.component.html',
    styleUrls: ['grouping-header.component.scss'],
})
export class GroupingHeaderComponent implements OnInit {
    @Input() public action: FormGroup;

    public types: ComboBox[];

    public statuses: ComboBox[];

    constructor(private singletonService: AppSingletonService) {
    }

    public ngOnInit() {
        this.statuses = GroupStatus.STATUSARRAY;
        this.types = AppConstants.GROUP_TYPES;
    }
}
