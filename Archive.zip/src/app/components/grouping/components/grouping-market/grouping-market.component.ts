import { Component, OnInit, Input } from '@angular/core';
import { AutoCompleteChip } from '../../../../models/ui-model';
import { FormGroup, FormControl, FormGroupDirective, FormControlDirective, FormBuilder, FormArray } from '@angular/forms';
import { GroupType } from '../../../../models/group-type';
import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { InitMethods } from '../../grouping-detail/grouping-detail-form-utils';

@Component({
    selector: 'grouping-market',
    templateUrl: 'grouping-market.component.html',
    styleUrls: ['grouping-market.component.scss'],
})
export class GroupingMarketComponent implements OnInit {
    @Input() public action: FormGroup;
    public listOfAirport: AutoCompleteChip[];

    constructor(private singletonService: AppSingletonService, private formbuilder: FormBuilder) {
    }

    public ngOnInit() {
        this.listOfAirport = this.singletonService.getCombinedAirportsAndLocations();
    }

    public addUnit(): void {
        const control = this.action.get('market') as FormArray;
        control.push(InitMethods.initMarketsUnit(this.formbuilder));
    }

    public removeUnit(i): void {
        const control = this.action.get('market') as FormArray;
        control.removeAt(i);
    }
}
