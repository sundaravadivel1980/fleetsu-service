import { Component, OnInit, Input } from '@angular/core';
import { AutoCompleteChip } from '../../../../models/ui-model';
import { FormGroup, FormControl, FormGroupDirective, FormControlDirective, FormArray, FormBuilder } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { GroupType } from '../../../../models/group-type';
import { InitMethods } from '../../grouping-detail/grouping-detail-form-utils';

@Component({
    selector: 'grouping-airlines',
    templateUrl: 'grouping-airlines.component.html',
    styleUrls: ['grouping-airlines.component.scss'],
})
export class GroupingAirlinesComponent implements OnInit {
    @Input() public action: FormGroup;
    public carriersList: AutoCompleteChip[];

    constructor(private singletonService: AppSingletonService, private formbuilder: FormBuilder) {
    }

    public ngOnInit() {
        const groupList = GroupType.getGroupList('Carrier Grouping', this.singletonService.groupTypes);
        const airlineList = this.singletonService.airlines;
        this.carriersList = groupList.concat(airlineList) as AutoCompleteChip[];
    }

    public addUnit(): void {
        const control = this.action.get('carrier') as FormArray;
        control.push(InitMethods.initAirlinesUnit(this.formbuilder));
    }

    public removeUnit(i): void {
        const control = this.action.get('carrier') as FormArray;
        control.removeAt(i);
    }
}
