import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Rule, PointOfSaleCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import { PointOfSaleComponentForm, PointOfSaleFormGroup, RuleDetailChildForm } from '../../../../models/rule-form.model';
import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from 'src/app/services/message-translation.service';
import { REGEX_CONSTANTS, CarrierPrefConstants } from 'src/app/app.constants';
import { InitMethods } from '../../grouping-detail/grouping-detail-form-utils';

@Component({
    selector: 'grouping-pos',
    templateUrl: 'grouping-pos.component.html',
    styleUrls: ['./grouping-pos.component.scss']
})

export class GroupingPosComponent implements OnInit {
    @Input() public action: FormGroup;
    public pointOfSaleGroup: FormGroup;
    public pointOfSaleComponentData: PointOfSaleCondition[];

    public operators: ComboBox[];

    /** POS Group Name */
    public groupName: AutoCompleteChip[];
    /** Business ID */
    public businessID: AutoCompleteChip[];
    /** Airline/GDS Code */
    public airlineGds: AutoCompleteChip[];
    /** Geographical City Code */
    public geographicalCode: AutoCompleteChip[];
    /** Country Code */
    public countryCode: AutoCompleteChip[];
    /** User type */
    public userType: AutoCompleteChip[];
    /** GDS/OA City Code */
    public iataCityCode: AutoCompleteChip[];
    /** Originating System */
    public airlineCode: AutoCompleteChip[];
    /** Currency Code */
    public currencyCode: AutoCompleteChip[];
    public posFields: string[];

    public isEmptyCondition: boolean = false;
    public hasErrors: boolean = false;

    public maxPosGroup: string;
    public maxBusinessID: string;
    public maxAirlineCode: string;
    public maxIataNumber: string;
    public maxUserType: string;
    public maxPseudoCity: string;
    public maxCountryCode: string;
    public maxGeoCity: string;
    public maxOACity: string;
    public maxOrigSys: string;
    public maxCurrencyCode: string;
    public maxCommNumber: string;
    public maxInHouseCode: string;

    constructor(private singletonService: AppSingletonService, private messageService: MessageTranslationService, private formbuilder: FormBuilder) {
        this.operators = singletonService.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        // Groupname, BusinessID, UserType data got from ref table date thru singleton
        this.groupName = this.singletonService.posGroups;
        this.businessID = this.singletonService.businessIds;
        this.userType = this.singletonService.userTypes;
        this.getCarrierPreferences();

        this.posFields = ['businessID', 'airlineGds', 'iataNumber', 'pseudoCode', 'geographicalCode',
            'countryCode', 'userType', 'iataCityCode', 'airlineCode', 'currencyCode', 'requestCode', 'communicationNumber',
            'inhouseID'];
    }

    public addUnit(): void {
        const control = this.action.get('pointOfSale') as FormArray;
        control.push(InitMethods.initPosUnit(this.formbuilder));
    }

    public removeUnit(i): void {
        const control = this.action.get('pointOfSale') as FormArray;
        control.removeAt(i);
    }

    private getCarrierPreferences() {
        this.maxPosGroup =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_POS_GROUP, this.singletonService.carrierPreferences);
        this.maxPosGroup = this.maxPosGroup ? this.maxPosGroup : '10';
        this.maxBusinessID =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_BUSI_ID, this.singletonService.carrierPreferences);
        this.maxBusinessID = this.maxBusinessID ? this.maxBusinessID : '100';
        this.maxAirlineCode =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_AIRLINE_CODE, this.singletonService.carrierPreferences);
        this.maxAirlineCode = this.maxAirlineCode ? this.maxAirlineCode : '100';
        this.maxIataNumber =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_IATA_NUMBER, this.singletonService.carrierPreferences);
        this.maxIataNumber = this.maxIataNumber ? this.maxIataNumber : '2000';
        this.maxPseudoCity =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_PSEUDO_CITY, this.singletonService.carrierPreferences);
        this.maxPseudoCity = this.maxPseudoCity ? this.maxPseudoCity : '100';
        this.maxCountryCode =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_COUNTRY_CODE, this.singletonService.carrierPreferences);
        this.maxCountryCode = this.maxCountryCode ? this.maxCountryCode : '100';
        this.maxGeoCity =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_GEO_CITY, this.singletonService.carrierPreferences);
        this.maxGeoCity = this.maxGeoCity ? this.maxGeoCity : '100';
        this.maxOACity =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_OA_CITY, this.singletonService.carrierPreferences);
        this.maxOACity = this.maxOACity ? this.maxOACity : '10';
        this.maxOrigSys =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_ORIGINATING_SYSTEM, this.singletonService.carrierPreferences);
        this.maxOrigSys = this.maxOrigSys ? this.maxOrigSys : '20';
        this.maxCurrencyCode =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_CURRENCY_CODE, this.singletonService.carrierPreferences);
        this.maxCurrencyCode = this.maxCurrencyCode ? this.maxCurrencyCode : '20';
        this.maxCommNumber =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_COMM_NUMBER, this.singletonService.carrierPreferences);
        this.maxCommNumber = this.maxCommNumber ? this.maxCommNumber : '10';
        this.maxInHouseCode =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_INHOUSE_CODE, this.singletonService.carrierPreferences);
        this.maxInHouseCode = this.maxInHouseCode ? this.maxInHouseCode : '20';
        this.maxUserType =
            CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_USER_TYPE, this.singletonService.carrierPreferences);
        this.maxUserType = this.maxUserType ? this.maxUserType : '5';
        this.countryCode = this.singletonService.countires;
        this.currencyCode = this.singletonService.currencies;

        // airlineGds (Airline/GDS), airlineCode (Originating system)
        const airlinesList = this.singletonService.airlines;
        this.airlineGds = airlinesList;
        this.airlineCode = airlinesList;
        // for geographicalCode (Geographical city code), iataCityCode (GDS/other airline city code)
        const airportList = this.singletonService.airports;
        this.geographicalCode = airportList;
        this.iataCityCode = airportList;
    }
}
