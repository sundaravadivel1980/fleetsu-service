import { NgModule } from '@angular/core';
import { DxcCoreModule } from '@dxc/tr-ux-ace-core/dist/lib';
// import { ServicesModule } from '@dxc/tr-ux-ace-services';

import { GroupingDirectoryComponent } from './grouping-directory/grouping-directory.component';
import { GroupingDetailComponent } from './grouping-detail/grouping-detail.component';
// import { GroupingService }          from '@dxc/tr-ux-ace-services';
import { GroupingRoutingModule } from './grouping-routing.module';

import { GroupingHeaderComponent } from './components/grouping-header/grouping-header.component';
import { GroupingAirlinesComponent } from './components/grouping-airlines/grouping-airlines.component';
import { GroupingPosComponent } from './components/grouping-pos/grouping-pos.component';
import { GroupingFlightsComponent } from './components/grouping-flights/grouping-flights.component';
import { GroupingLocationsComponent } from './components/grouping-locations/grouping-locations.component';
import { GroupingMarketComponent } from './components/grouping-market/grouping-market.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports:      [DxcCoreModule, TranslateModule, GroupingRoutingModule ],
  declarations: [ GroupingDetailComponent, GroupingDirectoryComponent, GroupingHeaderComponent,
  GroupingAirlinesComponent, GroupingPosComponent, GroupingFlightsComponent, GroupingLocationsComponent, GroupingMarketComponent ],
  providers:    []
})
export class GroupingModule {
  constructor() {
    console.log('Group Module');
  }
}
