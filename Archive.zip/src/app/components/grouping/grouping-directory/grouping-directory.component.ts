import { Component, ViewChild, AfterViewInit, OnInit, OnDestroy } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { RuleService, RuleRs, RuleSummary, Rule, RuleRq, GroupingRs, Grouping, GroupingService } from '@dxc/tr-ux-ace-services/dist/lib';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormControl, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Store } from '@ngrx/store';

import { environment } from '../../../../environments/environment';
import { AppConstants, GroupStatus } from '../../../app.constants';
import { ComboBox, AutoCompleteChip } from '../../../models/ui-model';
import { MessageTranslationService } from 'src/app/services/message-translation.service';
import { Group, GroupModel } from '../../../state-management/app-store.model';
import * as AppStoreActions from '../../../state-management/app-store.action';

@Component({
    templateUrl: 'grouping-directory.component.html',
    styleUrls: ['grouping-directory.component.scss']
})
export class GroupingDirectoryComponent implements OnInit, AfterViewInit, OnDestroy {

    public tableColumns = ['name', 'type', 'status', 'time', 'userId', 'action'];
    public statusList: ComboBox[];
    public groupType: any;
    public status: any;
    public filterGroupType: any;
    public groupTypes: ComboBox[];

    public dataSource: MatTableDataSource<Grouping> = new MatTableDataSource([]);
    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    constructor(
        private ruleService: RuleService,
        private fb: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private spinnerService: Ng4LoadingSpinnerService,
        private messageServiceAdapter: MessageTranslationService,
        private groupingService: GroupingService,
        private http: HttpClient,
        private appStore: Store<Group>) {
    }

    public ngOnInit(): void {
        this.loadAllGroups();
        this.statusList = GroupStatus.STATUSARRAY;
        this.groupTypes = AppConstants.GROUP_TYPES;
    }

    public ngAfterViewInit(): void {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    }

    public navigateNew() {
        const obj = { type: this.groupType, actionType: 'new' } as GroupModel;
        this.appStore.dispatch(new AppStoreActions.NewAction(obj));
        this.router.navigate(['/rule/groups/detail/0']);
    }

    public navigateEdit(groupId: string, groupGid: number, groupVersion: number, groupType: string, groupTime: string) {
        const obj: GroupModel = {
            actionType: 'edit',
            type: groupType,
            gid: groupGid,
            id: groupId,
            time: groupTime,
            version: groupVersion
        } as GroupModel;
        this.appStore.dispatch(new AppStoreActions.EditAction(obj));
        this.router.navigate(['/rule/groups/detail/0']);
    }

    public applyFilter(filterValue: string): void {
        filterValue = filterValue.trim(); // Remove whitespace
        filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
        this.dataSource.filter = filterValue;
    }

    public ngOnDestroy() {
        // console
    }

    private loadAllGroups() {
        this.spinnerService.show();
        const url = environment.GROUP_URL + '/directory';
        this.groupingService.groupingTable(url).subscribe(
            (groupRes: GroupingRs) => {
                this.spinnerService.hide();
                if (groupRes.rsStandardPayload.success) {
                    const rows = groupRes.grouping ? groupRes.grouping : [];
                    this.dataSource.data = rows;
                } else {
                    this.messageServiceAdapter.serviceError(url, groupRes.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }

    private filterGroups() {
        this.spinnerService.show();
        const url = '';
        this.groupingService.getGroupsByStatusAndType(url, this.groupType, this.status).subscribe(
            (groupRes: GroupingRs) => {
                this.spinnerService.hide();
                if (groupRes.rsStandardPayload.success) {
                    const rows = groupRes.grouping ? groupRes.grouping : [];
                    this.dataSource.data = rows;
                } else {
                    this.messageServiceAdapter.serviceError(url, groupRes.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }

    private deleteGroup(id, gid, time) {
        console.log(id, gid, time);
        this.spinnerService.show();
        const url = '';
        this.groupingService.deleteGroup(url).subscribe(
            (groupRes: GroupingRs) => {
                this.spinnerService.hide();
                if (groupRes.rsStandardPayload.success) {
                    this.messageServiceAdapter.success('Deleted Succcessfully..!');
                    this.loadAllGroups();
                } else {
                    this.messageServiceAdapter.serviceError(url, groupRes.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }
}
