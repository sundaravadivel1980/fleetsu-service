export class InitMethods {
    public static initAirlinesUnit(formbuilder) {
        return formbuilder.group({
            carrier: ''
        });
    }

    public static initFlightsUnit(formbuilder) {
        return formbuilder.group({
            flight: ''
        });
    }

    public static initMarketsUnit(formbuilder) {
        return formbuilder.group({
            origin: '',
            destination: ''
        });
    }

    public static initLocationsUnit(formbuilder) {
        return formbuilder.group({
            city: '',
            country: ''
        });
    }

    public static initPosUnit(formbuilder) {
        return formbuilder.group({
            operator: '',
            groupName: '',
            businessID: '',
            airlineGds: '',
            iataNumber: '',
            pseudoCode: '',
            geographicalCode: '',
            countryCode: '',
            userType: '',
            iataCityCode: '',
            airlineCode: '',
            currencyCode: '',
            requestCode: '',
            communicationNumber: '',
            inhouseID: '',
            label: ''
        });
    }
}
