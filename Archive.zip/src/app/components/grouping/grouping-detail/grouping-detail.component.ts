import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GroupingDetailParentComponent } from './grouping-detail-parent.component';
import { FormBuilder, FormGroup, Validators, FormGroupDirective, FormControlDirective, FormArray, FormControl } from '@angular/forms';
import { GroupingRs, Grouping, GroupingRq, GroupingDirectoryRs, GroupCarrier, GroupFlight, GroupingService } from '@dxc/tr-ux-ace-services/dist/lib';
import { Store } from '@ngrx/store';
import { Group, GroupModel } from '../../../state-management/app-store.model';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { MessageTranslationService } from '../../../services/message-translation.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppConstants } from 'src/app/app.constants';
import { environment } from 'src/environments/environment';

@Component({
  templateUrl: 'grouping-detail.component.html',
  styleUrls: ['grouping-detail.component.scss']
})

export class GroupingDetailComponent extends GroupingDetailParentComponent implements OnInit, OnDestroy {
  public id: number;
  public subscriptions: Subscription = new Subscription();
  public appStoreGroupData: GroupModel;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private groupService: GroupingService,
    private messageService: MessageTranslationService,
    private ng4SpinnerService: Ng4LoadingSpinnerService,
    private appStore: Store<Group>) {
    super(fb, router, groupService, messageService, ng4SpinnerService);
  }

  public ngOnInit() {
    this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
    this.subscriptions.add(
      this.appStore.select('group').subscribe(data => {
        this.appStoreGroupData = data as GroupModel;
        this.groupingType = data.type;
        this.intializeForm();
        if (this.appStoreGroupData.actionType === 'edit') {
          this.loadGroupDataForEdit(data);
        }
      })
    );
  }

  public saveAction() {
    this.ng4SpinnerService.show();
    // this.validateAllFormFields(this.groupingForm);
    const url =  environment.GROUP_URL;
    const body = this.getFormValues() as GroupingRq;
    if (this.appStoreGroupData.actionType === 'new') {
      this.createGroup(url, body);
    } else if (this.appStoreGroupData.actionType === 'edit') {
      body.grouping[0].gid = this.appStoreGroupData.gid;
      body.grouping[0].id = this.appStoreGroupData.id;
      body.grouping[0].time = this.appStoreGroupData.time;
      body.grouping[0].version = this.appStoreGroupData.version;
      this.updateGroup(url, body);
    }
    console.log(JSON.stringify(body as GroupingRq));
  }

  public createGroup(url, body) {
    this.groupService.createGroup(url, body).subscribe(
      (successRes: GroupingRs) => {
        this.ng4SpinnerService.hide();
        this.messageService.clear();
        if (successRes.rsStandardPayload.success) {
          this.messageService.success('Group saved successfully');
        } else {
          this.messageService.serviceError(url, successRes.rsStandardPayload);
        }
      },
      (errorRes) => {
        this.ng4SpinnerService.hide();
        this.messageService.httpError(errorRes);
      }
    );
  }

  public updateGroup(url, body) {
    this.groupService.updateGroup(url, body).subscribe(
      (successRes: GroupingRs) => {
        this.ng4SpinnerService.hide();
        this.messageService.clear();
        if (successRes.rsStandardPayload.success) {
          this.messageService.success('Group updated successfully');
        } else {
          this.messageService.serviceError(url, successRes.rsStandardPayload);
        }
      },
      (errorRes) => {
        this.ng4SpinnerService.hide();
        this.messageService.httpError(errorRes);
      }
    );
  }

  public loadGroupDataForEdit(data): void {
    this.ng4SpinnerService.show();
    const url = environment.GROUP_URL + '/' +  data.gid + '/' + data.version;
    this.groupService.getGroup(url).subscribe(
      (res: GroupingRs) => {
        this.ng4SpinnerService.hide();
        if (res.rsStandardPayload.success) {
          const grouping: Grouping[] = res.grouping;
          this.setFormValues(grouping);
        } else {
          this.messageService.serviceError(url, res.rsStandardPayload);
        }
      }
    );
  }

  public validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  public ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
