import { FormBuilder, FormArray, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageTranslationService } from '../../../services/message-translation.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import {
    GroupingRs, Grouping, GroupingRq, GroupingDirectoryRs, GroupCarrier, GroupFlight,
    FlightRange, POS, OriginDestination, GroupingService
} from '@dxc/tr-ux-ace-services/dist/lib';
import { InitMethods } from './grouping-detail-form-utils';
import { GroupStatus } from 'src/app/app.constants';

export class GroupingDetailParentComponent {
    public groupingForm: FormGroup;
    public groupingType: string;

    constructor(
        private formbuilder: FormBuilder,
        private routing: Router,
        private groupingService: GroupingService,
        private messageServiceAdapter: MessageTranslationService,
        private spinnerService: Ng4LoadingSpinnerService) {
        // empty
    }

    public intializeForm() {
        const formGroup = {};
        formGroup['header'] = this.formbuilder.group({ name: '', type: [{value: this.groupingType, disabled: true}],
        status: GroupStatus.INACTIVE, keyword: '' });

        switch (this.groupingType) {
            case null || undefined || '':
                this.routing.navigate(['/groups/directory']);
                return;
            case 'CARRIER':
                formGroup['carrier'] =  this.formbuilder.array([InitMethods.initAirlinesUnit(this.formbuilder)]);
                break;
            case 'FLIGHT':
                formGroup['flight'] =  this.formbuilder.array([InitMethods.initFlightsUnit(this.formbuilder)]);
                break;
            case 'LOCATION':
                formGroup['location'] =  this.formbuilder.array([InitMethods.initLocationsUnit(this.formbuilder)]);
                break;
            case 'MARKET':
                formGroup['market'] =  this.formbuilder.array([InitMethods.initMarketsUnit(this.formbuilder)]);
                break;
            case 'POS':
                formGroup['pointOfSale'] =  this.formbuilder.array([InitMethods.initPosUnit(this.formbuilder)]);
                break;
            default:
                break;
        }
        this.groupingForm = new FormGroup(formGroup);
    }

    public getFormValues(): GroupingRq {
        // To avoid reference Object deletion
        const form = this.filterEmptyNullUndefined(JSON.parse(JSON.stringify(this.groupingForm.value)));
        const grouping = Object.keys(form['header']).length > 0 ? form['header'] : {};
        switch (this.groupingType) {
            case 'FLIGHT':
                const flightRange: FlightRange[] = form['flight']['flight'].map((item) => {
                    if (item.toString().includes('-')) {
                        const numbers = item.split('-');
                        return { startFlight: numbers[0], endFlight: numbers[1] } as FlightRange;
                    } else {
                        return { startFlight: item } as FlightRange;
                    }
                });
                grouping['flight'] = { flight: flightRange } as GroupFlight;
                break;
            case 'CARRIER':
                const carrierValue = form['carrier'];
                if (Object.keys(carrierValue).length > 0) {
                    grouping['carrier'] = carrierValue;
                }
                break;
            case 'LOCATION':
                const locationValue = form['location'];
                if (Object.keys(locationValue).length > 0) {
                    grouping['location'] = locationValue;
                }
                break;
            case 'MARKET':
                const marketValue = form['market'];
                if (Object.keys(marketValue).length > 0) {
                    grouping['market'] = marketValue;
                }
                break;
            case 'POS':
                const posValue = form['pointOfSales'];
                if (Object.keys(posValue).length > 0) {
                    grouping['pointOfSale'] = posValue;
                }
                break;
            default:
                break;
        }
        const groupingRequest: GroupingRq = { grouping: [] } as GroupingRq;
        if (Object.keys(grouping).length > 0) {
            groupingRequest['grouping'].push(grouping);
        }
        return groupingRequest as GroupingRq;
    }

    public setFormValues(groupingData: Grouping[]) {
        console.log(groupingData);
        const headerValues = {
            name: groupingData[0].name,
            type: groupingData[0].type,
            status: groupingData[0].status,
            keyword: groupingData[0].keyword
        };
        this.groupingForm.get('header').patchValue(headerValues);
        switch (groupingData[0].type) {
            case 'CARRIER':
                this.groupingForm.get('carrier').patchValue(groupingData[0].carrier);
                break;
            case 'MARKET':
                this.groupingForm.get('market').patchValue(groupingData[0].market);
                break;
            case 'LOCATION':
                this.groupingForm.get('location').patchValue(groupingData[0].location);
                break;
            case 'FLIGHT':
                const flightsRange = { flight: [] };
                flightsRange.flight = groupingData[0].flight.flight.map(item => {
                    if (item.startFlight && item.endFlight) {
                        return item.startFlight + '-' + item.endFlight;
                    } else if (item.startFlight && !item.endFlight) {
                        return item.startFlight;
                    } else if (!item.startFlight && item.endFlight) {
                        return item.endFlight;
                    }
                });
                this.groupingForm.get('flight').patchValue(flightsRange);
                break;
            case 'POS':
                this.groupingForm.get('pointOfSale').patchValue(groupingData[0].pointOfSale);
                break;
        }
    }

    public filterEmptyNullUndefined(obj: object) {
        Object.keys(obj).forEach(prop => {
            if (obj[prop] === '' || obj[prop] === null || obj[prop] === undefined) {
                delete obj[prop];
            } else if (Array.isArray(obj[prop]) && obj[prop].length === 0) {
                delete obj[prop];
            } else if (typeof obj[prop] === 'object') {
                this.filterEmptyNullUndefined(obj[prop]);
            }
        });
        return obj;
    }
}
