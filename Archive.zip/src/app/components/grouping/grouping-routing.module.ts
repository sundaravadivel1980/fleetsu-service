import { NgModule } from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';

import { GroupingDirectoryComponent } from './grouping-directory/grouping-directory.component';
import { GroupingDetailComponent } from './grouping-detail/grouping-detail.component';

const routes: Routes = [
  { path: '', redirectTo: 'directory', pathMatch: 'full' },
  { path: 'directory', component: GroupingDirectoryComponent },
  { path: 'detail/:id', component: GroupingDetailComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GroupingRoutingModule { }
