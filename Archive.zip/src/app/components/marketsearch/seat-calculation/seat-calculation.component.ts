import { Component, OnInit } from '@angular/core';
import { AppSingletonService } from '../../app-singleton.service';
import { HttpClient } from '@angular/common/http';
import { BaseFareService } from '../../../services/market-search/base-fare.service';
import { SeatCalculationService } from '../../../services/market-search/seat-calculation.service';
import { MarketSearchParamsService } from '../../../services/market-search/marketsearch-params.service';

@Component({
    selector: 'seat-calculation',
    templateUrl: 'seat-calculation.component.html',
    styleUrls: ['./seat-calculation.component.scss']
})
export class SeatCalculationComponent implements OnInit {
    public responseData: any;
    public navTabs: any[];
    private response: any;
    private seatCabins: any;
    private seatArray: any;
    private selectedItems: number = 0;
    constructor(private http: HttpClient,
                private marketSearchParamsService: MarketSearchParamsService,
                private seatCalculationService: SeatCalculationService) {
        // em
    }

    public ngOnInit() {
        this.navTabs = [];
        this.seatCabins = {
            col1: [null, 'Y', 'YN', 'B', 'M', 'E', 'U', 'H', 'HN', 'Q', 'V', 'W', 'S', 'T', 'L', 'K', 'G', 'N', 'XN', 'X'],
            col2: ['F', 'FN', 'A', 'ON', 'O', null, 'J', 'JN', 'C', 'D', 'Z', 'ZN', 'P', 'PN', 'R', 'RN', 'IN', 'I']
        };
        this.responseData = this.marketSearchParamsService.seatCalculationParams.leftCabins;
        this.responseData = Object.keys(this.responseData).map((k) => this.responseData[k]);
        let rightData = this.marketSearchParamsService.seatCalculationParams.rightCabins;
        rightData = rightData ? Object.keys(rightData).map((k) => rightData[k]) : null;
        this.responseData.forEach((val, ind) => {
            this.navTabs.push({ Name: val.origin.toUpperCase() + ' > ' + val.destination.toUpperCase() });
            val.classSelected = 'Y';
            val.leftValue = this.seatCalculationService.getFilteredData(val.classitems, val.classSelected);
            if (rightData) {
                val.rightClassItems = rightData[ind].rightClassItems;
                val.rightValue = this.seatCalculationService.getFilteredData(val.rightClassItems, val.classSelected);
            }
        });
    }

    public selectedItem(args) {
        this.selectedItems = args.value;
    }
    public matTooltip(item) {
        const operator = item.basefareadjusted - item.basefare >= 0 ? '+' : '-';
        const valueee = ((item.basefareadjusted - item.basefare) >= 0 ? 1 : -1) * (item.basefareadjusted - item.basefare);
        const varrr = `${item.basefare} / Adjusted / ${operator} $${valueee}`;
        return varrr;
    }
    public cabinSelected(val, cab) {
        val.leftValue = this.seatCalculationService.getFilteredData(val.classitems, cab);
        val.classSelected = cab;
        if (val.rightValue) {
            val.rightValue = this.seatCalculationService.getFilteredData(val.rightClassItems, cab);
        }
    }
}
