import { NgModule } from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';

import { MarketSearchComponent } from './marketsearch.component';
import { FullMarketSearchComponent } from './full-market-search/full-market-search.component';
import { FullMarketComponent } from './full-market-search/full-market.component';
import { BaseFareComponent } from './base-fare/base-fare.component';
import { BidPriceComponent } from './bid-price/bid-price.component';

const routes: Routes = [
  {
    path: '',
    component: MarketSearchComponent,
    children: [
      { path: 'full-market', component: FullMarketComponent, pathMatch: 'full' },
      { path: 'bid-price', component: BidPriceComponent, pathMatch: 'full' },
      { path: 'base-fare', component: BaseFareComponent, pathMatch: 'full' },
      { path: 'custom-seam', component: FullMarketComponent, pathMatch: 'full' },
      { path: 'seamless-avail', component: FullMarketComponent, pathMatch: 'full' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MarketSearchRoutingModule { }
