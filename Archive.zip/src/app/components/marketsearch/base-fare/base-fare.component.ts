
import { Component, OnInit } from '@angular/core';
import { AppSingletonService } from '../../app-singleton.service';
import { HttpClient } from '@angular/common/http';
import { MarketSearchParamsService } from '../../../services/market-search/marketsearch-params.service';

@Component({
    selector: 'base-fare',
    templateUrl: 'base-fare.component.html',
    styleUrls: ['./base-fare.component.scss']
})
export class BaseFareComponent implements OnInit {
    public baseFareData: any = null;
    public selectedCabinvalue: string;
    constructor(private marketSearchParamsService: MarketSearchParamsService) {
        // console
    }
    public ngOnInit() {
        this.baseFareData = this.marketSearchParamsService.baseFareParams;
    }

    private selectedCabin(args) {
        this.selectedCabinvalue = args;
    }
}
