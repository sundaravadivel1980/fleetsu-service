import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { AppSingletonService } from '../../../app-singleton.service';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { AppConstants } from '../../../app.constants';
import { MarketSearchParams } from '../../../services/market-search/marketsearch-params.model';
import { FullMarketService } from '../../../services/market-search/full-market.service';
import { MarketSearchParamsService } from '../../../services/market-search/marketsearch-params.service';

@Component({
  selector: 'full-market-search',
  templateUrl: './full-market-search.component.html',
  styleUrls: ['./full-market-search.component.scss']
})

export class FullMarketSearchComponent implements OnInit {
  @Input() public valueChanged: number = 0;
  @Output('selectedFlight') public selectedFlight = new EventEmitter();
  public compareFlights: MarketSearchParams;
  private parms: MarketSearchParams;
  private selectedItem: number = 0;
  private subscription: ISubscription;
  constructor(protected msParamsService: MarketSearchParamsService,
              protected router: Router,
              protected singletonService: AppSingletonService,
              protected messageService: MessageService,
              private fmService: FullMarketService) {
  }
  /*
   * Angular lifecycle method, used to get/populate the value for new/edit rule
  */
  public ngOnInit() {
    this.parms = this.msParamsService.params;
    if (!this.parms) {
      this.router.navigate(['/marketsearch']);
      return;
    }
    this.compareFlights = this.msParamsService.params;
  }

  public onFlightSort() {
    // this.avlData.flightList.sort((a, b) => {
    //   if ((a.flight[0].marketingAirlineCode + a.flight[0].flightNumber) < (b.flight[0].marketingAirlineCode + a.flight[0].flightNumber)) {
    //     return -1;
    //   }
    //   if ((a.flight[0].marketingAirlineCode + a.flight[0].flightNumber) > (b.flight[0].marketingAirlineCode + a.flight[0].flightNumber)) {
    //     return 1;
    //   }
    //   return 0;
    // });
  }

  private onRowSelect(index, flightItems) {
    this.selectedFlight.emit({value: flightItems});
    this.selectedItem = index;
  }

}
