import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { AppSingletonService } from '../../../app-singleton.service';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { AppConstants } from '../../../app.constants';
import { MarketSearchParams, NavigationTabs, Reports } from '../../../services/market-search/marketsearch-params.model';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FullMarketService } from '../../../services/market-search/full-market.service';
import { BaseFareService } from '../../../services/market-search/base-fare.service';
import { SeatComputationRes, BidPriceRes, BaseFareRes, AllReportsRes } from '../../../services/market-search/market-model';
import { BidPriceService } from '../../../services/market-search/bid-price.service';
import { SeatCalculationService } from '../../../services/market-search/seat-calculation.service';
import { SeamlessAvailabilityService } from '../../../services/market-search/seamless-respose.service';
import { MarketSearchParamsService, SeatCalParams } from '../../../services/market-search/marketsearch-params.service';

@Component({
  selector: 'full-market',
  templateUrl: './full-market.component.html'
})

export class FullMarketComponent implements OnInit {
  public displayNavigation: boolean = false;
  public selectedReport: string;
  public selectedValue: number = 0;
  public selectedFl: any;
  public showDropDown: boolean = true;
  public searchTypes: Reports[] = [{ name: 'All Reports', value: 'all' },
  { name: 'Bid Price', value: 'bid' },
  { name: 'Base fare', value: 'base' },
  { name: 'Seat Calculation', value: 'seat' }];
  public navItems: NavigationTabs[] = [{
    Name: 'Market Search',
  },
  {
    Name: 'Seat Calculation',
  },
  {
    Name: 'Base Fare',
  },
  {
    Name: 'Bid Price',
  }
  ];

  constructor(protected msParamsService: MarketSearchParamsService,
              protected singletonService: AppSingletonService,
              protected messageService: MessageService,
              private fmService: FullMarketService,
              private seamlessService: SeamlessAvailabilityService,
              private baseFareService: BaseFareService,
              private bidPriceService: BidPriceService,
              private spinnerService: Ng4LoadingSpinnerService,
              private seatCalculationService: SeatCalculationService) {
  }

  public ngOnInit() {
    // this.router.navigate(['/marketsearch/full-market/full-market-search']);
  }

  public getFlights(args) {
    this.selectedFl = args.value;
  }

  public search() {
    this.spinnerService.show();
    this.displayNavigation = true;
    this.msParamsService.seatCalculationParams = new SeatCalParams();
    this.msParamsService.baseFareParams = [];
    this.msParamsService.bidPriceParams = [];
    const request = this.msParamsService.jsonRequest;
    request.selectedFlight = this.selectedFl ? this.selectedFl.flight : null;
    let jsonRequest = null;
    jsonRequest = this.seamlessService.getJsonRequestFromSelectedFlight(request, false, this.selectedReport);
    if (this.selectedReport === 'all') {
      this.navItems = [{
        Name: 'Market Search',
      },
      {
        Name: 'Seat Calculation',
      },
      {
        Name: 'Base Fare',
      },
      {
        Name: 'Bid Price',
      }
      ];
      this.seamlessService.getAllReports(jsonRequest).subscribe((result: AllReportsRes) => {
        if (result.data.basefare) {
          this.msParamsService.baseFareParams.push(this.baseFareService.generateResponse(result.data.basefare));
        }
        if (result.data.bidprices) {
          this.msParamsService.bidPriceParams.push(this.bidPriceService.getBidPriceReport(result.data, null));
        }
        if (result.data.seatcomputation) {
          this.msParamsService.seatCalculationParams.leftCabins = this.seatCalculationService.getSeatCalculation(result, 'left');
        }
        if (request.priPOS.compare) {
          jsonRequest = this.seamlessService.getJsonRequestFromSelectedFlight(request, true, this.selectedReport);
          this.seamlessService.getAllReports(jsonRequest).subscribe((data: AllReportsRes) => {
            if (data.data.basefare) {
              this.msParamsService.baseFareParams.push(this.baseFareService.generateResponse(data.data.basefare));
            }
            if (data.data.bidprices) {
              this.msParamsService.bidPriceParams.push(this.bidPriceService.getBidPriceReport(data.data, null));
            }
            if (data.data.seatcomputation) {
              this.msParamsService.seatCalculationParams.rightCabins = this.seatCalculationService.getSeatCalculation(data, 'right');
            }
          });
        }
        this.spinnerService.hide();
        // empty
      });
    } else if (this.selectedReport === 'base') {
        this.navItems = [{
          Name: 'Market Search',
        },
        {
          Name: 'Base Fare',
        }];
        this.seamlessService.getAllReports(jsonRequest).subscribe((result: BaseFareRes) => {
          this.msParamsService.baseFareParams.push(this.baseFareService.generateResponse(result.data.basefare));
          if (request.priPOS.compare) {
            jsonRequest = this.seamlessService.getJsonRequestFromSelectedFlight(request, true, this.selectedReport);
            this.seamlessService.getAllReports(jsonRequest).subscribe((data: BaseFareRes) => {
              this.msParamsService.baseFareParams.push(this.baseFareService.generateResponse(data.data.basefare));
        });
          }
          this.spinnerService.hide();
        });
    } else if (this.selectedReport === 'bid') {
        this.navItems = [{
          Name: 'Market Search',
        },
        {
          Name: 'Bid Price',
        }];
        this.seamlessService.getAllReports(jsonRequest).subscribe((result: BidPriceRes) => {
          this.msParamsService.bidPriceParams.push(this.bidPriceService.getBidPriceReport(result.data, null));
          if (request.priPOS.compare) {
            jsonRequest = this.seamlessService.getJsonRequestFromSelectedFlight(request, true, this.selectedReport);
            this.seamlessService.getAllReports(jsonRequest).subscribe((data: BidPriceRes) => {
              this.msParamsService.bidPriceParams.push(this.bidPriceService.getBidPriceReport(data.data, null));
        });
          }
          this.spinnerService.hide();
        });
      } else if (this.selectedReport === 'seat') {
        this.navItems = [{
          Name: 'Market Search',
        },
        {
          Name: 'Seat Calculation',
        }];
        this.seamlessService.getAllReports(jsonRequest).subscribe((result: SeatComputationRes) => {
          this.msParamsService.seatCalculationParams.leftCabins = this.seatCalculationService.getSeatCalculation(result, 'left');
          if (request.priPOS.compare) {
            jsonRequest = this.seamlessService.getJsonRequestFromSelectedFlight(request, true, this.selectedReport);
            this.seamlessService.getAllReports(jsonRequest).subscribe((data: SeatComputationRes) => {
              this.msParamsService.seatCalculationParams.rightCabins = this.seatCalculationService.getSeatCalculation(data, 'right');
            });
          }
          this.spinnerService.hide();
        });
      }

  }

  private selectedItem(args) {
    this.selectedValue = args.value;
    if (args.value === 0) {
      this.showDropDown = true;
    } else {
      this.showDropDown = false;
    }
  }
}
