import { Component, OnInit } from '@angular/core';
import { AppSingletonService } from '../../app-singleton.service';
import { Router } from '@angular/router';
import { BaseFareService } from '../../../services/market-search/base-fare.service';
import { MarketSearchParamsService } from '../../../services/market-search/marketsearch-params.service';

@Component({
    selector: 'bid-price',
    templateUrl: 'bid-price.component.html',
    styleUrls: ['./bid-price.component.scss']
})
export class BidPriceComponent implements OnInit {
    public cabinData: any;
    // public bidTabs: any = [];
    private selectedItems: number = 0;
    constructor(private router: Router, private marketSearchParamsService: MarketSearchParamsService) {
        // console
    }

    public ngOnInit() {
        this.cabinData = this.marketSearchParamsService.bidPriceParams;
        if (!this.cabinData) {
            this.router.navigate(['/marketsearch']);
        }
        // for (const val of this.cabinData) {
        //     this.bidTabs.push({Name: val.origin.toUpperCase() + ' > ' + val.destination.toUpperCase()
        //     + ' ' + val.carrier.toUpperCase() + ' ' + val.flightNo});
        // }
    }

    public selectedItem(args) {
        this.selectedItems = args.value;
    }
}
