import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { AppSingletonService } from '../../../app-singleton.service';
import { MessageService, Message } from '@dxc/tr-ux-ace-core/dist/lib';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppValidator } from '../../../validators/app-validator';
import {
    MarketSearchParams, FullMarketSearch, BaseFareRequestParams,
    BaseFareUrlAndParams, BidPriceRequestParams, Flight, PriPos
} from '../../../services/market-search/marketsearch-params.model';
import { MarketSearchParamsService } from '../../../services/market-search/marketsearch-params.service';
import { FullMarketService } from '../../../services/market-search/full-market.service';
import { BaseFareService } from '../../../services/market-search/base-fare.service';
import { BidPriceService } from '../../../services/market-search/bid-price.service';
import { BidPriceRes, BaseFareRes, AllReportsRes } from '../../../services/market-search/market-model';
import { SeamlessAvailabilityService } from '../../../services/market-search/seamless-respose.service';
import { MarketSearchValidator } from '../market-search-validators/market-search-validator';
import { InitiateFormGroups } from '../../../services/market-search/initiate-formgroups';

@Component({
    selector: 'search-bar',
    templateUrl: 'search-bar.component.html',
    styleUrls: ['./search-bar.component.scss'],
    providers: [AppValidator, MarketSearchValidator]
})
export class SearchBarComponent implements OnInit {
    @Input() public childInput: any;
    @Output('searchclick') public searchclick = new EventEmitter();

    public searchBar: FormGroup;
    public searchTypes: string;
    public disableButton: boolean = false;
    private parms: MarketSearchParams;
    private baseFareParms: BaseFareRequestParams;
    private bidPriceParms: BidPriceRequestParams;
    private hasError: boolean = false;
    private jsonRequest: any;
    private baseFareUrl: BaseFareUrlAndParams;
    private bidPriceUrl: BaseFareUrlAndParams;
    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageService,
                private router: Router,
                private msParamService: MarketSearchParamsService,
                private validator: AppValidator,
                private fullMarketService: FullMarketService,
                private baseFareService: BaseFareService,
                private bidPriceService: BidPriceService,
                private spinnerService: Ng4LoadingSpinnerService,
                private seamlessService: SeamlessAvailabilityService,
                private marketSearchValidator: MarketSearchValidator,
                private initiateFormGroups: InitiateFormGroups) {
        this.searchTypes = this.singletonService.marketSearchStore.SearchType;
    }

    public ngOnInit() {
        this.searchBar = this.fb.group({
            searchType: 'FM',
            fullMarketSearch: this.initiateFormGroups.initSearchBar(),
            baseFareSearch: this.initiateFormGroups.initBaseFare(),
            bidPriceSearch: this.initiateFormGroups.initBidPrice(),
            seamlessSearch: this.initiateFormGroups.initSeamlessSearch(),
            customSeamlessSearch: this.initiateFormGroups.initCustomSeamlessSearch()
        });
    }

    get flightFormArray(): FormArray {
        return this.searchBar.get('customSeamlessSearch').get('flightDetails') as FormArray;
    }

    public reset() {
        this.router.navigate(['/marketsearch']);
    }

    public onSearchClick() {
        this.validate();
        if (!this.hasError) {
            this.spinnerService.show();
            if (this.searchBar.controls.searchType.value === 'FM') {
                this.getFullMarketSearch();
            } else if (this.searchBar.controls.searchType.value === 'BFR') {
                this.getBaseFareSearch();
            } else if (this.searchBar.controls.searchType.value === 'BPR') {
                this.getBidPriceSearch();
            } else if (this.searchBar.controls.searchType.value === 'CSR') {
                this.getCustomeSeamlessSearch();
            } else if (this.searchBar.controls.searchType.value === 'SAR') {
                this.getSeamlessSearch();
            }
        }
    }

    public addDatesFlight(i) {
        this.flightFormArray.push(this.initiateFormGroups.createFlightDetails());
        if (this.flightFormArray.length === 3) {
            this.disableButton = true;
        }
    }

    public removeDatesFlight(i) {
        this.flightFormArray.removeAt(i);
        this.disableButton = false;
    }

    private getSeamlessSearch() {
        this.router.navigate(['/marketsearch']);
        const priPOS = new PriPos();
        priPOS.country = 'US';
        priPOS.airportCode = 'IAH';
        // get from carrier
        priPOS.gdsCarrier = 'UA';
        const flight = new Flight();
        // need to get from carrier
        flight.carrier = 'UA';
        flight.carrierName = 'United Airlines';
        const flightOptions = [flight];
        this.jsonRequest = {};
        this.jsonRequest.flightOptions = flightOptions;
        this.jsonRequest.priPOS = priPOS;
        const params = {
            edifact: this.searchBar.controls.seamlessSearch['controls'].edifact.value.replace(/(\s+|\r\n|\n|\r)/gm, '')
        };
        this.fullMarketService.postEdifactRequest(params).subscribe((result: AllReportsRes) => {
            this.msParamService.params = [];
            const seamlessResponse = this.fullMarketService.getDataFromSeamless(result.data.paores.odi);
            this.msParamService.params.push(this.fullMarketService.classifyCabinClass(seamlessResponse));
           // this.jsonRequest.selectedFlight = this.data[0].travelsegments;
            this.msParamService.jsonRequest = this.jsonRequest;
            this.router.navigate(['/marketsearch/seamless-avail']);
            this.spinnerService.hide();
        });
    }

    private getBidPriceSearch() {
        this.bidPriceParms = new BidPriceRequestParams();
        const { marketDepDate,
            marketOrgin, marketDestination,
            fltOptFlightNumber, fltOptCarrier } = this.searchBar.controls.bidPriceSearch['controls'];
        this.bidPriceParms.flightNumber = fltOptFlightNumber.value;
        this.bidPriceParms.departuredate = marketDepDate.value;
        this.bidPriceParms.destination = marketDestination.value;
        this.bidPriceParms.fltOptCarrier = fltOptCarrier.value;
        this.bidPriceParms.origin = marketOrgin.value;
        this.bidPriceUrl = this.bidPriceService.generateUrlAndRequest(this.bidPriceParms);
        this.msParamService.bidPriceParams = [];
        this.bidPriceService.getBidPriceDetails(this.bidPriceUrl).subscribe((resp: BidPriceRes) => {
            this.msParamService.bidPriceParams.push(this.bidPriceService.getBidPriceReport(resp.data, null));
            this.router.navigate(['/marketsearch/bid-price']);
            this.spinnerService.hide();
        });
    }

    private getBaseFareSearch() {
        this.baseFareParms = new BaseFareRequestParams();
        this.msParamService.baseFareParams = [];
        const { marketDepDate,
            marketOrgin, marketDestination,
            fltOptConnection1, fltOptConnection2,
            countryCode, fltOptCarrier } = this.searchBar.controls.baseFareSearch['controls'];
        this.baseFareParms.countryCode = countryCode.value;
        this.baseFareParms.departuredate = marketDepDate.value;
        this.baseFareParms.destination = marketDestination.value;
        this.baseFareParms.firstconnect = fltOptConnection1.value;
        this.baseFareParms.fltOptCarrier = fltOptCarrier.value;
        this.baseFareParms.origin = marketOrgin.value;
        this.baseFareParms.secondconnect = fltOptConnection2.value;
        this.baseFareUrl = this.baseFareService.generateUrlAndRequest(this.baseFareParms);
        this.baseFareService.getBaseFareDetails(this.baseFareUrl).subscribe(
            (data: BaseFareRes) => {
                this.msParamService.baseFareParams.push(this.baseFareService.generateResponse(data.data.basefare));
                this.router.navigate(['/marketsearch/base-fare']);
                this.spinnerService.hide();
            });
    }

    private getCustomeSeamlessSearch() {
        this.router.navigate(['/marketsearch']);
        const { flightDetails, marketDepDate, posCountry, posAirport,
            posIataCode, posGds, comparePos, comparePosCountry, comparePosAirport,
            comparePosIataCode, comparePosGds } = this.searchBar.get('customSeamlessSearch')['controls'];
        const priPOS = new PriPos();
        priPOS.country = 'US';
        priPOS.airportCode = 'IAH';
            // get from carrier
        priPOS.gdsCarrier = 'UA';
        priPOS.compare = comparePos.value;
        const secPos = new PriPos();
        secPos.country = 'US';
        secPos.cityCode = posCountry.value;
        secPos.iataCode = posIataCode.value;
        // gdscarrier get from carrier
        secPos.gdsCarrier = comparePosGds.value;
        secPos.gdsCarrierName = comparePosGds.value;
        secPos.airportCode = 'IAH';
        secPos.compare = comparePos.value;
        const flightOptions = [];
        const departWindow = [];
        for (const val of flightDetails.controls) {
            const departWindow1 = {
                departureDate: null,
                startTime: null,
                endTime: null
            };
            const flight = new Flight();
            flight.carrier = 'UA';
            flight.carrierName = 'United Airlines';
            flight.flightNumber = val.value.fltOptFlightNumber;
            flight.boardOn = val.value.marketOrgin;
            flight.boardOff = val.value.marketDestination;
            flightOptions.push(flight);
            departWindow1.departureDate = val.value.marketDepDate;
            departWindow.push(departWindow1);
        }
        this.jsonRequest = {};
        this.jsonRequest.flightOptions = flightOptions;
        this.jsonRequest.departWindow = departWindow;
        this.jsonRequest.secPOS = secPos;
        this.jsonRequest.priPOS = priPOS;
        const val1 = this.seamlessService.getAvailabilityJsonRequest(this.jsonRequest, false);
        this.seamlessService.getAllReports(val1).subscribe((result: AllReportsRes) => {
            this.msParamService.params = [];
            let seamlessResponse = this.fullMarketService.getDataFromSeamless(result.data.paores.odi);
            this.msParamService.params.push(this.fullMarketService.classifyCabinClass(seamlessResponse));
            this.msParamService.jsonRequest = this.jsonRequest;
            if (comparePos.value) {
                const val2 = this.seamlessService.getAvailabilityJsonRequest(this.jsonRequest, true);
                this.seamlessService.getAllReports(val2).subscribe((innerResult: AllReportsRes) => {
                    seamlessResponse = this.fullMarketService.getDataFromSeamless(innerResult.data.paores.odi);
                    this.msParamService.params.push(this.fullMarketService.classifyCabinClass(seamlessResponse));
                    this.router.navigate(['/marketsearch/custom-seam']);
            });
        } else {
            this.router.navigate(['/marketsearch/custom-seam']);
        }
            this.spinnerService.hide();
        });
    }

    private getFullMarketSearch() {
        const priPOS = new PriPos();
        priPOS.country = 'US';
        priPOS.airportCode = 'IAH';
        // get from carrier
        priPOS.gdsCarrier = 'UA';
        const flight = new Flight();
        flight.carrier = 'UA';
        flight.carrierName = 'United Airlines';

        const departWindow1 = {
            departureDate: null,
            startTime: null,
            endTime: null
        };
        const departWindow = [departWindow1];
        const flightOptions = [flight];
        this.jsonRequest = {};
        this.jsonRequest.flightOptions = flightOptions;
        this.jsonRequest.priPOS = priPOS;
        this.jsonRequest.departWindow = departWindow;
        this.msParamService.jsonRequest = this.jsonRequest;
        this.parms = new MarketSearchParams();
        this.parms.type = this.searchBar.controls.searchType.value;
        this.parms.fullMarket = new FullMarketSearch();
        const { fullMarket } = this.parms;
        const { marketReward, marketDepDate,
            marketOrgin, marketDestination,
            depStartTime, depEndTime,
            fltOptConnection1, fltOptConnection2,
            fltOptFlightNumber, fltOptCarrier, comparePos } = this.searchBar.controls.fullMarketSearch['controls'];
        fullMarket.marketReward = marketReward.value;
        fullMarket.marketOrgin = marketOrgin.value;
        fullMarket.marketDestination = marketDestination.value;
        fullMarket.marketDepDate = marketDepDate.value;
        fullMarket.depStartTime = depStartTime.value;
        fullMarket.depEndTime = depEndTime.value;
        fullMarket.fltOptConnection1 = fltOptConnection1.value;
        fullMarket.fltOptConnection2 = fltOptConnection2.value;
        fullMarket.fltOptFlightNumber = fltOptFlightNumber.value;
        fullMarket.fltOptCarrier = fltOptCarrier.value;
        fullMarket.comparePos = comparePos.value;
        this.msParamService.params = [];
        const request = this.fullMarketService.generateRequest(this.parms, this.parms.fullMarket.comparePos);
        this.fullMarketService.getFullMarketDetails1(request).subscribe((result) => {
            this.msParamService.params.push(this.fullMarketService.getData(result));
            this.router.navigate(['/marketsearch/full-market']);
            this.spinnerService.hide();
        });
    }

    private validate() {
        this.hasError = false;
        if (this.searchBar.controls.searchType.value === 'FM') {
            this.marketSearchValidator.doFullMarketAndBaseValidation(this.searchBar, 'fullMarket');
            if (this.searchBar.controls.fullMarketSearch.status.toLowerCase() === 'invalid') {
                this.hasError = true;
            }
        } else if (this.searchBar.controls.searchType.value === 'BFR') {
            this.marketSearchValidator.doFullMarketAndBaseValidation(this.searchBar, 'baseFare');
            if (this.searchBar.controls.baseFareSearch.status.toLowerCase() === 'invalid') {
                this.hasError = true;
            }
        } else if (this.searchBar.controls.searchType.value === 'BPR') {
            this.marketSearchValidator.doBidPriceValidation(this.searchBar);
            if (this.searchBar.controls.bidPriceSearch.status.toLowerCase() === 'invalid') {
                this.hasError = true;
            }
        }
    }
}
