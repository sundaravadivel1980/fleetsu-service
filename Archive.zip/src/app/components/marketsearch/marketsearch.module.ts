/*
 * Rule Module
 */

import { NgModule } from '@angular/core';

import { DxcCoreModule } from '@dxc/tr-ux-ace-core/dist/lib';

import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { PlatformModule } from '@angular/cdk/platform';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import {
  MatPaginatorModule,
  MatGridListModule,
  MatListModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRippleModule,
  MatSliderModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTabsModule,
  MatTooltipModule,
} from '@angular/material';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MarketSearchComponent } from './marketsearch.component';
import { MarketSearchRoutingModule } from './marketsearch-routing.module';
import { FullMarketRoutingModule } from './full-market-search/fullmarket-routing.module';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { FullMarketSearchComponent } from './full-market-search/full-market-search.component';
import { FullMarketComponent } from './full-market-search/full-market.component';
import { BaseFareComponent } from './base-fare/base-fare.component';
import { SeatCalculationComponent } from './seat-calculation/seat-calculation.component';
import { BidPriceComponent } from './bid-price/bid-price.component';
import { MarketSearchParamsService } from '../../services/market-search/marketsearch-params.service';
import { FullMarketService } from '../../services/market-search/full-market.service';
import { InitiateFormGroups } from '../../services/market-search/initiate-formgroups';
import { BaseFareService } from '../../services/market-search/base-fare.service';
import { SeatCalculationService } from '../../services/market-search/seat-calculation.service';
import { SeamlessAvailabilityService } from '../../services/market-search/seamless-respose.service';
import { BidPriceService } from '../../services/market-search/bid-price.service';
import { MySort } from '../../pipes/rule/sort-pipe';

@NgModule({
  imports: [
    // Cdk
    A11yModule,
    BidiModule,
    ObserversModule,
    OverlayModule,
    PlatformModule,
    PortalModule,
    ScrollDispatchModule,
    CdkStepperModule,
    CdkTableModule,
    // Material
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    DxcCoreModule,
    MarketSearchRoutingModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatGridListModule,
    MatListModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRippleModule,
    MatSliderModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTabsModule,

  ],
  declarations: [
    MarketSearchComponent,
    FullMarketSearchComponent,
    SearchBarComponent,
    FullMarketComponent,
    BaseFareComponent,
    BidPriceComponent,
    SeatCalculationComponent,
    MySort
  ],
  providers: [MarketSearchParamsService, FullMarketService, BaseFareService, SeamlessAvailabilityService,
    SeatCalculationService, BidPriceService, InitiateFormGroups],
  entryComponents: []
})
export class MarketSearchModule { }
