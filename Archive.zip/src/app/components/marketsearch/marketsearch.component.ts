/*
 * Rule Engine Component which will route to rule list, detail, edit, create, delete
 */
import { Component, OnInit } from '@angular/core';
import { AppSingletonService } from '../../app-singleton.service';

@Component({
  templateUrl: 'marketsearch.component.html',
  styleUrls: ['./marketsearch.component.scss'],
  providers: []
})
export class MarketSearchComponent implements OnInit {
  public searchType: string = '';

  private valueChanged = 0;
  constructor(private singletonService: AppSingletonService) {
    this.singletonService.currentApp = 'Market Search';
  }
  public ngOnInit(): void {
    // empty
  }
  public showSearchResult(args) {
    this.searchType = '';
    this.valueChanged += 1;
    this.searchType = args.value;
  }

}
