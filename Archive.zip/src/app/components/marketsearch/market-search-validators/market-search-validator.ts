import { ValidationErrors, FormGroup, FormArray, Validator, Validators, AbstractControl } from '@angular/forms';
import { AppValidator } from '../../../validators/app-validator';

export class MarketSearchValidator extends AppValidator {
    public constructor() {
        // empty
        super();
    }

    public doFullMarketAndBaseValidation(control: FormGroup, searchType) {
        const { marketOrgin,
            marketDestination,
            marketDepDate,
            fltOptCarrier } = searchType === 'fullMarket' ? control.controls.fullMarketSearch['controls']
                : control.controls.baseFareSearch['controls'];
        super.setRequired(marketOrgin);
        super.setRequired(marketDestination);
        super.setRequired(marketDepDate);
        super.setRequired(fltOptCarrier);
        // empty
    }

    public doBidPriceValidation(control: FormGroup) {
        const { marketOrgin,
            marketDestination,
            marketDepDate,
            fltOptCarrier, fltOptFlightNumber } = control.controls.bidPriceSearch['controls'];
        super.setRequired(marketOrgin);
        super.setRequired(marketDestination);
        super.setRequired(marketDepDate);
        super.setRequired(fltOptCarrier);
        super.setRequired(fltOptFlightNumber);
    }

}
