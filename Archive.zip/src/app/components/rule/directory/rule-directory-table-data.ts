import { HttpErrorResponse } from '@angular/common/http';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RuleService, RuleRs, RuleSummary, Rule, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';

import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';
import { MessageTranslationService } from 'src/app/services/message-translation.service';

export class RuleDirectoryTableData {
    public dataChange: BehaviorSubject<RuleSummary[]> = new BehaviorSubject<RuleSummary[]>([]);
    public ruleData = new Subject <Rule[]> ();
    private URL = environment.RULE_URL;

    constructor(private ruleService: RuleService,
                private messageServiceAdapter: MessageTranslationService,
                private spinnerService: Ng4LoadingSpinnerService) {
    }

    get data(): RuleSummary[] {
        return this.dataChange.value;
    }

    public getRuleDatas(): Observable <Rule[]> {
        return this.ruleData.asObservable();
    }

    public loadAllRules() {
        this.spinnerService.show();
        const url = environment.RULE_URL + '/directory';
        this.ruleService.getAllRules(url).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                     const rows = ruleResponse.rule ? ruleResponse.rule : [];
                     this.dataChange.next(rows);
                } else {
                    this.messageServiceAdapter.serviceError(url, ruleResponse.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }

    public loadRules(status: string, ruleType: string) {
        this.spinnerService.show();
        const url = environment.RULE_URL + '/directory';
        this.ruleService.getRules(url, status, ruleType).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    const rows = ruleResponse.rule ? ruleResponse.rule : [];
                    this.dataChange.next(rows);
                } else {
                    this.messageServiceAdapter.serviceError(url, ruleResponse.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }

    public deleteRule(ruleId) {
        this.spinnerService.show();
        const url = environment.RULE_URL;
        this.ruleService.deleteRule(url + '/' + ruleId).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    this.messageServiceAdapter.success('Rule Deleted Successfully.');
                } else {
                    this.messageServiceAdapter.serviceError(url, ruleResponse.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            },
            () => {
                this.loadAllRules();
            }
        );
    }

    public getRule(id: number, version: number) {
        this.spinnerService.show();
        this.messageServiceAdapter.clear();
        // let ruleDeactivateData: any;
        const url = this.URL + '/' + id + '/' + version;
        this.ruleService.getRule(url).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    const rows = ruleResponse.rule ? ruleResponse.rule : [];
                    this.ruleData.next(rows);
               } else {
                   this.messageServiceAdapter.serviceError(url, ruleResponse.rsStandardPayload);
               }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            }
        );
    }

    public updateStatus(ruleDataReq: RuleRq) {
        this.spinnerService.show();
        this.messageServiceAdapter.clear();
        this.ruleService.updateRule(this.URL, ruleDataReq).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    this.messageServiceAdapter.success('Rule Deactivated Successfully', true);
                } else {
                    this.messageServiceAdapter.serviceError(this.URL, ruleResponse.rsStandardPayload);
                }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageServiceAdapter.httpError(error);
            },
            () => {
                this.loadAllRules();
            }
        );
    }
}
