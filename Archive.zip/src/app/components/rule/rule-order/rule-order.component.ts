import { Component, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { RuleService, RuleRs, RuleSummary, Rule, RuleRq, RuleOrderRs, Order } from '@dxc/tr-ux-ace-services/dist/lib';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormControl, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ComboBox } from '../../../models/ui-model';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';

@Component({
    selector: 'rule-order',
    templateUrl: './rule-order.component.html',
    styleUrls: ['./rule-order.component.scss']
})

export class RuleOrderComponent implements OnInit {

    public tableColumns = ['order', 'newOrder', 'name', 'keyword', 'type', 'status', 'version', 'time', 'userId'];
    public ruleStatus: any;
    public ruleType: any;
    public ruleOrderClicked: boolean = true;
    public triggerError: boolean;

    public status: ComboBox[] = [
        { id: 'ACTIV', value: 'Active' },
        { id: 'SIMUL', value: 'Simulated' }
    ];
    public ruleTypes: ComboBox[] = [
        { id: 'MKFRAJ', value: 'Market' },
        { id: 'BPRADJ', value: 'Bid Price' },
        { id: 'AVLADJ', value: 'Availability' }
    ];
    // public tableRows: Rule[];
    public tableForm: FormGroup;
    public dataSource: MatTableDataSource<Order>;
    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    constructor(
        private ruleService: RuleService,
        private fb: FormBuilder,
        private route: ActivatedRoute,
        private spinnerService: Ng4LoadingSpinnerService,
        private http: HttpClient) {
    }

    public ngOnInit(): void {
        // const tableRows = this.tableRows;
    }

    public saveTable(): void {
        this.spinnerService.show();
        this.ruleOrderClicked = true;
        const url: string = 'http://localhost:8402/ace/rule/order';
        const data = this.getTableDataForSave();
        this.http.post(url, data, { headers: new HttpHeaders().set('Content-Type', 'application/json') }).subscribe(
            (response: RuleOrderRs) => {
                this.spinnerService.hide();
                if (response.rsStandardPayload.success) {
                    console.log(response);
                }
            },
            (error) => {
                this.spinnerService.hide();
                console.log(error);
            });
    }

    public ruleReOrder() {
        if (this.tableForm.valid) {
            this.triggerError = false;
            this.ruleOrderClicked = false;
        } else {
            this.triggerError = true;
        }
    }

    public getTableDataForSave() {
        const orders = {
            status: this.ruleStatus,
            type: this.ruleType,
            order: []
        };
        Object.keys(this.tableForm.value).forEach(gId => {
            orders.order.push({ gid: gId, orderNumber: this.tableForm.value[gId] });
        });
        return { order: [orders] };
    }

    /**** USE THIS FOR SORTING REFERENCE ***
        public ruleReOrder() {
            this.ruleOrderClicked = false;
            const tableRows = JSON.parse(JSON.stringify(this.dataSource.data));
            const list = JSON.parse(JSON.stringify(this.getOrderList));
            const affectRowsOrder = [];
            const keys = Object.keys(list);
            const tempRows = [];
            keys.forEach(gid => {
                tableRows.forEach(row => {
                    if (Number(row.gid) === Number(gid)) {
                        row.order = Number(list[gid]['new']);
                    }
                    tempRows.push(row);
                });
            });

            keys.forEach(gid => {
                if (keys.indexOf((list[gid]['affect']).toString()) !== -1) {
                    affectRowsOrder.push(list[gid]['current']);
                    delete list[gid];
                }
            });
            const newTableRows = [];
            affectRowsOrder.forEach(replaceOrder => {
                Object.keys(list).forEach(gid => {
                    tempRows.forEach(row => {
                        if (Number(row.gid) === Number(list[gid]['affect'])) {
                            row.order = Number(replaceOrder);
                        }
                        newTableRows.push(row);
                    });
                });
            });
            console.log(this.dataSource.data);
            console.log(Array.from(new Set(newTableRows)));
            this.tableForm = undefined;
            this.tableForm = this.fb.group(this.dynamicFormFields(tableRows));
            this.dataSource.data = Array.from(new Set(newTableRows));
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
        }

        get getOrderList() {
            const form = JSON.parse(JSON.stringify(this.tableForm.value));
            const currentRows = this.dataSource.data;
            const returnList = {};
            Object.keys(form).forEach(gid => {
                if (form[gid] !== null && form[gid] !== '' && form[gid] !== undefined) {
                    const obj = {};
                    currentRows.forEach(row => {
                        if (row['gid'] === Number(gid)) {
                            obj['current'] = row.order;
                            obj['new'] = form[gid];
                        }

                        if (Number(form[gid]) === Number(row.order)) {
                            obj['affect'] = row['gid'];
                        }
                    });
                    returnList[gid] = obj;
                }
            });
            return returnList;
        }
        */

    public createDynamicTableAndForm(tableRows: Order[]) {
        this.tableForm = this.fb.group(this.dynamicFormFields(tableRows));
        this.dataSource = new MatTableDataSource(tableRows);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    }

    public dynamicFormFields(tableRows): object {
        const allFormFields = {};
        for (const row of tableRows) {
            allFormFields[row.gid] = new FormControl('', Validators.required);
        }
        return allFormFields;
    }

    public getTable(status, type): void {
        this.spinnerService.show();
        const url = 'http://localhost:8402/ace/rule/order/directory';
        let params: any;
        params = new HttpParams().set('status', status).set('ruleSet', type);
        this.http.get(url, { params }).subscribe(
            (ruleResponse) => {
                this.spinnerService.hide();
                const rows = ruleResponse['rule'] ? ruleResponse['rule'] : [];
                this.createDynamicTableAndForm(rows);
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                console.log(error);
            }
        );
    }

    public applyFilter(filterValue: string): void {
        filterValue = filterValue.trim(); // Remove whitespace
        filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
        this.dataSource.filter = filterValue;
    }
}
