import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';
import { RuleService, RuleRs, RuleSummary, Rule, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';
import { HttpClient } from '@angular/common/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Injectable()
export class RuleOrderResolver implements Resolve<Rule> {
    private cacheResolve: Rule[];
    constructor(
        private ruleService: RuleService,
        private http: HttpClient,
        private spinnerService: Ng4LoadingSpinnerService) {
    }

    public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
        const url = environment.RULE_URL + '/directory';
        this.spinnerService.show();
        if (this.cacheResolve) {
            this.spinnerService.hide();
            console.log(this.cacheResolve);
            return this.cacheResolve;
        }else {
            return this.http.get(url).toPromise().then(
                (ruleResponse: RuleRs) => {
                    console.log(ruleResponse);
                    this.cacheResolve = ruleResponse.rule as Rule[];
                    this.spinnerService.hide();
                    console.log(this.cacheResolve);
                    return this.cacheResolve ? this.cacheResolve : null;
                }
            );
        }
    }
}
