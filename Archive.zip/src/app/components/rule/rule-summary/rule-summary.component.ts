import { Component, Inject, OnInit, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ComboBox, IdValue } from '../../../models/ui-model';
import { AppSingletonService } from '../../../app-singleton.service';
import { RuleRs, RuleRq, RqStandardPayload, Rule, Action, RuleService } from '@dxc/tr-ux-ace-services/dist/lib';
import { DataShare } from '../../../services/rule/data-share';

@Component({
    selector: 'rule-summary',
    templateUrl: 'rule-summary.component.html',
    styleUrls: ['./rule-summary.component.scss']
})
export class RuleSummaryComponent implements OnInit {
    public bookingClassesInput: IdValue[];
    public selectedInput: any = ['B', 'M', 'U', 'N', 'A'];
    public marketDetails: any;
    public classesService: any;
    public classesInput: any;

    public constructor(private dialogRef: MatDialogRef<any>, private appSingleton: AppSingletonService,
                       @Inject(MAT_DIALOG_DATA) public ruleViewPopUpData: any) {
    }

    public ngOnInit() {
        this.classesInput = this.appSingleton.ruleJsonStore.BookingClasses;
        this.marketDetails = this.getMarketCondition();
        this.bookingClassesInput = this.bookingClassesFilter(this.selectedInput, this.classesInput);
        this.classesService = this.classesDetails();
        console.log(this.classesService);
    }

    get getActionDetails() {
        const action = this.ruleViewPopUpData.action[0];
        return action.classClosureAction ? action.classClosureAction : action.classSuppressionAction ? action.classSuppressionAction :
            action.marketFareAdjustmentAction ? action.marketFareAdjustmentAction : action.availabilityAdjustmentAction ?
                action.availabilityAdjustmentAction : action.bidPriceAdjustmentAction ? action.bidPriceAdjustmentAction : '';
    }

    public closeDialog(data) {
        this.dialogRef.close(data);
    }

    private classesDetails() {
        const classesDetails = [];
        if (this.getActionDetails.classCondition) {
            for (const classes of this.getActionDetails.classCondition) {
                classesDetails.push({
                    inputs: this.bookingClassesFilter(classes.classOfService, this.classesInput),
                    selected: classes.classOfService,
                });
            }
        }
        return classesDetails;
    }

    private getMarketCondition() {
        const originDestinations = { market: [], segment: [] };
        for (const marketCond of this.getActionDetails['marketCondition']) {
            if (marketCond.market) {
                for (const item of marketCond.market[0].market) {
                    originDestinations['market'].push({ origin: item['origin'].toString(), destination : item['destination'].toString() });
                }
            } else if (marketCond.segment) {
                for (const item of marketCond.segment) {
                    originDestinations['segment'].push({ origin: item['origin'].toString(), destination : item['destination'].toString() });
                }
            }
        }
        return originDestinations;
    }

    private bookingClassesFilter(selected: any, input: any) {
        const filteredArr = [];
        for (const item of input) {
            const diff = item['value'].filter(x => !selected.includes(x));
            if (diff.length !== item['value'].length) {
                filteredArr.push(item);
            }
        }
        return filteredArr;
    }
}
