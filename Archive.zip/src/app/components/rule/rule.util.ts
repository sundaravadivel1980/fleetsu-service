import { HttpErrorResponse } from '@angular/common/http';
import { AbstractControl } from '@angular/forms/src/model';
import { RuleService,  RqStandardPayload, RuleExportRq, RuleRs, Rule, OriginDestination } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppConstants } from '../../app.constants';
import { saveAs } from 'file-saver/FileSaver';
import { environment } from '../../../environments/environment';
import { DateTimeFormGroup, OriginDestinationFormGroup } from 'src/app/models/rule-form.model';
import { MessageTranslationService } from '../../services/message-translation.service';
import { DatePipe } from '@angular/common';
import { AppUtil } from 'src/app/utility/app-util';

export class RuleUtil {
    public static getAction(rule: Rule) {
        return rule.action[0];
    }

    public static downloadExportData(ruleArray: any, ruleService: RuleService, messageService: MessageTranslationService) {
        const EXPORT_URL = environment.RULE_EXPORT_URL;
        const requestPayload = {
          correlationId: '1', pointOfSale: null
        } as RqStandardPayload;
        const exportRuleData = {
          rqStandardPayload: requestPayload,
          rule: ruleArray
        } as RuleExportRq;

        ruleService.exportRule(EXPORT_URL, exportRuleData).subscribe(
          (ruleResponse: any) => this.saveAsFile(ruleResponse),
          (error: HttpErrorResponse) => {
            messageService.httpError(error);
          }
        );
    }

    public static saveAsFile(blobData: any) {
        const blob = new Blob([blobData], { type: 'application/octet-binary'});
        const objectUrl = URL.createObjectURL(blob);
        const filename = 'rules.csv';
        saveAs(blob, filename);
    }

    public static isBookingClassSelected(formControl: AbstractControl) {
        return formControl.get('bookedClasses').value;
    }

    public static isCabinSelected(formControl: AbstractControl) {
        return formControl.get('cabinClasses').value && formControl.get('cabinClasses').value.length > 0;
    }

    public static splitGroupAndNonGroup(value: string[]) {
        const gArray = [];
        const nonGrray = [];
        value.forEach(data => {
            const group = Number(data);
            if (group && group >= 0) {
                gArray.push(group);
            } else {
                nonGrray.push(data);
            }
        });

        return {groupArray: gArray, nonGroupArray: nonGrray};
    }

    public static splitAirportAndLocationGroup(originDestination: OriginDestinationFormGroup): OriginDestination {
        const originDestinationData = new OriginDestination();

        if (originDestination && originDestination.origin && originDestination.origin.length > 0) {
            const originAndGrouping = this.splitGroupAndNonGroup(originDestination.origin);

            if (originAndGrouping.groupArray.length > 0) {
                originDestinationData.originGrouping = originAndGrouping.groupArray;
            }
            if (originAndGrouping.nonGroupArray.length > 0) {
                originDestinationData.origin = originAndGrouping.nonGroupArray;
            }
        }

        if (originDestination && originDestination.origin && originDestination.destination.length > 0) {
            const destAndGrouping = this.splitGroupAndNonGroup(originDestination.destination);

            if (destAndGrouping.groupArray.length > 0) {
                originDestinationData.destinationGrouping = destAndGrouping.groupArray;
            }
            if (destAndGrouping.nonGroupArray.length > 0) {
                originDestinationData.destination = destAndGrouping.nonGroupArray;
            }
        }

        return originDestinationData;
    }

    public static combineLocationGroupAndAirport(originDestination: OriginDestination): OriginDestinationFormGroup {
        const originDestForm = new OriginDestinationFormGroup();

        const originlocationGroupList = originDestination.originGrouping;
        if (originlocationGroupList && originlocationGroupList.length > 0) {
            const origin = originDestination.origin ? originDestination.origin : [];
            originDestForm.origin = this.combineTwoArray(origin, originlocationGroupList);
        } else {
            originDestForm.origin = originDestination.origin;
        }

        const destlocationGroupList = originDestination.destinationGrouping;
        if (destlocationGroupList) {
            const destination = originDestination.destination ? originDestination.destination : [];
            originDestForm.destination = this.combineTwoArray(destination, destlocationGroupList);
        } else {
            originDestForm.destination = originDestination.destination;
        }

        return originDestForm;
    }

    public static startDateTimeString(form: DateTimeFormGroup, datePipeObj: DatePipe) {
        let startHour: string = form.startHour;
        if (!form.startHour || form.startHour === '0') {
            startHour = '00';
        }
        let startMinute: string = form.startMinute;
        if (!form.startMinute || form.startMinute === '0') {
            startMinute = '00';
        }
        return datePipeObj.transform(form.startDate, 'yyyy-MM-dd') + 'T'
        + startHour + ':' + startMinute + ':00';
    }

    public static endDateTimeString(form: DateTimeFormGroup, datePipeObj: DatePipe) {
        let endHour: string = form.endHour;
        if (!form.endHour || form.endHour === '0') {
            endHour = '00';
        }
        let endMin: string = form.endMinute;
        if (!form.endMinute || form.endMinute === '0') {
            endMin = '00';
        }

        return datePipeObj.transform(form.endDate, 'yyyy-MM-dd') +
        'T' + endHour + ':' + endMin + ':00';
    }

    private static combineTwoArray(array1: string[], array2: number[]) {
        const stringArray = AppUtil.numberToStringArray(array2);
        return array1.concat(stringArray);
    }

}
