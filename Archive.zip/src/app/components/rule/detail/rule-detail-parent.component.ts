import { ViewChild, ViewContainerRef, ViewChildren, QueryList, ComponentFactoryResolver } from '@angular/core';
import { Router } from '@angular/router';
// import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Rule, Action, RuleService, Condition, AllowPartialCancelationActionInput,
    JourneyDataControlActionInput } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../app-singleton.service';
import { AppConstants, CONDITION_MAP } from '../../../app.constants';

import { RuleParams } from '../../../services/rule/rule-params.model';
import { RuleParamsService } from '../../../services/rule/rule-params.service';

import { MarketComponent } from '../conditions/market/market.component';
import { ClassesComponent } from '../conditions/classes/classes.component';
import { FlightsComponent } from '../conditions/flights/flights.component';
import { CarriersComponent } from '../conditions/carriers/carriers.component';
import { LoadFactorComponent } from '../conditions/load-factor/load-factor.component';
import { RoutingComponent } from '../conditions/routing/routing.component';
import { ClassAvailabilityComponent } from '../conditions/class-availability/class-availability.component';
import { ConnectionPointsComponent } from '../conditions/connection-points/connection-points.component';
import { AvailabilityAdjustmentComponent } from '../conditions/availability-adjustment/availability-adjustment.component';
import { BaseFareAdjustmentComponent } from '../conditions/base-fare-adjustment/base-fare-adjustment.component';
import { DepartureDatesComponent } from '../conditions/departure-dates/departure-dates.component';
import { SellingDatesComponent } from '../conditions/selling-dates/selling-dates.component';
import { PointOfSaleComponent } from '../conditions/point-of-sale/point-of-sale.component';
import { BidPriceAdjustmentComponent } from '../conditions/bid-price-adjustment/bid-price-adjustment.component';
import { PointOfCommencementComponent } from '../conditions/point-of-commencement/point-of-commencement.component';
import { ClassBookingComponent } from '../conditions/class-booking/class-booking.component';
import { ArrivalTimeGroupComponent } from '../conditions/arrival-time/arrival-time.component';
import { DepartureTimeGroupComponent } from '../conditions/departure-time/departure-time.component';
import { TimeOutsideDepartureComponent } from '../conditions/time-outside-departure/time-outside-departure.component';
import { TimeToDepartureComponent } from '../conditions/time-to-departure/time-to-departure.component';
import { EquipmentComponent } from '../conditions/equipment/equipment.component';
import { HashDirective } from '../../../directives/hash-directive'; // For dynamic component createtion, finding ng-container
import { HeaderSectionComponent } from '../conditions/header-section/header-section.component';
import { IdValue } from 'src/app/models/ui-model';
import { AppUtil } from 'src/app/utility/app-util';

export class RuleDetailParentComponent {

    public ruleViewData: Rule;

    public params: RuleParams;

    public enableAdditionalCondition: boolean = false;

    public toggleShaddow: boolean = false;
    public optionalConditions: string[] = [];
    public requiredConditions: string[] = [];
    /** Additioncal components list to be shown in the expansion panel */
    public componentsList1: string[] = [];
    public componentsList2: string[] = [];
    public selectedOptConditions: any = {};
    public selectedReqConditions: any = {};
    public isDataLoaded: boolean;

/**
 * @ViewChild() provides the instance of another component or directive
 * in a parent component and then parent component can access the methods and properties of that component or directive.
 */
    @ViewChild(HeaderSectionComponent)
    protected headerSectionComponent: HeaderSectionComponent;
    @ViewChild(MarketComponent)
    private marketComponent: MarketComponent;
    @ViewChild(ClassesComponent)
    private classesComponent: ClassesComponent;
    @ViewChild(FlightsComponent)
    private flightsComponent: FlightsComponent;
    @ViewChild(CarriersComponent)
    private carriersComponent: CarriersComponent;
    @ViewChild(LoadFactorComponent)
    private loadFactorComponent: LoadFactorComponent;
    @ViewChild(ClassAvailabilityComponent)
    private classAvailabilityComponent: ClassAvailabilityComponent;
    @ViewChild(ConnectionPointsComponent)
    private connectionPointsComponent: ConnectionPointsComponent;
    @ViewChild(RoutingComponent)
    private routingComponent: RoutingComponent;
    @ViewChild(AvailabilityAdjustmentComponent)
    private availabilityAdjustmentComponent: AvailabilityAdjustmentComponent;
    @ViewChild(BaseFareAdjustmentComponent)
    private baseFareAdjustmentComponent: BaseFareAdjustmentComponent;
    @ViewChild(DepartureDatesComponent)
    private departureDatesComponent: DepartureDatesComponent;
    @ViewChild(PointOfSaleComponent)
    private pointOfSaleComponent: PointOfSaleComponent;
    @ViewChild(BidPriceAdjustmentComponent)
    private bidPriceAdjustmentComponent: BidPriceAdjustmentComponent;
    @ViewChild(PointOfCommencementComponent)
    private pointOfCommencementComponent: PointOfCommencementComponent;
    @ViewChild(ClassBookingComponent)
    private classBookingComponent: ClassBookingComponent;
    @ViewChild(SellingDatesComponent)
    private sellingDatesComponent: SellingDatesComponent;
    @ViewChild(ArrivalTimeGroupComponent)
    private arrivalTimeGroupComponent: ArrivalTimeGroupComponent;
    @ViewChild(DepartureTimeGroupComponent)
    private departureTimeGroupComponent: DepartureTimeGroupComponent;
    @ViewChild(TimeOutsideDepartureComponent)
    private timeOutsideDepartureComponent: TimeOutsideDepartureComponent;
    @ViewChild(TimeToDepartureComponent)
    private timeToDepartureComponent: TimeToDepartureComponent;
    @ViewChild(EquipmentComponent)
    private equipmentComponent: EquipmentComponent;
    @ViewChildren(HashDirective) private hashes: QueryList<HashDirective>; // Directive to get dynamic Compoenents

    constructor(
        protected ruleParamsService: RuleParamsService,
        protected router: Router,
        protected ruleService: RuleService,
        protected singletonService: AppSingletonService,
        protected resolver: ComponentFactoryResolver) {

        const data = singletonService.ruleJsonStore;
    }

    protected enableDisableOptionalConditions() {
        this.selectedOptConditions = {};
        const conditions = this.ruleViewData.condition;
        const conditionKeys = Object.keys(conditions);

        for (const key of conditionKeys) {
            const code = CONDITION_MAP[key];
            if (code) {
                const emptyArray = AppUtil.isEmptyArray(this.optionalConditions);
                if (!emptyArray && this.optionalConditions.join().indexOf(code) !== -1) {
                     this.selectedOptConditions[code] = true;
                }
            }
        }
        for (const key in this.selectedOptConditions) {
            // If any additional condition is true, then show the 'Aditional Conditions' sections
            if (this.selectedOptConditions[key] === true) {
                this.enableAdditionalCondition = true;
            }
        }
    }

    protected enableRequiredConditions() {
        const reqConditions = this.requiredConditions;
        for (const cond of reqConditions) {
            this.selectedReqConditions[cond] = true;
        }
    }

    protected buildAction(): Action {
        const action = {} as Action;
        this.setActionInput(action);
        return action;
    }

    protected isEmptyPOSAndPOC() {
        if (this.pointOfSaleComponent.isEmpty() && this.pointOfCommencementComponent.isEmpty()) {
            return true;
        }
        return false;
    }

    protected buildCondition(): Condition {
        const condition =  new Condition();

        if (this.selectedReqConditions.MARKET || this.selectedOptConditions.MARKET) {
            condition.marketCondition = this.marketComponent.getValues();
        }

        if (this.selectedReqConditions.CLASSES || this.selectedOptConditions.CLASSES) {
            condition.classCondition = this.classesComponent.getValues();
        }

        if (this.selectedReqConditions.POS || this.selectedOptConditions.POS) {
            condition.pointOfSaleCondition = this.pointOfSaleComponent.getValues();
        }

        if (this.selectedReqConditions.POC  || this.selectedOptConditions.POC) {
            condition.pointOfCommencementCondition = this.pointOfCommencementComponent.getValues();
        }

        if (this.selectedReqConditions.FLIGHT || this.selectedOptConditions.FLIGHT) {
            condition.flightCondition = this.flightsComponent.getValues();
        }

        if (this.selectedReqConditions.CARRIER || this.selectedOptConditions.CARRIER) {
            condition.carrierCondition = this.carriersComponent.getValues();
        }

        if (this.selectedReqConditions.LOADFACTOR  || this.selectedOptConditions.LOADFACTOR) {
            condition.loadFactorCondition = this.loadFactorComponent.getValues();
        }

        if (this.selectedReqConditions.CLASSAVL  || this.selectedOptConditions.CLASSAVL) {
            condition.classAvailabilityCondition = this.classAvailabilityComponent.getValues();
        }

        if (this.selectedReqConditions.CONNPOINT  || this.selectedOptConditions.CONNPOINT) {
            condition.connectionPointCondition = this.connectionPointsComponent.getValues();
        }

        if (this.selectedReqConditions.ROUTING  || this.selectedOptConditions.ROUTING) {
            condition.routingCondition = this.routingComponent.getValues();
        }

        if (this.selectedReqConditions.DEPTDATE  || this.selectedOptConditions.DEPTDATE) {
            condition.departureDateCondition = this.departureDatesComponent.getValues();
        }

        if (this.selectedReqConditions.CLASSBKG  || this.selectedOptConditions.CLASSBKG) {
            condition.classBookingCondition = this.classBookingComponent.getValues();
        }

        if (this.selectedReqConditions.SELLDATE  || this.selectedOptConditions.SELLDATE) {
            condition.sellingDateTimeCondition = this.sellingDatesComponent.getValues();
        }

        if (this.selectedReqConditions.ARRTIME  || this.selectedOptConditions.ARRTIME) {
            condition.arrivalTimeCondition = this.arrivalTimeGroupComponent.getValues();
        }

        if (this.selectedReqConditions.DEPTTIME  || this.selectedOptConditions.DEPTTIME) {
            condition.departureTimeCondition = this.departureTimeGroupComponent.getValues();
        }

        if (this.selectedReqConditions.TIMEOUTDEPT  || this.selectedOptConditions.TIMEOUTDEPT) {
            condition.timeOutsideDepartureCondition = this.timeOutsideDepartureComponent.getValues();
        }

        if (this.selectedReqConditions.TIMETODEPT  || this.selectedOptConditions.TIMETODEPT) {
            condition.timeToDepartureCondition = this.timeToDepartureComponent.getValues();
        }

        if (this.selectedReqConditions.EQUIP  || this.selectedOptConditions.EQUIP) {
            condition.equipmentCondition = this.equipmentComponent.getValues();
        }

        return condition;
    }

    protected setAdjustLeg(action: Action) {
        if (action.bidPriceAdjustmentActionInput) {
            action.bidPriceAdjustmentActionInput.adjustLeg = this.marketComponent.getLegOrOAndDFlag();
        }
    }

    protected splitList(list: any) {
        const data = list.sort((a, b) => {
            const x = a['description'].toString().toLowerCase();
            const y = b['description'].toString().toLowerCase();
            return x < y ? -1 : y < x ? 1 : 0 ;
        });
        const divide: number = (data.length / 2) + 1;
        this.componentsList1 = data.slice(0, divide);
        this.componentsList2 = data.slice(divide);
    }

    protected getAdditionalConditionsArray(optionalConditions: string[]) {
        const idValueList = [];
        for (const cond of optionalConditions) {
            const idValue = new IdValue();
            idValue.id = cond;
            idValue.value = 'acegui.rule.addl.conditions.' + cond;
            idValueList.push(idValue);
        }

        if (idValueList.length > 0) {
            const divide: number = (idValueList.length / 2) + 1;
            this.componentsList1 = idValueList.slice(0, divide);
            this.componentsList2 = idValueList.slice(divide);
        }
    }

    private setActionInput(action: Action) {
        switch (this.params.ruleAction) {
            case AppConstants.ACTION_CLASS_CLOSSURE:
                action.classClosureActionInput = this.classesComponent.getClassClossureActionInput();
                break;
            case AppConstants.ACTION_BASE_FARE_ADJ:
                action.marketFareAdjustmentActionInput = this.baseFareAdjustmentComponent.getValues();
                break;
            case AppConstants.ACTION_BID_PRICE_ADJ:
                action.bidPriceAdjustmentActionInput = this.bidPriceAdjustmentComponent.getValues();
                break;
            case AppConstants.ACTION_CLASS_SUPPRESSION:
                action.classSuppressionActionInput = this.classesComponent.getClassSuppressionActionInput();
                break;
            case AppConstants.ACTION_AVAIL_ADJ:
                action.availabilityAdjustmentActionInput = this.availabilityAdjustmentComponent.getValues();
                break;
            case AppConstants.ACTION_PARTIAL_CANCELLATION:
                action.allowPartialCancelationActionInput = new AllowPartialCancelationActionInput();
                break;
            case AppConstants.ACTION_REMOVE_JOUNEY_USER:
                action.journeyDataControlActionInput = new JourneyDataControlActionInput();
                break;
            default:
            // Nothing to do here
        }
    }
}
