import { Component, OnInit, OnDestroy, ViewChild, ViewContainerRef, AfterViewInit,
ComponentFactoryResolver, Renderer } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { OverlayOrigin } from '@angular/cdk/overlay';
import { TemplatePortalDirective } from '@angular/cdk/portal';
import { OverlayConfig } from '@angular/cdk/overlay';
import { Overlay } from '@angular/cdk/overlay';
import { MatDialog } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { TranslateService } from '@ngx-translate/core';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

import {
  RuleRs,
  RuleRq,
  RqStandardPayload,
  Rule,
  Action,
  RuleService
} from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../app-singleton.service';
import { DataShare } from '../../../services/rule/data-share';
import { RuleParamsService } from '../../../services/rule/rule-params.service';
import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';
import { RuleDetailParentComponent } from './rule-detail-parent.component';
import { RuleSummaryComponent } from '../rule-summary/rule-summary.component';
import { MessageTranslationService } from '../../../services/message-translation.service';
import { ClassesComponent } from '../conditions/classes/classes.component';
import { CarrierConfig } from 'src/app/models/carrier-config';
import { RuleUtil } from 'src/app/components/rule/rule.util';

@Component({
  templateUrl: './rule-detail.component.html',
  styleUrls: ['./rule-detail.component.scss']
})

/*
  * Rule detail component. This use the Angular reactive form concept
  * This contains multiple child components.
  * See the rule-detail.component.html for the embedded child components/forms
  * this.ruleViewData is the input to the child form(s)
  *
  * RuleDetailParentComponent.setComponents is used to get the values from the
  * child forms and construct the rule PUT/POST request
 *
 */

export class RuleDetailComponent extends RuleDetailParentComponent implements OnInit, OnDestroy {
  public enableAdditionalCondition: boolean = false;
  // @ViewChild('classesContainer', {read: ViewContainerRef}) public classesContainer: ViewContainerRef;

  private URL: string = environment.RULE_URL;
  private overlayRef: any;

  @ViewChild('addConditionOrigin')
  private addConditionOrigin: OverlayOrigin;
  @ViewChild('addConditionTemplate')
  private addConditionTemplate: TemplatePortalDirective;

  constructor(public overlay: Overlay,
              protected ruleParamsService: RuleParamsService,
              protected router: Router,
              protected ruleService: RuleService,
              protected singletonService: AppSingletonService,
              protected popup: MatDialog,
              protected resolver: ComponentFactoryResolver,
              private translateService: TranslateService,
              private spinnerService: Ng4LoadingSpinnerService,
              private factoryResolver: ComponentFactoryResolver,
              private messageServiceAdapter: MessageTranslationService) {
    super(ruleParamsService, router, ruleService, singletonService,  resolver);
    // To reload the page after save/copy
    if (this.params && this.params.copyId > 0) {
      this.router.routeReuseStrategy.shouldReuseRoute = function(){
          return false;
      };
    }
  }
  /*
   * Angular lifecycle method, used to get/populate the value for new/edit rule
  */
  public ngOnInit() {
    this.params = this.ruleParamsService.params;
    if ( this.params === undefined ) {
      this.router.navigate(['/rule']);   // If no value set, redirect to home (Try to access via url)
    }

    this.getCarrierPreferredConditions();

    // Get the additional conditions to be shown in the overlay popup
    this.getAdditionalConditionsArray(this.optionalConditions);

    this.enableRequiredConditions();

    if (this.params && (this.params.ruleId > 0 || this.params.copyId > 0)) {
      // for edit, load the rule from db and enable the rule optional conditions
      this.loadRule();
    } else if (this.params && this.params.ruleId === 0) {
      // for new rule
      this.isDataLoaded = true;
      this.ruleViewData = new Rule();
      this.ruleViewData.type = this.params.ruleAction;
    }
  }

  public getCarrierPreferredConditions() {
    this.requiredConditions = [];
    this.optionalConditions = [];

    // by default loading from file.
    this.requiredConditions = this.singletonService.configJsonStore[this.params.ruleAction + '_default']['data'];
    this.optionalConditions = this.singletonService.configJsonStore[this.params.ruleAction + '_optional']['data'];

    // Set it from carrier preference if available
    const optPreference = CarrierConfig.getCarrierPreferenceValues(
      this.params.ruleAction + '_optional', this.singletonService.carrierPreferences);
    if (optPreference[0] && optPreference[0].data && optPreference[0].data.length > 0) {
      this.optionalConditions = optPreference[0].data;
    }

    const requiredPreference = CarrierConfig.getCarrierPreferenceValues(
      this.params.ruleAction + '_default', this.singletonService.carrierPreferences);
    if (requiredPreference[0] && requiredPreference[0].data && requiredPreference[0].data.length > 0) {
      this.requiredConditions = requiredPreference[0].data;
    }

  }

  /*
   * User action for save rule. This will construct the rule request and post to service
   *
  */
  public saveRule(status: string) {

    this.messageServiceAdapter.clearConsolidatedErrors();
    this.messageServiceAdapter.clear();

    const ruleActionInput = this.buildAction();
    const ruleConditions = this.buildCondition();

    if (this.params.ruleAction === AppConstants.ACTION_BID_PRICE_ADJ) {
      this.setAdjustLeg(ruleActionInput);
    }

    if (this.params.ruleAction === AppConstants.ACTION_REMOVE_JOUNEY_USER
         || this.params.ruleAction === AppConstants.ACTION_PARTIAL_CANCELLATION) {
          if (this.isEmptyPOSAndPOC()) {
            this.messageServiceAdapter.addRequiredConditionError('POS or POC');
          }
    }

    const headerValues = this.headerSectionComponent.getValues();
    if (!this.messageServiceAdapter.hasConsolidatedErrors()) {
      const rule = {
        gid: this.params.ruleId,
        keyword: headerValues.keywords,
        name: headerValues.name,
        status: headerValues.status,
        transaction: headerValues.transaction,
        time: this.params.ruleTime,
        version: this.params.ruleVersion,
        userId: null,
        type: this.params.ruleAction,
        quickRule: null,
        action: ruleActionInput,
        condition: ruleConditions
      } as Rule;

      this.ruleViewData = rule;

      this.createOrUpdateRule();

    } else {
        this.messageServiceAdapter.showConsolidatedErrors();
    }

  }

  /**
   * To show additional conditions list overlay
   */
  public showAddlCondtionsOverlay() {
    const strategy = this.overlay.position()
      .connectedTo(
      this.addConditionOrigin.elementRef,
      { originX: 'end', originY: 'bottom' },
      { overlayX: 'end', overlayY: 'top' });

    const config = new OverlayConfig({
      hasBackdrop: true,
      backdropClass: 'cdk-overlay-transparent-backdrop',
      positionStrategy: strategy
    });
    this.overlayRef = this.overlay.create(config);

    this.overlayRef.attach(this.addConditionTemplate);
    this.overlayRef.backdropClick().subscribe(() => this.overlayRef.detach());
  }

  /**
   * Will add additional components in the rule detail page
   */
  public addAdditionalComp(checked: boolean, id: string) {
    this.selectedOptConditions[id] = checked;
    this.enableAdditionalCondition = false;
    for (const key in this.selectedOptConditions) {
      if (this.selectedOptConditions[key] === true) {
        this.enableAdditionalCondition = true;
      }
    }
  }

  public closeAddCondition() {
    this.overlayRef.detach();
  }

  /**
   * Confirmation popup. Not yet fully implemented
   * @param rule
   */
  public ruleSummary(rule) {
    const popupRef = this.popup.open(RuleSummaryComponent,
      {
        data: rule,
        width: '750px'
      });
    popupRef.afterClosed().subscribe(result => {
       if (result === 'confirmed') {
        this.createOrUpdateRule();
       }
    });
  }

  public ngOnDestroy() {
    // this.ruleParamsService.params = undefined;
  }

  private createOrUpdateRule() {
    this.spinnerService.show();
    const requestPayload = { correlationId: '1', pointOfSale: null } as RqStandardPayload;
    const ruleData = { rqStandardPayload: requestPayload, rule: [this.ruleViewData] } as RuleRq;
    if (this.ruleParamsService.params.ruleId > 0) {
      this.ruleService.updateRule(this.URL, ruleData).subscribe(
        (ruleResponse: RuleRs) => {
          this.spinnerService.hide();
          if (ruleResponse.rule && ruleResponse.rule.length > 0) {
            this.ruleViewData = ruleResponse.rule[0];
            this.ruleParamsService.params.ruleId = this.ruleViewData.gid;
            this.ruleParamsService.params.ruleVersion = this.ruleViewData.version;
            this.ruleParamsService.params.ruleTime = this.ruleViewData.time;
            this.messageServiceAdapter.success('Rules saved successfully');
          } else {
            this.messageServiceAdapter.serviceError(this.URL, ruleResponse.rsStandardPayload);
          }
        },
        (error: HttpErrorResponse) => {
          this.spinnerService.hide();
          this.messageServiceAdapter.httpError(error);
        }
      );
    } else {
      this.ruleService.createRule(this.URL, ruleData).subscribe(
        (ruleResponse: RuleRs) => {
          this.spinnerService.hide();
          if (ruleResponse.rule && ruleResponse.rule.length > 0) {
            this.headerSectionComponent.enableIconLinks();
            this.ruleViewData = ruleResponse.rule[0];
            this.ruleParamsService.params.ruleId = this.ruleViewData.gid;
            this.ruleParamsService.params.ruleVersion = this.ruleViewData.version;
            this.ruleParamsService.params.ruleTime = this.ruleViewData.time;
            this.messageServiceAdapter.success('Rules Saved Successfully', true);
            this.router.navigate(['/rule/detail', this.ruleViewData.gid]);
          } else {
            this.messageServiceAdapter.serviceError(this.URL, ruleResponse.rsStandardPayload);
          }
        },
        (error: HttpErrorResponse) => {
          this.spinnerService.hide();
          this.messageServiceAdapter.httpError(error);
        }
      );
    }
  }

  private loadRule() {
    let tmpRuleId: number;
    let tmpRuleVersion: number;
    if (this.params.copyId > 0) {
      tmpRuleId = this.params.copyId;
      tmpRuleVersion = this.params.copyRuleVersion;
    } else {
      tmpRuleId = this.params.ruleId;
      tmpRuleVersion = this.params.ruleVersion;
    }

    this.spinnerService.show();
    this.ruleService.getRule(this.URL + '/' + tmpRuleId + '/' + tmpRuleVersion).subscribe(
      (ruleResponse: RuleRs) => {
        this.spinnerService.hide();
        this.params.ruleTime = ruleResponse.rule[0].time;
        this.isDataLoaded = true;
        this.ruleViewData = ruleResponse.rule[0];
        this.params.ruleTime = ruleResponse.rule[0].time;
        if (this.params.copyId > 0) {
          this.ruleViewData.status = '';
        }
        this.enableDisableOptionalConditions();
      },
      (error: HttpErrorResponse) => {
        this.spinnerService.hide();
        this.messageServiceAdapter.httpError(error);
      }
    );
  }

}
