/*
 * Rule Engine Component which will route to rule list, detail, edit, create, delete
 */
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: 'rule.component.html',
  styleUrls: ['./rule.component.scss'],
  providers: []
})
export class RuleComponent {
  public selectedNavItem: number = 1;
  public  navItems  =  [{
    Name:  'Home',
    Link: '/rule'
  },
  {
    Name:  'Directory',
    Link: '/rule'
  },
  {
    Name:  'Table',
    Link: 'tables'
  },
  {
    Name:  'Groups',
    Link: 'groups'
  }
  ];
  constructor(private router: Router) {

  }
  public navigateToPage($event) {
      // this.selectedNavItem = $event.value;
      // this.router.navigate([this.navItems[$event.value].Link]);
  }
}
