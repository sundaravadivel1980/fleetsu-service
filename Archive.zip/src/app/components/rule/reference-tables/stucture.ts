export const stucture = {
    rsStandardPayload: {
        success: true
    },
    tableStructure: [{
        name: 'Carrier Grouping',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 1,
        version: 1,
        column: [{
            name: 'Code',
            displayName: 'Code',
            required: true,
            type: 'STRING',
            validationErrorCode: 50000,
            validationErrorMessage: 'Carrier group code must contain a 3 character alpha numeric value',
            validationRegEx: '[A-Z0-9]{3}'
        }, {
            name: 'Description',
            displayName: 'Description',
            required: true,
            type: 'STRING'
        }, {
            name: 'Carrier Codes',
            displayName: 'Carrier Codes',
            listDelim: ',',
            minListItems: 1,
            required: true,
            type: 'STRING',
            validationErrorCode: 50001,
            validationErrorMessage: 'Carrier codes must contain one or more 2 character alpha numeric values',
            validationRegEx: '[A-Za-z0-9]{2}'
        }],
        description: 'Carrier Group Table',
        paging: false,
        readOnly: false
    }, {
        name: 'Location Grouping',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 2,
        version: 1,
        column: [{
            name: 'Code',
            displayName: 'Code',
            required: true,
            type: 'STRING',
            validationErrorCode: 50100,
            validationErrorMessage: 'Location group code must contain a 4 character alpha numeric value',
            validationRegEx: '[A-Z0-9]{4}'
        }, {
            name: 'Description',
            displayName: 'Description',
            required: true,
            type: 'STRING'
        }, {
            name: 'Airport/City Codes',
            displayName: 'Airport/City Codes',
            listDelim: ',',
            minListItems: 1,
            required: true,
            type: 'STRING',
            validationErrorCode: 50101,
            validationErrorMessage: 'Airport/City codes must contain one or more 3 character alpha values',
            validationRegEx: '[A-Za-z]{3}'
        }],
        description: 'Location Group Table',
        paging: false,
        readOnly: false
    }, {
        name: 'Market Grouping',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 3,
        version: 1,
        column: [{
            name: 'Code',
            displayName: 'Code',
            required: true,
            type: 'STRING',
            validationErrorCode: 50200,
            validationErrorMessage: 'Market group code must contain a 4 character alpha numeric value',
            validationRegEx: '[A-Z0-9]{4}'
        }, {
            name: 'Description',
            displayName: 'Description',
            required: true,
            type: 'STRING'
        }, {
            name: 'Origin',
            displayName: 'Origin Airport, City or Location Group Codes',
            listDelim: ',',
            minListItems: 1,
            required: true,
            type: 'STRING',
            validationErrorCode: 50201,
            validationErrorMessage:
            'Airport/City codes must contain one or more 3 character alpha values, and Location codes must contain 4 character alpha values',
            validationRegEx: '[A-Za-z]{3}|[A-Za-z0-9]{4}'
        }, {
            name: 'Destination',
            displayName: 'Destination Airport, City or Location Group Codes',
            listDelim: ',',
            minListItems: 1,
            required: true,
            type: 'STRING',
            validationErrorCode: 50202,
            validationErrorMessage:
            'Airport/City codes must contain one or more 3 character alpha values, and Location codes must contain 4 character alpha values',
            validationRegEx: '[A-Za-z]{3}|[A-Za-z0-9]{4}'
        }],
        description: 'Market Group Table',
        paging: false,
        readOnly: false
    }, {
        name: 'Flight Grouping',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 4,
        version: 1,
        column: [{
            name: 'Code',
            displayName: 'Code',
            required: true,
            type: 'STRING',
            validationErrorCode: 50300,
            validationErrorMessage: 'Flight group code must contain a 4 character alpha numeric value, starting with an alpha',
            validationRegEx: '[A-Z][A-Z0-9]{3}'
        }, {
            name: 'Description',
            displayName: 'Description',
            required: true,
            type: 'STRING'
        }, {
            name: 'Flights',
            displayName: 'Flight Numbers or Ranges',
            listDelim: ',',
            minListItems: 1,
            required: true,
            type: 'STRING',
            validationErrorCode: 50301,
            validationErrorMessage: 'Flight must contain 1 to 4 numeric flight numbers or a range with 2 flight numbers separated by a dash (-)',
            validationRegEx: '[0-9]{1,4}(-[0-9]{1,4})?'
        }],
        description: 'Flight Group Table',
        paging: false,
        readOnly: false
    }, {
        name: 'Carrier Preferences',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 5,
        version: 1,
        column: [{
            name: 'Key',
            displayName: 'Configuration Key',
            required: true,
            type: 'STRING'
        }, {
            name: 'Description',
            displayName: 'Description',
            required: false,
            type: 'STRING'
        }, {
            name: 'Values',
            displayName: 'Configuration Values',
            listDelim: ',',
            subListDelim: ':',
            minListItems: 1,
            required: true,
            type: 'SUB_LIST'
        }],
        description: 'Carrier Preferences Table',
        paging: false,
        readOnly: false
    }, {
        name: 'Equipment',
        time: '2018-02-15T16:59:20',
        userId: 'TODO',
        id: 6,
        version: 1,
        column: [{
            name: 'IATA Code',
            displayName: 'IATA Equipment Code',
            required: true,
            type: 'STRING'
        }, {
            name: 'IATA Description',
            displayName: 'IATA Code Description',
            required: false,
            type: 'STRING'
        }, {
            name: 'Configuration Code',
            displayName: 'Equipment Configuration Code',
            type: 'STRING'
        }, {
            name: 'Configuration Description',
            displayName: 'Equipment Configuration Description',
            required: false,
            type: 'STRING'
        }],
        description: 'Equipment Code Table',
        paging: false,
        readOnly: false
    }]
};
