import { Component, ViewChild, Input, Output, OnInit, OnChanges, AfterViewInit, AfterContentInit, EventEmitter } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';

@Component({
    selector: 'dynamic-table',
    templateUrl: 'dynamic-table.component.html'
})

export class DynamicTableComponent implements OnChanges {

    public columns: any[] = [];
    public displayedColumns: any;
    public dataSource: any;
    @ViewChild(MatSort) public sort: MatSort;
    @ViewChild(MatPaginator) public paginator: MatPaginator;

    @Input() public tableContent: any;
    @Input() public tableColumns: any;
    @Output() public clickedRow = new EventEmitter();

    constructor() {
        // console.log
    }

    public ngOnChanges() {
        if (this.tableContent && this.tableColumns) {
            this.generateTable(this.tableContent, this.tableColumns);
        } else {
            console.log('No data');
        }
    }

    public generateTable(content, cols) {
        this.displayedColumns = [];
        this.displayedColumns = cols;
        if (this.displayedColumns.indexOf('actions') === -1) {
            this.displayedColumns.push('actions');
        }

        this.columns = [];
        for (const item of this.displayedColumns) {
            if (item !== 'actions') {
                this.columns.push({ columnDef: item, header: item, cell: (element) => `${element[item]}` });
            } else if (item === 'actions') {
                this.columns.push({ columnDef: item, header: item, cell: (element) => ` ` });
            }
        }

        this.dataSource = undefined;
        this.dataSource = new MatTableDataSource(content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    }

    public applyFilter(filterValue: string) {
        this.dataSource.filter = (filterValue.trim()).toLowerCase();
    }

    public emitClickedRow(row, action) {
        row['action'] = action;
        this.clickedRow.emit(row);
    }
}
