import { Component, OnInit, Input, Output, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http/src/response';

// import { Observable } from 'rxjs/Observable';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { environment } from '../../../../../environments/environment';
import { AppConstants } from '../../../../app.constants';
import { ReferenceTablesService } from '@dxc/tr-ux-ace-services';

@Component({
    templateUrl: 'details.component.html'
})

export class DetailsComponent implements OnInit, OnDestroy {
    public formFields: any;
    constructor(
        private singleton: AppSingletonService,
        private route: Router,
        private messageService: MessageTranslationService,
        private actRoute: ActivatedRoute,
        private refService: ReferenceTablesService) {
    }

    public ngOnInit() {
        this.formFields = this.refService.shareParams;
        console.log(this.formFields);
    }

    public ngOnDestroy() {
        this.refService.shareParams = undefined;
    }

    public formEmitted(data) {
        console.log(data);
        if (data.action === 'cancel') {
            this.route.navigate(['rule/tables'], { skipLocationChange: true });
        }

        if (data.action === 'save') {
            delete data.action;
            console.log(data);
            const params = { row: [] };
            params['row'].push(data);
            console.log(params);
            const URL = environment.REF_TABLE_URL;
            this.refService.addNewRecord(URL, params).subscribe(
                (response) => {
                    if (response['rsStandardPayload']['success'] === true) {
                        this.refService.responseMessage = { success: true, operation: data.operation };
                        this.messageService.success('Successfully Added');
                        this.route.navigate(['rule/tables'], { skipLocationChange: true });
                    }else if (response['rsStandardPayload']['success'] === false) {
                        this.messageService.serviceError(URL, response['rsStandardPayload']);
                    }
                },
                (error: HttpErrorResponse) => {
                    this.messageService.httpError(error);
                }
            );
        }
    }
}
