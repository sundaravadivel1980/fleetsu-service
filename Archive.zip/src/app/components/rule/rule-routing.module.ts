import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RuleComponent } from './rule.component';
import { RuleDirectoryComponent } from './directory/rule-directory.component';
import { RuleDetailComponent } from './detail/rule-detail.component';
import { DetailsComponent } from './reference-tables/details/details.component';
import { DirectoryComponent } from './reference-tables/directory/directory.component';
import { RuleOrderComponent } from './rule-order/rule-order.component';
import { RuleOrderResolver } from './rule-order/rule-order.resolver';
// import {} from '../grouping/grouping.module'

const routes: Routes = [
  {
    path: '',
    component: RuleComponent,
    children: [
      { path: '', component: RuleDirectoryComponent, pathMatch: 'full' },
      { path: 'detail/:id', component: RuleDetailComponent, pathMatch: 'full' },
      { path: 'tables', component: DirectoryComponent, pathMatch: 'full' },
      { path: 'tables/details', component: DetailsComponent, pathMatch: 'full' },
      { path: 'detail', redirectTo: '/rule', pathMatch: 'full' },
      { path: 'groups', loadChildren: '../grouping/grouping.module#GroupingModule' },
      { path: 'order', component: RuleOrderComponent, pathMatch: 'full'
      // , resolve: {
      //   tableContent: RuleOrderResolver
      // }
     },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RuleRoutingModule { }
