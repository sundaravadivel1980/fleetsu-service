import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, AvailabilityAdjustmentActionInput, ClassCondition, CarrierPreference } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import {
    RuleDetailChildForm,
    AvailabilityAdjustmentComponentForm,
    AvailabilityAdjustmentFormGroup
} from '../../../../models/rule-form.model';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { AppValidator } from 'src/app/validators/app-validator';
import { RuleDetailFieldValidator } from 'src/app/validators/rule/rule-detail-field-validator';
import { CarrierConfig } from 'src/app/models/carrier-config';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector: 'availability-adjustment',
    templateUrl: 'availability-adjustment.component.html',
    styleUrls: ['./availability-adjustment.component.scss']
})

export class AvailabilityAdjustmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public availabilityAdjustmentForm: FormGroup;

    /**
     * Actually it is not array. There will be only one action input
     */
    private availAdjustDataActionInput: AvailabilityAdjustmentActionInput;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    private commonFieldValidator = new RuleDetailFieldValidator();
    private carrierPrefSeats: string;
    private carrierPrefPercentage: string;
    private carrierPrefMaxSeats: string;
    private carrierPrefMaxIncreaseOrDecrease: string;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
                // empty constructor
    }

    public ngOnInit() {
        this.carrierPrefPercentage =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.PERCENTAGE_RESTRICTION, this.singletonService.carrierPreferences);
       // this.carrierPrefPercentage = '1-100';
        this.carrierPrefSeats =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.SEATS_RESTRICTION, this.singletonService.carrierPreferences);
        this.carrierPrefMaxSeats =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_SEATS_RESTRICTION, this.singletonService.carrierPreferences);
        this.carrierPrefMaxIncreaseOrDecrease =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_SEATS_INCREASE_OR_DECREASE, this.singletonService.carrierPreferences);

        this.availabilityAdjustmentForm = this.fb.group({
            availabilityAdjustmentUnit: this.fb.array([this.createAvailAdjFormGroup()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.availAdjustDataActionInput = rule.action.availabilityAdjustmentActionInput;
        }
        if (this.availAdjustDataActionInput) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): AvailabilityAdjustmentActionInput {
        this.validate();

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Availability adjustment');
            return null;
        }

        const dataArray = [];
        for (const availAdjustUnit of this.aaFormArray.value) {
            const availabilityActionInput = new AvailabilityAdjustmentActionInput();
            availabilityActionInput.changeAmount = availAdjustUnit.seats > 0 ?
                availAdjustUnit.seatsSign + availAdjustUnit.seats : '';
            availabilityActionInput.changePercent = availAdjustUnit.numbers > 0 ?
                availAdjustUnit.numbersSign + availAdjustUnit.numbers : '';
            availabilityActionInput.maximum = availAdjustUnit.maxSeats;
            availabilityActionInput.maximumIncrease = availAdjustUnit.increaseSeats;
            availabilityActionInput.overrideSegmentLimit = availAdjustUnit.override ? true : false;
            availabilityActionInput.useAuAvailability = availAdjustUnit.availability ? true : false;
            dataArray.push(availabilityActionInput);
        }
        return dataArray[0];
    }

    public validate() {
        const removeGroups = [];
        this.hasErrors = false;

        this.removeEmptyForms();

        const validator = new AppValidator();

        if (this.isEmptyCondition) {
            this.messageService.addError('acegui.rules.messages.avail.adjust.condition.required');
            this.hasErrors = true;
        } else {
            for (const availAdjustFormUnit of this.aaFormArray.controls) {

                // Percentage is required when maximum increase seats is given
                if ((!availAdjustFormUnit.get('numbers').value && availAdjustFormUnit.get('increaseSeats').value) ||
                    availAdjustFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                 }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyGroups = [];
        this.isEmptyCondition = false;

        for (const availAdjustFormUnit of this.aaFormArray.controls) {
            let emptyForm = true;
            if (availAdjustFormUnit.value.availability || availAdjustFormUnit.value.override || availAdjustFormUnit.value.seats ||
                availAdjustFormUnit.value.numbers || availAdjustFormUnit.value.maxSeats ||
                availAdjustFormUnit.value.increaseSeats) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyGroups.push(i);
            }
            i++;
        }
        for (const removeGroup of emptyGroups.reverse()) {
            this.removeAvailabilityAdjustmentUnit(removeGroup);
        }
        if (this.aaFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addAvailabilityAdjustmentUnit();
        }
    }

    /**
     * If AU is selected, disable all other fields
     * @param checked
     */
    public auSelected(checked) {
        const fieldsList = ['override', 'numbers', 'maxSeats', 'seats', 'numbersSign', 'seatsSign', 'increaseSeats'];
        if (checked) {
            for (const field of fieldsList) {
                this.aaFormArray.controls[0].get(field).reset();
                this.aaFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.aaFormArray.controls[0].get(field).reset();
                this.aaFormArray.controls[0].get(field).disable();
            }
        }
    }

    get aaFormArray(): FormArray {
        return this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
    }

    private numberPercentageDisable(value, index, args) {
        if (value === '') {
            this.aaFormArray.controls[index].get(args).enable();
            this.aaFormArray.controls[index].get(args + 'Sign').enable();
        } else {
            this.aaFormArray.controls[index].get(args).reset();
            this.aaFormArray.controls[index].get(args + 'Sign').reset();
            this.aaFormArray.controls[index].get(args + 'Sign').disable();
            this.aaFormArray.controls[index].get(args).disable();
        }

    }

    private setFormValuesFromData() {
        const availAdjustFormUnitArray = [];

        const availAdjustFormUnit = {} as AvailabilityAdjustmentFormGroup;
        if (this.availAdjustDataActionInput.changeAmount) {
            availAdjustFormUnit.seatsSign = this.availAdjustDataActionInput.changeAmount > 0 ? '+' : '-';
            availAdjustFormUnit.seats = Math.abs(this.availAdjustDataActionInput.changeAmount);
        }
        if (this.availAdjustDataActionInput.changePercent) {
            availAdjustFormUnit.numbersSign = this.availAdjustDataActionInput.changePercent > 0 ? '+' : '-';
            availAdjustFormUnit.numbers = Math.abs(this.availAdjustDataActionInput.changePercent);
        }
        availAdjustFormUnit.maxSeats = this.availAdjustDataActionInput.maximum;
        availAdjustFormUnit.minSeats = this.availAdjustDataActionInput.minimum;
        availAdjustFormUnit.increaseSeats = this.availAdjustDataActionInput.maximumIncrease;
        availAdjustFormUnit.availability = this.availAdjustDataActionInput.useAuAvailability ? true : false;
        availAdjustFormUnit.override = this.availAdjustDataActionInput.overrideSegmentLimit ? true : false;
        availAdjustFormUnitArray.push(availAdjustFormUnit);
        const availAdjustFormModel = {
            availabilityAdjustmentUnit: availAdjustFormUnitArray
        } as AvailabilityAdjustmentComponentForm;

        if (availAdjustFormModel) {
            this.setFormValues(availAdjustFormModel);
        }

        if (availAdjustFormUnit.availability) {
            this.auSelected(!availAdjustFormUnit.availability);
        }
    }

    private setFormValues(availabilityAdjustmentFromModel: AvailabilityAdjustmentComponentForm) {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        for (const availabilityAdjustmentUnit of availabilityAdjustmentFromModel.availabilityAdjustmentUnit) {
            control.push(this.createAvailAdjFormGroup());
        }
        this.removeAvailabilityAdjustmentUnit(0);
        (this.availabilityAdjustmentForm as FormGroup).patchValue(availabilityAdjustmentFromModel, { onlySelf: true });
    }

    private createAvailAdjFormGroup() {		// nest
        return this.fb.group({
            seatsSign: [''],
            seats: ['', this.commonFieldValidator.validateNumberRange(this.carrierPrefSeats)],
            numbersSign: [''],
            numbers: ['',  Validators.compose([this.commonFieldValidator.validateNumberRange(this.carrierPrefPercentage),
                                                this.commonFieldValidator.validatePercentage])],
            maxSeats: ['', this.commonFieldValidator.validateNumberRange(this.carrierPrefMaxSeats)],
            increaseSeats: ['', Validators.compose([this.commonFieldValidator.validateNumberRange(this.carrierPrefMaxIncreaseOrDecrease),
                                                    this.commonFieldValidator.checkPercentage]) ],
            override: [''],
            availability: ['']
        });
    }

    private addAvailabilityAdjustmentUnit() {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        control.push(this.createAvailAdjFormGroup());
    }

    private removeAvailabilityAdjustmentUnit(i: number) {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        control.removeAt(i);
    }

    get availabilityAdjustmentUnit(): FormArray {
        return this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
    }

}
