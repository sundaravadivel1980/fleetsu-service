import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { ConnectionPointCondition, ConnectionCity, ConnectionCityAirport, TimeConnectionCity, Rule } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleDetailChildForm,
            ConnectionPointComponentForm,
            ConnectionPointFormGroup,
            ConnectionCityAndTimeFormModel
        } from '../../../../models/rule-form.model';
import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';
import { CarrierConfig } from '../../../../models/carrier-config';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { AppUtil } from 'src/app/utility/app-util';
import { AppValidator } from 'src/app/validators/app-validator';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector: 'connection-points',
    templateUrl: 'connection-points.component.html',
    styleUrls: ['./connection-points.component.scss']
})

export class ConnectionPointsComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public connectionPointsform: FormGroup;
    public connectionPointDataArray: ConnectionPointCondition[];

    public mainOperators: ComboBox[];
    public radioOptions: ComboBox[];
    public listOfAirport: AutoCompleteChip[];
    private maxAny: string;
    private maxInSequence: string;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;
    private connectionPointsBeyondMaxLimit: boolean = false;
    private disableButton: boolean[];

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        this.mainOperators = singletonService.ruleJsonStore.ConnectionPoint.MainOperator;
        this.radioOptions = singletonService.ruleJsonStore.ConnectionPoint.RadioOptions;
        this.maxAny =  CarrierConfig.getCarrierPreferenceValue(
            CarrierPrefConstants.ANY_CONNECTION_POINTS_RESTRICTION, this.singletonService.carrierPreferences);
        this.maxInSequence =  CarrierConfig.getCarrierPreferenceValue(
            CarrierPrefConstants.IN_SEQUENCE_CONNECTION_POINT_RESTRICTION, this.singletonService.carrierPreferences);
    }

    public ngOnInit() {
        this.disableButton = [];
        this.listOfAirport = this.singletonService.airports;
        this.connectionPointsform = this.fb.group({ connectionPointUnit: this.fb.array([this.createConnPointFormGroup()]) });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.connectionPointDataArray = rule.condition.connectionPointCondition;
        }

        if ( this.connectionPointDataArray && this.connectionPointDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): ConnectionPointCondition[] {

        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            if (!this.connectionPointsBeyondMaxLimit) {
                // Show the form validation errors only if the connection points within the limit.
                // If beyong the limit, it will show the different error message. Check the validate() method
                this.messageService.addErrorWithParam(
                    'acegui.rules.messages.form.validatiom.failed', 'Connection point condition');
            }
            return null;
        }

        const connectionPointConditionArray = [];
        for (const connectionPointFormUnit of this.connectionPointFormArray.value) {
            const connCityAndTimeArray = [];
            for (const connTimeFormUnit of connectionPointFormUnit.connectionTimeUnit) {
                const connTime =  {
                    maximumMinutes: connTimeFormUnit.maxTime,
                    minimumMinutes: connTimeFormUnit.minTime
                } as TimeConnectionCity;

                const connCity =  {} as ConnectionCityAirport;
                connCity.arrival = connTimeFormUnit.connectionpointCityFrom ? connTimeFormUnit.connectionpointCityFrom[0] : '';
                if (connTimeFormUnit.connectionpointCityTo) {
                    connCity.departure =  connTimeFormUnit.connectionpointCityTo[0];
                }

                connCityAndTimeArray.push({
                    airports: connCity,
                    time: connTime
                } as ConnectionCity);
            }
            connectionPointConditionArray.push({
                comparator: connectionPointFormUnit.connectionpointSelect,
                inSequence: connectionPointFormUnit.connectionpointRadio === 'Any' ? false : true,
                connectionCity : connCityAndTimeArray
            } as ConnectionPointCondition);
        }
        return connectionPointConditionArray;
    }

    public validate() {

        this.removeEmptyForms();

        const emptyConnFormUnits = [];
        this.hasErrors = false;
        this.connectionPointsBeyondMaxLimit = false;
        const validator = new AppValidator();

        if (!this.isEmptyCondition) {
            for (const connPointFormUnit of this.connectionPointFormArray.controls) {
                const connCityTimeFormArray = connPointFormUnit.get('connectionTimeUnit') as FormArray;

                // Connection point maximum validation.
                const selectedRadioButtonValue = connPointFormUnit.get('connectionpointRadio').value;
                if (selectedRadioButtonValue === 'Any'
                        && this.maxAny
                        && (connCityTimeFormArray.length > Number(this.maxAny))) {
                        this.connectionPointsBeyondMaxLimit = true;
                        this.messageService.addErrorWithParam('acegui.rules.messages.connection.point.reached.max.limit', this.maxAny);
                } else if (selectedRadioButtonValue === 'In Sequence'
                        && this.maxInSequence
                        && (connCityTimeFormArray.length > Number(this.maxInSequence))) {
                        this.connectionPointsBeyondMaxLimit = true;
                        this.messageService.addErrorWithParam('acegui.rules.messages.connection.point.reached.max.limit', this.maxInSequence);
                }

                if (this.connectionPointsBeyondMaxLimit) {
                    this.hasErrors = true;
                } else {
                    for (const connCityTimeFormUnit of connCityTimeFormArray.controls) {
                        // Validate the connection city 'From'
                        if (!AppUtil.isArrayValueExists(connCityTimeFormUnit, 'connectionpointCityFrom')) {
                            validator.setRequired(connCityTimeFormUnit.get('connectionpointCityFrom'));
                            this.hasErrors = true;
                        }

                        // Check the other field level errors. There are validations for mintime and maxtime. Check the html
                        if (connCityTimeFormUnit.status.toLowerCase() === 'invalid') {
                            this.hasErrors = true;
                        }
                    }
                }
            }
        }
    }

    public removeEmptyForms() {

        let i: number = 0;
        const emptyConnFormUnits = [];
        this.isEmptyCondition = false;

        for (const connPointFormUnit of this.connectionPointFormArray.controls) {

            const connCityTimeFormArray = connPointFormUnit.get('connectionTimeUnit') as FormArray;
            let j: number = 0;
            const emptyConnCityTimeFormUnits = [];
            for (const connCityTimeFormUnit of connCityTimeFormArray.controls) {
                let emptyConnCityForm = true;
                if (connCityTimeFormUnit.get('connectionpointCityFrom').value.length > 0
                || connCityTimeFormUnit.get('connectionpointCityTo').value.length > 0 ||
                    connCityTimeFormUnit.get('minTime').value || connCityTimeFormUnit.get('maxTime').value) {
                        emptyConnCityForm = false;
                }

                if (emptyConnCityForm) {
                    emptyConnCityTimeFormUnits.push(j);
                }
                j++;
            }
            let emptyForm = false;
            if (connCityTimeFormArray.controls.length === emptyConnCityTimeFormUnits.length) {
                emptyForm = true;
                emptyConnCityTimeFormUnits.splice(0, 1);
            }

            for (const emptyConnCityFormUnit of emptyConnCityTimeFormUnits.reverse()){
                this.removeConnectionTimeUnit(i, emptyConnCityFormUnit);
            }

            if (emptyForm) {
                emptyConnFormUnits.push(i);
            }

            i++;
        }
        if (this.connectionPointFormArray.length === emptyConnFormUnits.length) {
            this.isEmptyCondition = true;
            emptyConnFormUnits.splice(0, 1);
        }
        for (const emptyConnForm of emptyConnFormUnits.reverse()){
            this.removeConnectionPointUnit(emptyConnForm);
        }
    }

    get connectionPointFormArray(): FormArray {
        return this.connectionPointsform.get('connectionPointUnit') as FormArray;
    }

    private setFormValuesFromData() {
        const connectionPointFormModel = new ConnectionPointComponentForm();

        const connPointFormArray = [];
        for (const connectionPointDataUnit of this.connectionPointDataArray) {
            const connPointFormUnit = new ConnectionPointFormGroup();
            connPointFormUnit.connectionpointSelect = connectionPointDataUnit.comparator;
            if (connectionPointDataUnit.inSequence) {
                connPointFormUnit.connectionpointRadio = 'In Sequence';
            } else {
                connPointFormUnit.connectionpointRadio = 'Any';
            }

            const connCityAndTimeFormArray = [];
            for (const connCityAndTimeDataUnit of connectionPointDataUnit.connectionCity) {
                const connCityAndTimeFormUnit = {
                    maxTime: connCityAndTimeDataUnit.time.maximumMinutes ? connCityAndTimeDataUnit.time.maximumMinutes : '',
                    minTime: connCityAndTimeDataUnit.time.minimumMinutes ? connCityAndTimeDataUnit.time.minimumMinutes : '',
                    connectionpointCityFrom: connCityAndTimeDataUnit.airports.arrival ? [connCityAndTimeDataUnit.airports.arrival] : '',
                    connectionpointCityTo: connCityAndTimeDataUnit.airports.departure ? [connCityAndTimeDataUnit.airports.departure] : ''
                } as ConnectionCityAndTimeFormModel;

                connCityAndTimeFormArray.push(connCityAndTimeFormUnit);
            }
            connPointFormUnit.connectionTimeUnit = connCityAndTimeFormArray;
            connPointFormArray.push(connPointFormUnit);
        }
        connectionPointFormModel.connectionPointUnit = connPointFormArray;
        if (connectionPointFormModel) {
            this.setFormValues(connectionPointFormModel);
        }
    }

    private setFormValues(connectionPointFormModel: ConnectionPointComponentForm) {
        const connectionPointFormArrayLength = connectionPointFormModel.connectionPointUnit.length;
        const connPointFormArray = this.connectionPointsform.get('connectionPointUnit') as FormArray;

        let i: number;
        let j: number;

        for (i = 0; i < connectionPointFormArrayLength ; i++ ) {
            connPointFormArray.push(this.createConnPointFormGroup());
        }
        connPointFormArray.removeAt(i);

        // generate fields for orginDestination
        i = 0;
        for (const connPointFormUnit of connectionPointFormModel.connectionPointUnit) {
            j = 0;
            const connCityTimeFormArray = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
            for ( const orginDestination of connPointFormUnit.connectionTimeUnit) {
                connCityTimeFormArray.push(this.createConnCityTimeFormGroup());
                j++;
            }
            this.removeConnectionTimeUnit(i, j);
            i++;
        }
          // Push service response data into generated fields
        (this.connectionPointsform as FormGroup).patchValue(connectionPointFormModel, { onlySelf: true });
    }

    private createConnPointFormGroup() {		// nest
        this.disableButton.push(false);
        return this.fb.group({
            connectionpointSelect: 'EQ',
            connectionpointRadio: ['Any'],
            connectionTimeUnit: this.fb.array([this.createConnCityTimeFormGroup()])
        });
    }
    private addConnectionPointUnit() {
        this.connectionPointFormArray.push(this.createConnPointFormGroup());
    }

    private removeConnectionPointUnit(i: number) {
        this.connectionPointFormArray.removeAt(i);
        this.disableButton.splice(i, 1);
    }

    private createConnCityTimeFormGroup() {
        return this.fb.group({
            connectionpointCityFrom: [[]],
            connectionpointCityTo: [[]],
            minOperator: ['GT'],
            minTime: [],
            maxOperator: ['LT'],
            maxTime: []
        });
    }

    private addConnectionTimeUnit(i: number) {
        const control = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        const radioValue = this.connectionPointFormArray.controls[i].get('connectionpointRadio').value;
        control.push(this.createConnCityTimeFormGroup());
        this.updateDisableButtonState(i, radioValue);
    }

    private removeConnectionTimeUnit(i: number, j: number) {
        const control = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        const radioValue = this.connectionPointFormArray.controls[i].get('connectionpointRadio').value;
        control.removeAt(j);
       // this.removeAddTimeUnit = true;
        this.updateDisableButtonState(i, radioValue);
    }

    private radioClick(i: number, radioValue: string) {
        const radioVal = this.connectionPointFormArray.controls[i].get('connectionpointRadio').value;
        const unit = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        this.updateDisableButtonState(i, radioValue);
    }

    /**
     * Disable the add button if the no of connections is above max limit
     * @param i
     */
    private updateDisableButtonState(i, radioValue): void {
        const connectionPointFormArray = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        const value = radioValue;
        const length = connectionPointFormArray.controls.length;
        this.disableButton[i] = false;
        if (value === 'Any' && this.maxAny && length >= Number(this.maxAny)) {
            this.disableButton[i] = true;
        }else if (value === 'In Sequence' && this.maxInSequence && length >= Number(this.maxInSequence)) {
            this.disableButton[i] = true;
        }
    }

}
