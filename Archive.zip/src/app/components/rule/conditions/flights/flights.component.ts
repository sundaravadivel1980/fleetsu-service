import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { FlightCondition, Flight, Rule } from '@dxc/tr-ux-ace-services/dist/lib';

import { FlightFormGroup,
    FlightComponentForm, RuleDetailChildForm } from '../../../../models/rule-form.model';

import { AutoCompleteChip, ComboBox } from '../../../../models/ui-model';

import { RuleUtil } from '../../rule.util.ts';
import { AppSingletonService } from '../../../../app-singleton.service';
import { GroupType } from '../../../../models/group-type';
import { AppUtil } from '../../../../utility/app-util';
import { REGEX_CONSTANTS } from 'src/app/app.constants';
import { MessageTranslationService } from 'src/app/services/message-translation.service';

@Component({
    selector: 'flights',
    templateUrl: 'flights.component.html',
    styleUrls: ['./flights.component.scss']
})
export class FlightsComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public flightsForm: FormGroup;
    public flightConditionDataArray: FlightCondition[];

    public flightGroupList: AutoCompleteChip[];
    public operators: ComboBox[];
    public flightValid: boolean;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
    }

    public ngOnInit() {

        this.flightGroupList = this.singletonService.flightGroups;

        this.flightsForm = this.fb.group({
            flightLogicalUnits: this.fb.array([this.createFlightFormGroup()])
        });

        this.setValues();
    }

    public addFlightLogicalUnit() {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        flightFormArray.push(this.createFlightFormGroup());
    }

    public removeFlightLogicalUnit(i: number) {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        flightFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.flightConditionDataArray = rule.condition.flightCondition;
        }
        if ( this.flightConditionDataArray && this.flightConditionDataArray.length > 0 ) {
            this.setFormValuesFromData(this.flightConditionDataArray);
        }
    }

    public getValues(): FlightCondition[] {

        this.validate();

        if (this.hasErrors) {
            this.messageService.addErrorWithParam('acegui.rules.messages.form.validatiom.failed', 'Flight condition');
        }

        if (this.isEmptyCondition || this.hasErrors) {
            return null;
        }
        const flightConditionArray = [];
        for (const flightFormUnit of this.flightFormArray.value) {
            const flightArray = [];
            if (flightFormUnit.flightNumbers) {
                flightFormUnit.flightNumbers.forEach ( flightNumber => {
                const flghtNumberArray = flightNumber.split('-');
                if (flghtNumberArray[1]) {
                    flightArray.push( {
                    startFlight: flghtNumberArray[0],
                    endFlight: flghtNumberArray[1]
                    } as Flight );
                } else {
                    flightArray.push({
                    startFlight: flghtNumberArray[0]
                    } as Flight);
                }
                });
            }

            const flightCondition = {
                comparator: flightFormUnit.operator,
                flight: flightArray,
                flightGrouping: flightFormUnit.flightGroups ? flightFormUnit.flightGroups : []
            } as FlightCondition;

            flightConditionArray.push(flightCondition);
        }
        return flightConditionArray;
    }

    get flightFormArray(): FormArray{
        return this.flightsForm.get('flightLogicalUnits') as FormArray;
    }

    public validate() {
       this.removeEmptyForms();
       this.hasErrors = false;

       for (const flightLogicalUnit of this.flightFormArray.controls) {
         // Check is there any field level errors.
         if (flightLogicalUnit.status.toLowerCase() === 'invalid') {
            this.hasErrors = true;
        }
       }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const flightLogicalUnit of this.flightFormArray.controls) {
            let emptyForm = true;
            if (AppUtil.isArrayValueExists(flightLogicalUnit, 'flightNumbers')
                || AppUtil.isArrayValueExists(flightLogicalUnit, 'flightGroups')) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()){
            this.removeFlightLogicalUnit(emptyFormGroup);
        }
        if (this.flightFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addFlightLogicalUnit();
        }
    }

    private setFormValuesFromData(flightConditionDataArray: FlightCondition[]) {
        const flightFormArray = [];

        for (const flightConditionDataUnit of flightConditionDataArray) {
            const flightFormUnit = {} as FlightFormGroup;
            flightFormUnit.operator = flightConditionDataUnit.comparator;
            const flightNumbers = [];
            if (flightConditionDataUnit.flight) {
                for  (const flight of flightConditionDataUnit.flight) {
                    if  ( flight.hasOwnProperty('startFlight')  &&  flight.hasOwnProperty('endFlight') ) {
                        if (flight.startFlight && flight.endFlight) {
                            flightNumbers.push(flight.startFlight +  '-'  +  flight.endFlight);
                        } else if (flight.startFlight) {
                            flightNumbers.push(flight.startFlight.toString());
                        }
                    } else  if  (flight.hasOwnProperty('startFlight')) {
                        if (flight.startFlight) {
                            flightNumbers.push(flight.startFlight.toString());
                        }
                    }
                }
            }
            flightFormUnit.flightNumbers = flightNumbers;
            flightFormUnit.flightGroups = AppUtil.numberToStringArray(flightConditionDataUnit.flightGrouping);
            flightFormArray.push(flightFormUnit);
        }

        const flightComponentFormModel = {
            flightLogicalUnits: flightFormArray
        } as FlightComponentForm;

        if (flightComponentFormModel) {
            this.setFormValues(flightComponentFormModel);
        }
    }

    private setFormValues(flightComponentFormModel: FlightComponentForm) {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        for (const flightFormUnit of flightComponentFormModel.flightLogicalUnits){
            flightFormArray.push(this.createFlightFormGroup());
        }
        this.removeFlightLogicalUnit(0);
        (this.flightsForm as FormGroup).patchValue(flightComponentFormModel, { onlySelf: true });
    }

    private createFlightFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            flightNumbers: ['', this.validateFlightNumber],
            flightGroups: ''
        });
    }

    /**
     * User can specify a flight number range by inputting two numbers separated by a dash, for
     * example 123-456. Again, in flight number ranges, range start and end flight numbers are
     * tested to be a numeric value of 1 to 4 digits but are not verified against any schedule data.
     *
     * @param formGroup
     */
    private validateFlightNumber(formGroup: FormGroup) {
        if (formGroup.value) {
            for (const val of formGroup.value) {
                const rangeRegex = REGEX_CONSTANTS.RANGE_9999;
                const numberRegex = REGEX_CONSTANTS.NUMBER_9999;
                // Checks if the value is whole number or in the range (1-999)
                if (!val.match(rangeRegex) && !val.match(numberRegex)) {
                    return { parseError: true, errorMsg: 'acegui.rules.messages.flights.range'};
                }
                // Check if the start value is less than the end value
                if (val.match(rangeRegex)) {
                    if (Number(val.split('-')[0]) > Number(val.split('-')[1])) {
                        return { parseError: true, errorMsg: 'acegui.rules.messages.start.end.mismatch' };
                    }
                }
            }
        }
    }
}
