import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl, FormGroupDirective, NgForm } from '@angular/forms';

import { Rule, LoadFactorCondition, OriginDestination } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    LoadFactorFormGroup,
    LFComponentFormModel,
    OriginDestinationFormGroup,
    RuleDetailChildForm
} from '../../../../models/rule-form.model';

import {
   ComboBox, AutoCompleteChip, IdValue
} from '../../../../models/ui-model';

import { RuleUtil } from '../../rule.util.ts';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';

import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AbstractControl } from '@angular/forms/src/model';
import { AppValidator } from 'src/app/validators/app-validator';
import { REGEX_CONSTANTS } from 'src/app/app.constants';

@Component({
    selector: 'load-factor',
    templateUrl: 'load-factor.component.html',
    styleUrls: ['./load-factor.component.scss']
})

export class LoadFactorComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public LdFactorForm: FormGroup;

    public cabins: ComboBox[];
    public operators: ComboBox[];
    private listOfAirport: AutoCompleteChip[];

    // Will be true if there is no input value given by the user for class availability condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    private loadFactorComponentData: LoadFactorCondition[];

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        const data = singletonService.ruleJsonStore;
        this.operators = singletonService.ruleJsonStore.LoadfactorOperators;
    }

    public ngOnInit() {
        this.cabins = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.listOfAirport = this.singletonService.getCombinedAirportsAndLocations();

        this.LdFactorForm = this.fb.group({ LoadFactor: this.fb.array([this.createLoadFactorLogicalUnit()]) });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.loadFactorComponentData = rule.condition.loadFactorCondition;
        }
        if (this.loadFactorComponentData && this.loadFactorComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): LoadFactorCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam('acegui.rules.messages.form.validatiom.failed', 'Load factor condition');
            return null;
        }

        const loadFactorConditionArray = [];
        for (const ldFactorFormUnit of this.ldFormArray.value) {
            const ldFactorOriginDestFormArray = [];
            for (const originDestFormUnit of ldFactorFormUnit.originDestinations) {
                const originDestinationData = RuleUtil.splitAirportAndLocationGroup(originDestFormUnit);
                ldFactorOriginDestFormArray.push(originDestinationData);
            }

            const loadFactorCondition = new LoadFactorCondition();
            loadFactorCondition.comparator = ldFactorFormUnit.actual;
            loadFactorCondition.cabin = [ldFactorFormUnit.cabin];
            const actualInput = ldFactorFormUnit.actualInput.split('-');
            loadFactorCondition.startPercent = actualInput[0];
            if (actualInput[1]) {
                loadFactorCondition.endPercent = actualInput[1];
            }
            loadFactorCondition.leg = ldFactorOriginDestFormArray;
            loadFactorConditionArray.push(loadFactorCondition);
        }
        return loadFactorConditionArray;
    }

    get ldFormArray(): FormArray {
        return this.LdFactorForm.get('LoadFactor') as FormArray;
    }

    public isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
        return !!(control && control.invalid && (control.dirty || control.touched));
    }

    public addLoadFactorLogicalUnit() {
        const control = this.LdFactorForm.get('LoadFactor') as FormArray;
        control.push(this.createLoadFactorLogicalUnit());
    }

    public removeLoadFactorLogicalUnit(i: number) {
        const control = this.LdFactorForm.get('LoadFactor') as FormArray;
        control.removeAt(i);
    }

    public validateOriginAndDestination(originAndDestFormArray: FormArray) {
        let j: number = 0;
        const removeLocationGroups = [];
        for (const loadFactorLogicalUnitLeg of originAndDestFormArray.controls) {
            if (loadFactorLogicalUnitLeg.get('origin').value.length === 0 &&
                loadFactorLogicalUnitLeg.get('destination').value.length === 0) {
                removeLocationGroups.push(j);
            }
            j++;
        }

        return removeLocationGroups.reverse();
    }

    public validate() {

        this.removeEmptyForms();
        const validator = new AppValidator();
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const loadFactorFormUnit of this.ldFormArray.controls) {
                // Set the cabin and load factor value as required and trigger the field validation to show the red border
                if (!loadFactorFormUnit.get('cabin').value && !loadFactorFormUnit.get('actualInput').value) {
                    validator.setRequired(loadFactorFormUnit.get('cabin'));
                    validator.setRequired(loadFactorFormUnit.get('actualInput'));
                    this.hasErrors = true;
                } else if (!loadFactorFormUnit.get('cabin').value) {
                    validator.setRequired(loadFactorFormUnit.get('cabin'));
                    this.hasErrors = true;
                } else if (!loadFactorFormUnit.get('actualInput').value) {
                    validator.setRequired(loadFactorFormUnit.get('actualInput'));
                    this.hasErrors = true;
                }

                // Check is there any field level errors.
                if (loadFactorFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyLoadFactorFormUnits = [];
        this.isEmptyCondition = false;

        for (const loadFactorFormUnit of this.ldFormArray.controls) {
            const originAndDestFormUnitArray = loadFactorFormUnit.get('originDestinations') as FormArray;

            let emptyOriginAndDestForm = false;
            const emptyOriginAndDestFormUnitArray = this.validateOriginAndDestination(originAndDestFormUnitArray);
            if (originAndDestFormUnitArray.controls.length === emptyOriginAndDestFormUnitArray.length) {
                emptyOriginAndDestForm = true;
                emptyOriginAndDestFormUnitArray.splice(0, 1);
            }

            for (const emptyOriginDestFormUnit of emptyOriginAndDestFormUnitArray) {
                this.removeOriginDestFormGroup(i, emptyOriginDestFormUnit);
            }

            let emptyForm = true;
            if (loadFactorFormUnit.get('cabin').value
                || loadFactorFormUnit.get('actualInput').value
                || !emptyOriginAndDestForm) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyLoadFactorFormUnits.push(i);
            }

            i++;
        }

        if (this.ldFormArray.controls.length === emptyLoadFactorFormUnits.length) {
            this.isEmptyCondition = true;
            emptyLoadFactorFormUnits.splice(0, 1);
        }
        for (const emptyLdFactorForm of emptyLoadFactorFormUnits.reverse()) {
            this.removeLoadFactorLogicalUnit(emptyLdFactorForm);
        }
    }

    private setFormValuesFromData() {
        const loadFactorFormModel = new LFComponentFormModel();
        const loadFactorFormArray = [];

        for (const loadFactorData of this.loadFactorComponentData) {
            const ldFacorFormUnit = new LoadFactorFormGroup();
            ldFacorFormUnit.cabin = loadFactorData.cabin[0];
            ldFacorFormUnit.actual = String(loadFactorData.comparator);

            if (loadFactorData.startPercent && loadFactorData.endPercent) {
                ldFacorFormUnit.actualInput = loadFactorData.startPercent + '-' + loadFactorData.endPercent;
            } else {
                ldFacorFormUnit.actualInput = String(loadFactorData.startPercent);
            }

            const originAndDestFormArray = [];
            for (const loadFactorLegData of loadFactorData.leg) {
                const originDestFormUnit = RuleUtil.combineLocationGroupAndAirport(loadFactorLegData);
                originAndDestFormArray.push(originDestFormUnit);
            }

            ldFacorFormUnit.originDestinations = originAndDestFormArray;
            loadFactorFormArray.push(ldFacorFormUnit);
        }
        loadFactorFormModel.LoadFactor = loadFactorFormArray;

        if (loadFactorFormModel) {
            this.setFormValues(loadFactorFormModel);
        }
    }

    private setFormValues(ldFactorFormModel: LFComponentFormModel) {

        let i: number;
        let j: number;

        const loadFactorFormArrayLength = ldFactorFormModel.LoadFactor.length;
        const ldFactorFormArray = this.LdFactorForm.get('LoadFactor') as FormArray;

        // generate fields for marketLogic Unit
        for (i = 0; i < loadFactorFormArrayLength; i++) {
            ldFactorFormArray.push(this.createLoadFactorLogicalUnit());
        }

        ldFactorFormArray.removeAt(i);

        // generate fields for orginDestination
        i = 0;
        for (const ldFactorFormUnit of ldFactorFormModel.LoadFactor) {
            j = 0;
            const originDestFormArray = this.ldFormArray.controls[i].get('originDestinations') as FormArray;
            for (const originDestFormUnit of ldFactorFormUnit.originDestinations) {
                originDestFormArray.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j);
            i++;
        }
        // Push service response data into generated fields
        (this.LdFactorForm as FormGroup).patchValue(ldFactorFormModel, { onlySelf: true });
    }

    private createLoadFactorLogicalUnit() {
        return this.fb.group({
            cabin: [''],
            actual: ['EQ'],
            actualInput: ['', this.validateLoadFactor],
            originDestinations: this.fb.array([this.createOriginDestFormGroup()])
        });
    }

    /**
     * The user can specify load factor as a whole number (e.g. 75) or as a range of whole
     * numbers (e.g. 90 – 110). Numbers allowed are 0 – 999 (whole numbers, no decimal point).
     *
     * @param formGroup
     */
    private validateLoadFactor(formGroup: FormGroup) {
        if (formGroup.value) {
            // To check the range is between 0 to 999
            const value = formGroup.value;
            const rangeRegex = REGEX_CONSTANTS.RANGE_999;
            const numberRegex = REGEX_CONSTANTS.NUMBER_999;
            // Checks if the value is whole number or in the range (1-999)
            if (!value.match(rangeRegex) && ! value.match(numberRegex)) {
                return { parseError: true, errorMsg: 'acegui.rules.messages.load.factor.range' };
            }
            // Check if the start value is less than the end value
            if (value.match(rangeRegex)) {
                if (Number(value.split('-')[0]) > Number(value.split('-')[1])) {
                    return { parseError: true, errorMsg: 'acegui.rules.messages.start.end.mismatch' };
                }
            }
        }
    }

    private createOriginDestFormGroup() {
        return this.fb.group({
            origin: [''],
            destination: ['']
        });
    }

    private addOriginDestFormGroup(j: number) {
        const control = this.LdFactorForm.get('LoadFactor')['controls'][j].get('originDestinations') as FormArray;
        control.push(this.createOriginDestFormGroup());
    }

    private removeOriginDestFormGroup(j: number, i: number) {
        const control = this.LdFactorForm.get('LoadFactor')['controls'][j].get('originDestinations') as FormArray;
        control.removeAt(i);
    }

}
