import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { ChangeDetectorRef } from '@angular/core';

import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, BidPriceActionInput, Categories, BidPriceSeat, ClassCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import {
    RuleDetailChildForm,
    BidPriceAdjustmentComponentForm,
    BidPriceAdjustmentFormGroup, BidSeat
} from '../../../../models/rule-form.model';
import {
    ComboBox, AutoCompleteChip, IdValue
} from '../../../../models/ui-model';
import { CarrierConfig } from '../../../../models/carrier-config';
import { RuleUtil } from '../../rule.util.ts';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/observable';

import { AppState, PostModel } from '../../../../state-management/app-store.model';
import * as AppStoreActions from '../../../../state-management/app-store.action';
import { OnDestroy, AfterViewInit, DoCheck } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { AppValidator } from 'src/app/validators/app-validator';
import { RuleDetailFieldValidator } from 'src/app/validators/rule/rule-detail-field-validator';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector: 'bid-price-adjustment',
    templateUrl: 'bid-price-adjustment.component.html',
    styleUrls: ['./bid-price-adjustment.component.scss']
})

export class BidPriceAdjustmentComponent implements RuleDetailChildForm, OnInit, OnDestroy {

    @Input() public childInput: Rule;
    public bidPriceAdjustmentForm: FormGroup;

    public cabins: IdValue[];
    public categorys: ComboBox[];
    public gsaOperator: ComboBox[];
    public gsaRangeOperator: ComboBox[];
    public enableBidPriceCategory: boolean;
    public carrierPrefCurrency: string;
    public disableGSA: boolean = true;
    private cabinClassesInput: IdValue[];
    private cabinViewData: any;
    private commonFieldValidator = new RuleDetailFieldValidator();
    private bidPriceAdjustmentData: BidPriceActionInput;
    private carrierPrefPercentage: string;
    private carrierPrefAmount: string;
    private carrierPrefDecimal: string;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;
    private marketLegSelectionSubscription: Subscription;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private cdRef: ChangeDetectorRef,
                private messageService: MessageTranslationService,
                private appStore: Store<AppState>) {
        this.gsaRangeOperator = singletonService.ruleJsonStore.Operators;
        this.gsaOperator = singletonService.ruleJsonStore.SeatsOperators;
        // will be removed. there is no category
        this.categorys = singletonService.ruleJsonStore.BidPriceCategory;
        this.enableBidPriceCategory = false;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.carrierPrefCurrency = this.singletonService.carrierCurrency;
        this.carrierPrefPercentage =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.PERCENTAGE_RESTRICTION, this.singletonService.carrierPreferences);
        this.carrierPrefAmount =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.AMOUNT_RESTRICTION, this.singletonService.carrierPreferences);
        this.carrierPrefDecimal =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.AMOUNT_DECIMAL_RESTRICTION, this.singletonService.carrierPreferences);
        this.bidPriceAdjustmentForm = this.fb.group({
            bidPriceAdjustmentUnit: this.fb.array([this.createBidPriceAdjustFormGroup()])
        });
        this.setValues();
    }

    public ngOnDestroy() {
        // to prevent memory leak
        this.marketLegSelectionSubscription.unsubscribe();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.bidPriceAdjustmentData = rule.action.bidPriceAdjustmentActionInput;
        }
        if (this.bidPriceAdjustmentData) {
            this.setFormValuesFromData();
            // If O&D is selected then disable the GSA fields
            const legOrOAndD = rule.action.bidPriceAdjustmentActionInput.adjustLeg ? 'LEG' : 'O&D';
            this.appStore.dispatch(new AppStoreActions.MarketLegOrOD(legOrOAndD));
        } else {
            // For the new rule, O&D is the default one
            this.appStore.dispatch(new AppStoreActions.MarketLegOrOD('LEG'));
        }

        // Listen to the appstore for the changes, and enable/disable GSA fields
        this.subscribeLegSelectionInMarketComponent();
    }

    public getValues(): BidPriceActionInput {
        this.validate();

        if (this.hasErrors) {
            return null;
        }

        const dataArray = [];
        for (const bidPriceFormUnit of this.bidPriceFormArray.value) {
            const bidPriceAdjustActionInput = new BidPriceActionInput();
            const bidSeats = [];
            if (bidPriceFormUnit.gsaGroupUnit) {
                for (const gsaFormUnit of bidPriceFormUnit.gsaGroupUnit) {
                    const bidSeat = new BidPriceSeat();
                    if (gsaFormUnit.gsaNumber) {
                        bidSeat.startSeat = gsaFormUnit.gsaNumber;
                        bidSeat.seatsRestriction = bidSeat.startSeat ? gsaFormUnit.gsaOperator : '';
                        bidSeats.push(bidSeat);
                    } else if (gsaFormUnit.gsaRange) {
                        const gsaRangeArray = gsaFormUnit.gsaRange.split('-');
                        if (gsaRangeArray[1]) {
                            bidSeat.startSeat = gsaRangeArray[0];
                            bidSeat.endSeat = gsaRangeArray[1];
                        } else {
                            bidSeat.startSeat = gsaRangeArray[0];
                        }
                        bidSeat.seatsRestriction = bidSeat.startSeat ? gsaFormUnit.gsaRangeOperator : '';
                        bidSeats.push(bidSeat);
                    }
                }
            }

            bidPriceAdjustActionInput.bidPrice = bidPriceFormUnit.bidPrice;

            if (bidPriceFormUnit.amount) {
                // Prefix with + when user forgot to provide the + or -
                bidPriceAdjustActionInput.changeAmount =
                (bidPriceFormUnit.amountSign ? bidPriceFormUnit.amountSign : '+' ) + bidPriceFormUnit.amount;
            }
            bidPriceAdjustActionInput.changePercent = bidPriceFormUnit.numbers ? bidPriceFormUnit.numbersSign + bidPriceFormUnit.numbers : '';
            bidPriceAdjustActionInput.maximum = bidPriceFormUnit.maxAmount;
            bidPriceAdjustActionInput.minimum = bidPriceFormUnit.minAmount;
            bidPriceAdjustActionInput.seats = bidSeats;
            bidPriceAdjustActionInput.cabin = bidPriceFormUnit.cabinClasses;
            dataArray.push(bidPriceAdjustActionInput);
        }
        return dataArray[0];
    }

    public validate() {
        this.removeEmptyForms();
        this.hasErrors = false;

        const validator = new AppValidator();

        if (this.isEmptyCondition) {
            this.messageService.addError('acegui.rules.messages.bid.price.condition.required');
            this.hasErrors = true;
        } else {
            for (const bidPriceFormUnit of this.bidPriceFormArray.controls) {
                const gsaGroupUnit = bidPriceFormUnit.get('gsaGroupUnit') as FormArray;
                let emptyGSAForm = true;
                for (const gsaGroupUnitData of gsaGroupUnit.controls) {
                    if (gsaGroupUnitData.value.gsaNumber || gsaGroupUnitData.value.gsaRange) {
                        emptyGSAForm = false;
                    }
                }
                if (!bidPriceFormUnit.value.amount
                    && !bidPriceFormUnit.value.numbers
                    && !bidPriceFormUnit.value.bidPrice
                    && !bidPriceFormUnit.value.maxAmount
                    && !bidPriceFormUnit.value.minAmount) {
                    // Bid Price (or) Amount/Percentage/Mininum/Maximum is required
                    this.messageService.addError('acegui.rules.messages.bid.price.condition.required');
                    this.hasErrors = true;
                }  else {
                    if (bidPriceFormUnit.value.cabinClasses.length === 0) {
                        // cabin is required
                        validator.setRequired(bidPriceFormUnit.get('cabinClasses'));
                    }
                    if (bidPriceFormUnit.status.toLowerCase() === 'invalid') {
                        this.messageService.addErrorWithParam(
                        'acegui.rules.messages.form.validatiom.failed', 'Bid price adjustment');
                        this.hasErrors = true;
                    }
                }

            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyBidPriceGroups = [];
        this.isEmptyCondition = false;
        let subscribeAgain = false;

        for (const bidPriceFormUnit of this.bidPriceFormArray.controls) {
            const gsaGroupUnit = bidPriceFormUnit.get('gsaGroupUnit') as FormArray;
            let j: number = 0;
            const emptyGSAUnitGroups = [];
            for (const gsaGroupUnitData of gsaGroupUnit.controls) {
                let emptyGsaGroup = true;
                if (gsaGroupUnitData.value.gsaNumber || gsaGroupUnitData.value.gsaRange) {
                        emptyGsaGroup = false;
                }
                if (emptyGsaGroup) {
                    emptyGSAUnitGroups.push(j);
                }
                j++;
            }
            for (const emptyGSAGroup of emptyGSAUnitGroups.reverse()) {
                this.removeGsaGroupUnit(i, emptyGSAGroup);
            }

            let emptyGSAForm = false;
            if (gsaGroupUnit.length === 0) {
                emptyGSAForm = true;
                this.addGsaGroupUnit(i);
                subscribeAgain = true;
            }

            let emptyBidPriceForm = true;
            if (!emptyGSAForm || bidPriceFormUnit.value.numbers || bidPriceFormUnit.value.amount || bidPriceFormUnit.value.bidPrice
                || bidPriceFormUnit.value.maxAmount || bidPriceFormUnit.value.minAmount) {
                    emptyBidPriceForm = false;
            }

            if (emptyBidPriceForm) {
                emptyBidPriceGroups.push(i) ;
            }
            i++;
        }
        for (const emptyGroup of emptyBidPriceGroups.reverse()) {
            this.removeBidPriceAdjustmentUnit(emptyGroup);
        }
        if (this.bidPriceFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addBidPriceAdjustmentUnit();
            subscribeAgain = true;
        }

        if ( subscribeAgain ) {
            this.subscribeLegSelectionInMarketComponent();
        }
    }

    public enableDisableFields(value) {
        const fieldsList = ['amount', 'numbers', 'numbersSign', 'amountSign', 'minAmount', 'maxAmount'];
        if (value === '') {
            for (const field of fieldsList) {
                // this.bidPriceFormArray.controls[0].get(field).reset();
                this.bidPriceFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.bidPriceFormArray.controls[0].get(field).reset();
                this.bidPriceFormArray.controls[0].get(field).disable();
            }
        }
    }

    /**
     * When user type in the number text field, then it will disable the range field.
     * Vice-versa.
     * Number and range both are not allowed
     */
    public enableDisableGSARange(value, disableField: string, i: number, j: number) {
        const gsaUnit = this.bidPriceFormArray.controls[i].get('gsaGroupUnit') as FormArray;
        if (disableField === 'number') {
            gsaUnit.controls[j].get('gsaRange').disable();
            gsaUnit.controls[j].get('gsaRangeOperator').disable();
            gsaUnit.controls[j].get('gsaNumber').enable();
            gsaUnit.controls[j].get('gsaOperator').enable();
            if (value === '') {
                gsaUnit.controls[j].get('gsaRange').enable();
                gsaUnit.controls[j].get('gsaRangeOperator').enable();
            }
        } else if (disableField === 'range') {
            gsaUnit.controls[j].get('gsaRange').enable();
            gsaUnit.controls[j].get('gsaRangeOperator').enable();
            gsaUnit.controls[j].get('gsaNumber').disable();
            gsaUnit.controls[j].get('gsaOperator').disable();
            if (value === '') {
                gsaUnit.controls[j].get('gsaNumber').enable();
                gsaUnit.controls[j].get('gsaOperator').enable();
            }
        }
    }

    get bidPriceFormArray(): FormArray {
        return this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
    }

    private createBidPriceAdjustFormGroup() {
        return this.fb.group({
            cabinClasses: '',
            amount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            numbers: ['', this.commonFieldValidator.validateNumberRange(this.carrierPrefPercentage)],
            amountSign: '',
            numbersSign: '',
            minAmount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            maxAmount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            bidPrice: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            gsaGroupUnit: this.fb.array([this.createGsaFormGroup()])
        });
    }

    private addBidPriceAdjustmentUnit() {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        control.push(this.createBidPriceAdjustFormGroup());
    }

    private removeBidPriceAdjustmentUnit(i: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        control.removeAt(i);
    }

    get bidPriceUnit(): FormArray {
        return this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
    }

    private createGsaFormGroup() {
        return this.fb.group({
            gsaNumber: '',
            gsaRange: ['', this.commonFieldValidator.validateGSARange],
            gsaOperator: 'EQ',
            gsaRangeOperator: 'EQ'
        });
    }

    private addGsaGroupUnit(j: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit')['controls'][j].get('gsaGroupUnit') as FormArray;
        control.push(this.createGsaFormGroup());
    }

    private removeGsaGroupUnit(j: number, i: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit')['controls'][j].get('gsaGroupUnit') as FormArray;
        control.removeAt(i);
    }

    private selectAll(i: number) {
        const fields = this.categorys;
        const all = 'all';
        for (const item of fields) {
            this.bidPriceUnit['controls'][i].get(item.id).setValue(
                this.bidPriceUnit['controls'][i].get(all).value
            );
        }

    }
    private checkIfAllSelected(i: number) {
        const fields = this.categorys;
        const all = 'all';
        const chkAll = [];
        for (const item of fields) { chkAll.push(this.bidPriceUnit['controls'][i].get(item.id).value); }
        const selectAll = chkAll.every(function(item: boolean) { return item === true; });
        this.bidPriceUnit['controls'][i].get(all).setValue(selectAll);
    }

    private setFormValuesFromData() {
        const bidPriceAdjustmentFromModelGroupData = [];
        if (this.bidPriceAdjustmentData) {
            const bidPriceAdjustmentFromModelGroup = {} as BidPriceAdjustmentFormGroup;
            if (this.bidPriceAdjustmentData.bidPrice) {
                bidPriceAdjustmentFromModelGroup.bidPrice = this.bidPriceAdjustmentData.bidPrice;
            }
            if (this.bidPriceAdjustmentData.minimum) {
                bidPriceAdjustmentFromModelGroup.minAmount = this.bidPriceAdjustmentData.minimum;
            }
            if (this.bidPriceAdjustmentData.maximum) {
                bidPriceAdjustmentFromModelGroup.maxAmount = this.bidPriceAdjustmentData.maximum;
            }
            if (this.bidPriceAdjustmentData.changeAmount) {
                bidPriceAdjustmentFromModelGroup.amount = Math.abs(this.bidPriceAdjustmentData.changeAmount);
            }
            if (this.bidPriceAdjustmentData.changeAmount) {
                bidPriceAdjustmentFromModelGroup.amountSign = this.bidPriceAdjustmentData.changeAmount > 0 ? '+' : '-';
            }
            if (this.bidPriceAdjustmentData.changePercent) {
                bidPriceAdjustmentFromModelGroup.numbersSign = this.bidPriceAdjustmentData.changePercent > 0 ? '+' : '-';
            }
            if (this.bidPriceAdjustmentData.changePercent) {
                bidPriceAdjustmentFromModelGroup.numbers = Math.abs(this.bidPriceAdjustmentData.changePercent);
            }
            if (this.bidPriceAdjustmentData.bidPrice) {
                this.enableDisableFields(this.bidPriceAdjustmentData.bidPrice);
            }
            const bidPriceSeats = [];
            if (this.bidPriceAdjustmentData.seats) {
                for (const bidSeats of this.bidPriceAdjustmentData.seats) {
                    const bidPriceSeat = {} as BidSeat;
                    if (bidSeats.endSeat) {
                        bidPriceSeat.gsaRange = bidSeats.startSeat + '-' + bidSeats.endSeat;
                        bidPriceSeat.gsaRangeOperator = bidSeats.seatsRestriction;
                    } else {
                        bidPriceSeat.gsaNumber = bidSeats.startSeat;
                        bidPriceSeat.gsaOperator = bidSeats.seatsRestriction;
                    }
                    bidPriceSeats.push(bidPriceSeat);
                }
            } else {
                const bidPriceSeat = {} as BidSeat;
                bidPriceSeats.push(bidPriceSeat);
            }
            this.cabinViewData = this.bidPriceAdjustmentData.cabin;
            bidPriceAdjustmentFromModelGroup.gsaGroupUnit = bidPriceSeats;
            bidPriceAdjustmentFromModelGroupData.push(bidPriceAdjustmentFromModelGroup);
        }

        const bidPriceAdjustmentFromModel = {
            bidPriceAdjustmentUnit: bidPriceAdjustmentFromModelGroupData
        } as BidPriceAdjustmentComponentForm;

        if (bidPriceAdjustmentFromModel) {
            this.setFormValues(bidPriceAdjustmentFromModel);
        }
    }

    private setFormValues(bidPriceAdjustmentFromModel: BidPriceAdjustmentComponentForm) {
        const bidPriceAdjustmentUnitLength = bidPriceAdjustmentFromModel.bidPriceAdjustmentUnit.length;
        const controlBidPriceAdjustmentUnit = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        let i: number;
        let j: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < bidPriceAdjustmentUnitLength; i++) {
            controlBidPriceAdjustmentUnit.push(this.createBidPriceAdjustFormGroup());
        }
        controlBidPriceAdjustmentUnit.removeAt(i);
        i = 0;
        for (const bidPriceAdjustmentUnit of bidPriceAdjustmentFromModel.bidPriceAdjustmentUnit) {
            j = 0;
            const controlGsaGroupUnit = this.bidPriceUnit.controls[i].get('gsaGroupUnit') as FormArray;
            for (const gsaGroupUnit of bidPriceAdjustmentUnit.gsaGroupUnit) {
                if (gsaGroupUnit.gsaNumber) {
                    controlGsaGroupUnit.controls[j].get('gsaRange').disable();
                    controlGsaGroupUnit.controls[j].get('gsaRangeOperator').disable();
                } else if (gsaGroupUnit.gsaRange) {
                    controlGsaGroupUnit.controls[j].get('gsaNumber').disable();
                    controlGsaGroupUnit.controls[j].get('gsaOperator').disable();
                }
                controlGsaGroupUnit.push(this.createGsaFormGroup());
                j++;
            }
            this.removeGsaGroupUnit(i, j);
            i++;
        }
        (this.bidPriceAdjustmentForm as FormGroup).patchValue(bidPriceAdjustmentFromModel, { onlySelf: true });
        this.bidPriceFormArray.controls[0].get('cabinClasses').setValue(this.cabinViewData);
    }

    /**
     * This will listen to the O&D boolean flag selection in the market section.
     * When user selected the 'Adjust Leg', then the GSA fields will be visible.
     * GSA fields not applicable to 'Adjust O&D' price
     */
    private subscribeLegSelectionInMarketComponent() {
        // Enabling Disabling GSA based on AppStore MarketLegOrOD data
        this.disableGSA = true;
        const appStoreData: Observable<PostModel> = this.appStore.select('post');
        this.marketLegSelectionSubscription = appStoreData.subscribe(data => {
            if (data.marketLegOrOD === 'O&D' ) {
                this.disableGSAFields();
            } else if (data.marketLegOrOD === 'LEG' ) {
                this.enableGSAFields();
            }
        });
    }

    private disableGSAFields() {
        const gsaUnits = this.bidPriceFormArray['controls'][0].get('gsaGroupUnit')['controls'];
        const gsaControl = this.bidPriceFormArray['controls'][0].get('gsaGroupUnit') as FormArray;
        let j = 0;
        for (const control of gsaUnits) {
            gsaControl.controls[j].get('gsaRange').reset();
            gsaControl.controls[j].get('gsaRangeOperator').setValue('EQ');
            gsaControl.controls[j].get('gsaNumber').reset();
            gsaControl.controls[j].get('gsaOperator').setValue('EQ');
            gsaControl.controls[j].get('gsaRange').disable();
            gsaControl.controls[j].get('gsaRangeOperator').disable();
            gsaControl.controls[j].get('gsaNumber').disable();
            gsaControl.controls[j].get('gsaOperator').disable();
            this.disableGSA = true;
            j++;
        }
    }

    private numberPercentageDisable(value, index, args) {
        if (value === '') {
            this.bidPriceFormArray.controls[index].get(args).enable();
            this.bidPriceFormArray.controls[index].get(args + 'Sign').enable();
        } else {
            this.bidPriceFormArray.controls[index].get(args).reset();
            this.bidPriceFormArray.controls[index].get(args + 'Sign').reset();
            this.bidPriceFormArray.controls[index].get(args + 'Sign').disable();
            this.bidPriceFormArray.controls[index].get(args).disable();
        }

    }

    private enableGSAFields() {
        const gsaUnits = this.bidPriceFormArray['controls'][0].get('gsaGroupUnit')['controls'];
        const gsaControl = this.bidPriceFormArray['controls'][0].get('gsaGroupUnit') as FormArray;
        let j = 0;
        for (const control of gsaUnits) {
            if (gsaControl.controls[j].get('gsaRange').value) {
                gsaControl.controls[j].get('gsaRange').enable();
                gsaControl.controls[j].get('gsaRangeOperator').enable();
                gsaControl.controls[j].get('gsaNumber').disable();
                gsaControl.controls[j].get('gsaOperator').disable();
            } else if (gsaControl.controls[j].get('gsaNumber').value) {
                gsaControl.controls[j].get('gsaNumber').enable();
                gsaControl.controls[j].get('gsaOperator').enable();
                gsaControl.controls[j].get('gsaRange').disable();
                gsaControl.controls[j].get('gsaRangeOperator').disable();
            } else {
                gsaControl.controls[j].get('gsaRange').enable();
                gsaControl.controls[j].get('gsaRangeOperator').enable();
                gsaControl.controls[j].get('gsaNumber').enable();
                gsaControl.controls[j].get('gsaOperator').enable();
            }
            this.disableGSA = false;
            j++;
        }
    }

}
