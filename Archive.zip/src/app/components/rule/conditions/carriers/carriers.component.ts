import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { CarrierComponentForm, CarrierFormGroup } from '../../../../models/rule-form.model';
import { CarrierCondition, Rule } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm } from '../../../../models/rule-form.model';
import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppUtil } from '../../../../utility/app-util';

@Component({
    selector: 'carriers',
    templateUrl: 'carriers.component.html',
    styleUrls: ['./carriers.component.scss']
})
export class CarriersComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public carriersForm: FormGroup;
    private carrierConditionDataArray: CarrierCondition[];

    private carriersList: AutoCompleteChip[];
    private operators: ComboBox[];

    private isEmptyCondition: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
    }

    public ngOnInit() {

        this.carriersList = this.singletonService.getCombinedCarrierAndCarrierGroups();

        this.carriersForm = this.fb.group({
            carrierLogicalUnits: this.fb.array([this.createCarrierFormGroup()])
        });

        this.setValues();
    }

    get carriersFormArray(): FormArray {
        return this.carriersForm.get('carrierLogicalUnits') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.carrierConditionDataArray = rule.condition.carrierCondition;
        }
        if (this.carrierConditionDataArray && this.carrierConditionDataArray.length > 0) {
            this.setFormValuesFromData(this.carrierConditionDataArray);
        }
    }

    public validate() {
       this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const carrierFormUnit of this.carriersFormArray.controls) {
            let emptyForm = true;
            if (AppUtil.isArrayValueExists(carrierFormUnit, 'marketing')
              || AppUtil.isArrayValueExists(carrierFormUnit, 'operating')) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i) ;
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()) {
            this.removeCarrierFormGroup(emptyFormGroup);
        }
        if (this.carriersFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addCarrierFormGroup();
        }
    }

    public getValues(): CarrierCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }
        const carrierConditionArray = [];
        for (const carrierFormUnit of this.carriersFormArray.value) {
            const carrierCondition = new CarrierCondition();
            carrierCondition.comparator = carrierFormUnit.operator;
            if (carrierFormUnit.marketing && carrierFormUnit.marketing.length > 0) {
                const returnedObject =  RuleUtil.splitGroupAndNonGroup(carrierFormUnit.marketing);
                if (returnedObject && returnedObject.groupArray.length > 0) {
                    carrierCondition.marketingGrouping = returnedObject.groupArray;
                }
                if (returnedObject && returnedObject.nonGroupArray.length > 0) {
                    carrierCondition.marketing = returnedObject.nonGroupArray;
                }
            }
            if (carrierFormUnit.operating  && carrierFormUnit.operating.length > 0) {
                const returnedObject =  RuleUtil.splitGroupAndNonGroup(carrierFormUnit.operating);
                if (returnedObject && returnedObject.groupArray.length > 0) {
                    carrierCondition.operatingGrouping = returnedObject.groupArray;
                }
                if (returnedObject && returnedObject.nonGroupArray.length > 0) {
                    carrierCondition.operating = returnedObject.nonGroupArray;
                }
            }
            carrierConditionArray.push(carrierCondition);
        }

        return carrierConditionArray;
    }

    private setFormValuesFromData(carrierConditionDataArray: CarrierCondition[]) {
        const carrierFormUnitArray = [];
        for (const carrierConditionData of carrierConditionDataArray) {
            const carrierFormUnit = new CarrierFormGroup();
            carrierFormUnit.operator = carrierConditionData.comparator;
            carrierConditionData.marketing ? carrierFormUnit.marketing = carrierConditionData.marketing
                : carrierFormUnit.marketing = [];
            if (carrierConditionData.marketingGrouping && carrierConditionData.marketingGrouping.length > 0) {
                const markGroupingStringArray = AppUtil.numberToStringArray(carrierConditionData.marketingGrouping);
                carrierConditionData.marketing = carrierConditionData.marketing.concat(markGroupingStringArray);
            }
            carrierConditionData.operating ? carrierFormUnit.operating = carrierConditionData.operating
                : carrierFormUnit.operating = [];
            if (carrierConditionData.operatingGrouping && carrierConditionData.operatingGrouping.length > 0) {
                const operGroupingStringArray = AppUtil.numberToStringArray(carrierConditionData.operatingGrouping);
                carrierConditionData.operating = carrierConditionData.operating.concat(operGroupingStringArray);
            }
            carrierFormUnitArray.push(carrierFormUnit);
        }

        const carrierFormModel = {
            carrierLogicalUnits: carrierFormUnitArray
        } as CarrierComponentForm;

        if (carrierFormModel) {
            this.setFormValues(carrierFormModel);
        }
    }

    private setFormValues(carrierFormGroup: CarrierComponentForm) {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        for (const carrierFormUnit of carrierFormGroup.carrierLogicalUnits) {
            carrierFormArray.push(this.createCarrierFormGroup());
        }
        this.removeCarrierFormGroup(0);
        (this.carriersForm).patchValue(carrierFormGroup, { onlySelf: true });
    }

    private createCarrierFormGroup() {
        return this.fb.group({
            operator: ['EQ'],
            marketing: [''],
            operating: ['']
        });
    }

    private addCarrierFormGroup() {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        carrierFormArray.push(this.createCarrierFormGroup());
    }

    private removeCarrierFormGroup(i: number) {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        carrierFormArray.removeAt(i);
    }

}
