import { Component, Input, Output, EventEmitter, OnInit, ViewEncapsulation, OnDestroy, forwardRef } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { IdValue } from '../../../../models/ui-model';
import { Subscription } from 'rxjs/Subscription';
import { ClassRow } from 'src/app/models/rule-form.model';

// tslint:disable:no-forward-ref
// tslint:disable:no-empty

export const BOOKING_CLASS_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BookingClassesComponent),
    multi: true
};

@Component({
    selector: 'booking-classes',
    templateUrl: 'booking-classes.component.html',
    styleUrls: ['./booking-classes.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [BOOKING_CLASS_ACCESSOR]
})
export class BookingClassesComponent implements OnInit, OnDestroy, ControlValueAccessor {
    @Input() public childInput: any;
    @Input() public bookingClassesInput: ClassRow[];
    @Input() public selectedInput: IdValue[];
    @Output() public bookingClassesOutput = new EventEmitter();

    public bookingClasses: FormGroup;
    public allRow: string[];
    public reserved: any = []; // Ex: ['K', 'F', 'U', 'S'];
    public selected: any = [];
    public disable: boolean;
    public isEnable: boolean;
    private subscription: Subscription;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
    }

    public onChange: any = () => { };

    public writeValue(obj: any): void {
        for (const bookRows of obj) {
            this.toggleButtonClick(bookRows);
        }
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public registerOnTouched(fn: any): void {
    }

    public setDisabledState?(isDisabled: boolean): void {
        if (isDisabled === true) {
            this.selected = [];
            this.reserved = this.allRow;
            this.bookingClasses.disable();
        } else if (isDisabled === false) {
            this.selected = [];
            this.reserved = [];
            this.bookingClasses.enable();
        }
    }

    public ngOnInit() {
        this.selected = this.selectedInput ? this.selectedInput : [];
        const allrow = [];
        for (const item of this.bookingClassesInput) {
            allrow.push(item.value);
        }
        this.allRow = [].concat(...allrow);
        this.bookingClasses = this.fb.group(this.dynamicFormFields());

        this.bookingClasses.valueChanges.subscribe((bookedClasses) => {
            const selectedSeats = bookedClasses.selectedSeats;
            // this.bookingClassesOutput.emit(selectedSeats);
            this.onChange(selectedSeats);
        });

       // if (this.childInput) {
       //     for (const bookRows of this.childInput) {
       //         this.toggleButtonClick(bookRows);
       //     }
       // }
    }

    public ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    public dynamicFormFields() {
        const allFields = {};
        for (const item of this.bookingClassesInput) {
            allFields[item.id] = '';
        }
        allFields['allRow'] = '';
        allFields['selectedSeats'] = '';
        return allFields;
    }

    public isSelected(classPos: string): boolean {
        return (this.selected.indexOf(classPos) !== -1) ? true : false;
    }

    public isReserved(classPos: string): boolean {
        return (this.reserved.indexOf(classPos) !== -1) ? true : false;
    }

    public toggleButtonClick(item) {
        const index = this.selected.indexOf(item);
        if (index !== -1) {
            this.selected.splice(index, 1);
        } else {
            if (this.reserved.indexOf(item) === -1) {
                this.selected.push(item);
            }
        }
        this.bookingClasses.get('selectedSeats').setValue(this.selected.join());
        this.selectedClassesChange();
    }

    public ifAllRow() {
        for (const item of this.bookingClassesInput) {
            this.bookingClasses.get(item.id).setValue(
                this.bookingClasses.get('allRow').value
            );
        }
        if (this.bookingClasses.get('allRow').value) {
            if (this.selected === undefined) {
                this.selected = [];
            }
            this.pushClasses(this.allRow);
        } else if (!this.bookingClasses.get('allRow').value) {
            if (this.selected === undefined) {
                this.selected = [];
            }
            this.removeClasses(this.allRow);
        }
        this.bookingClasses.get('selectedSeats').setValue(this.selected.join());
    }

    private ifEachRow(checkbox: string) {
        // Check all the checkbox has value true
        const chkAll = [];
        for (const item of this.bookingClassesInput) {
            chkAll.push(this.bookingClasses.get(item.id).value);
        }
        const selectAll = chkAll.every(function(item: boolean) {
            return item === true;
        });
        this.bookingClasses.get('allRow').setValue(selectAll);
        if (selectAll) {
            this.selected = [];
            this.pushClasses(this.allRow); // if allRow true, push all classes
        } else {
            this.selectAll(checkbox);
        }
        this.bookingClasses.get('selectedSeats').setValue(this.selected.join());
    }

    private selectAll(checkbox: any): void {
        const allRow = this.bookingClasses.get('allRow').value;
        if (this.selected === undefined) {
            const seats = [];
            this.selected.push(seats);
        }
        for (const item of this.bookingClassesInput) {
            const isChecked = this.bookingClasses.get(checkbox).value;
            if (isChecked && item.id === checkbox) {
                this.pushClasses(item.value);
            } else if (!isChecked && item.id === checkbox) {
                this.removeClasses(item.value);
            }
        }
    }

    private removeClasses(values: any) {
        for (const item of values) {
            const index = this.selected.indexOf(item);
            if (index !== -1) {
                this.selected.splice(index, 1);
            }
        }
    }

    private pushClasses(values: any) {
        for (const item of values) {
            const index = this.selected.indexOf(item);
            if (index === -1) {
                this.selected.push(item);
            }
        }
    }

    private selectedClassesChange() {
        this.bookingClasses.get('allRow').setValue(
            this.allRow.every(item => this.selected.indexOf(item) !== -1)
        );
        // Dynamically setting checkbox
        for (const item of this.bookingClassesInput) {
            const row = item.id;
            const classes = item.value;
            this.bookingClasses.get(row).setValue(
                classes.every(val => this.selected.indexOf(val) !== -1)
            );
        }
    }

    private enableDisableAllFields(data) {
        if (data) {
            this.selected = [];
            this.reserved = this.allRow;
            this.bookingClasses.disable();
           // for (const item of this.bookingClassesInput) {
           //     this.bookingClasses.get(item.id).disable();
           // }
           // this.bookingClasses.reset();
        } else {
            this.selected = [];
            this.reserved = [];
            this.bookingClasses.enable();
            // for (const item of this.bookingClassesInput) {
            //     this.bookingClasses.get(item.id).enable();
            // }
            // this.bookingClasses.get('selectedSeats').reset();
        }
    }
}
