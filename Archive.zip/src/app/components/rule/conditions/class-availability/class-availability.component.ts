import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Rule, ClassAvailabilityCondition, Seat } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppUtil } from '../../../../utility/app-util';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm,
            ClassAvailabilityComponentForm,
            ClassAvailabilityFormGroup,
            ClassRow
} from '../../../../models/rule-form.model';
import { ComboBox, IdValue } from '../../../../models/ui-model';
import { AppValidator } from 'src/app/validators/app-validator';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector : 'class-availability',
    templateUrl : 'class-availability.component.html',
    styleUrls : ['./class-availability.component.scss']
})
export class ClassAvailabilityComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public classesAvailabilityGroup: FormGroup;
    public classAvailConditionDataArray: ClassAvailabilityCondition[];

    // Operators for class conditions
    public selectConds: string[] = [];
    // Operators for seats
    public operators: string[] = [];

    // Carrier configured classses and cabins. Name it appropriately
    public bookingClassesInput: ClassRow[];
    public cabinClassesInput: IdValue[];

    // User selected classes and cabins. Name it appropriately
    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class availability condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        const data = singletonService.ruleJsonStore;
        this.selectConds = data.Operators;
        this.operators = data.AllOperators;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList(CarrierPrefConstants.CABIN_TYPES, this.singletonService.carrierPreferences);
        this.bookingClassesInput =
        CarrierConfig.getBookingClassesList(CarrierPrefConstants.CLASS_AVAILABILITY_SECTION_CLASSES, this.singletonService.carrierPreferences);

        this.classesAvailabilityGroup = this.fb.group({classesAvailabilityUnit: this.fb.array([this.createClassesAvailabilityUnit()])});
        this.setValues();
    }

    /**
     * Populates the form value based on the rule data from the service
     */
    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.classAvailConditionDataArray = rule.condition.classAvailabilityCondition;
        }
        if ( this.classAvailConditionDataArray && this.classAvailConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    /**
     * Constructs the service request values for the create or update rule
     */
    public getValues(): ClassAvailabilityCondition[] {

        this.validate();

        // Do not send the data in the create/update service request when the the class availability input is not given.
        // This is also helpful to delete the existing data
        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Class availability condition');
            return null;
        }

        const classAvailabilityConditionArray = [];
        for (const classesAvailabilityUnit of this.classAvailabilityFormArray.value) {
            const seat = {
                seatComparator: classesAvailabilityUnit.operators,
                count: classesAvailabilityUnit.numbers
            } as Seat;

            const classAvailabilityCondition = {} as ClassAvailabilityCondition;
            classAvailabilityCondition.comparator = classesAvailabilityUnit.condSelect;
            classAvailabilityCondition.seats = seat;
            if (classesAvailabilityUnit.bookedClasses !== '') {
                classAvailabilityCondition.classOfService =  Array.isArray(classesAvailabilityUnit.bookedClasses) ?
                classesAvailabilityUnit.bookedClasses : classesAvailabilityUnit.bookedClasses.split(',');
            }
            if (classesAvailabilityUnit.cabinClasses !== '') {
                classAvailabilityCondition.cabin = classesAvailabilityUnit.cabinClasses;
            }

            classAvailabilityConditionArray.push(classAvailabilityCondition);
        }
        return classAvailabilityConditionArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;
        const validator = new AppValidator();

        if (!this.isEmptyCondition) {
            for (const classesAvailabilityFormUnit of this.classAvailabilityFormArray.controls) {
                if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                     &&  RuleUtil.isCabinSelected(classesAvailabilityFormUnit, 'cabinClasses')) {
                    // When user selected both cabin and classes
                    classesAvailabilityFormUnit.get('cabinClasses').setErrors({isError: true});
                    classesAvailabilityFormUnit.get('bookedClasses').setErrors({isError: true});
                }  else if (!RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                        &&  !RuleUtil.isCabinSelected(classesAvailabilityFormUnit, 'cabinClasses')) {
                        // When user not selected the classes or cabin, and selected seats
                        if (AppUtil.isValueExists(classesAvailabilityFormUnit, 'numbers')) {
                            classesAvailabilityFormUnit.get('cabinClasses').setErrors({isError: true});
                            classesAvailabilityFormUnit.get('bookedClasses').setErrors({isError: true});
                        }
                } else {
                    classesAvailabilityFormUnit.get('cabinClasses').setErrors(null);
                    classesAvailabilityFormUnit.get('bookedClasses').setErrors(null);
                }

                if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                        || RuleUtil.isCabinSelected(classesAvailabilityFormUnit, 'cabinClasses') ) {
                            // When seats are not selected
                            if (AppUtil.isEmptyValue(classesAvailabilityFormUnit, 'numbers')) {
                                validator.setRequired(classesAvailabilityFormUnit.get('numbers'));
                            } else {
                                classesAvailabilityFormUnit.get('numbers').setErrors(null);
                            }
                }

                if (classesAvailabilityFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyClassAvailFormUnitArray = [];
        this.isEmptyCondition = false;

        for (const classesAvailabilityFormUnit of this.classAvailabilityFormArray.controls) {

            let emptyForm = true;
            if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                || AppUtil.isArrayValueExists(classesAvailabilityFormUnit, 'cabinClasses')
                || AppUtil.isValueExists(classesAvailabilityFormUnit, 'numbers')) {
                    emptyForm = false;
            }

            if (emptyForm) {
                emptyClassAvailFormUnitArray.push(i);
            }
            i++;
        }

        // When the class form array and the removable form array is equal, then just add an empty form
        if (this.classAvailabilityFormArray.controls.length === emptyClassAvailFormUnitArray.length) {
            this.isEmptyCondition = true;
            emptyClassAvailFormUnitArray.splice(0, 1);
        }
        for (const emptyUnit of emptyClassAvailFormUnitArray.reverse()){
            this.removeClassesAvailabilityUnit(emptyUnit);
        }
    }

    get classAvailabilityFormArray(): FormArray{
        return this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
    }

    private clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    private setFormValuesFromData() {
        const classAvailabilityFormUnitArray = [];

        for ( const classAvailDataUnit of this.classAvailConditionDataArray) {
            this.cabinViewData.push(classAvailDataUnit.cabin ? classAvailDataUnit.cabin : '');
            this.bookingViewData.push(classAvailDataUnit.classOfService ? classAvailDataUnit.classOfService : '');
            classAvailabilityFormUnitArray.push( {
                condSelect: classAvailDataUnit.comparator,
                operators: classAvailDataUnit.seats.seatComparator,
                numbers: classAvailDataUnit.seats.count
            } as ClassAvailabilityFormGroup);
        }
        const classAvailabilityFormModel = {
            classesAvailabilityUnit: classAvailabilityFormUnitArray
        } as ClassAvailabilityComponentForm;

        if (classAvailabilityFormModel) {
            this.setFormValues(classAvailabilityFormModel);
        }
    }

    private setFormValues(classesAvailabilityFormModel: ClassAvailabilityComponentForm) {
        const classAvailFormArrayLength = classesAvailabilityFormModel.classesAvailabilityUnit.length;
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;

        let i: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < classAvailFormArrayLength ; i++ ) {
            classAvailFormArray.push(this.createClassesAvailabilityUnit());
        }
        classAvailFormArray.removeAt(i);
        // Push service response data into generated fields
        (this.classesAvailabilityGroup as FormGroup).patchValue(classesAvailabilityFormModel, { onlySelf: true });
        let z = 0;
        for (const cabin of this.cabinViewData) {
            this.classAvailabilityFormArray.controls[z].get('cabinClasses').setValue(cabin);
            z++;
        }
        let q = 0;
        for (const booking of this.bookingViewData) {
            this.classAvailabilityFormArray.controls[q].get('bookedClasses').setValue(booking);
            q++;
        }
    }

    private createClassesAvailabilityUnit() {
        return this.fb.group({
            condSelect : 'EQ',
            bookedClasses: [''],
            cabinClasses: [''],
            numbers: [''],
            operators: ['GT']
        });
    }

    private addClassesAvailabilityUnit() {
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
        classAvailFormArray.push(this.createClassesAvailabilityUnit());
    }

    private removeClassesAvailabilityUnit(i: number) {
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
        classAvailFormArray.removeAt(i);
    }

}
