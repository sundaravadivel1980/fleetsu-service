import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';

import { Rule, ClassCondition, ClassClosureActionInput, ClassSuppressionActionInput } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppConstants, CarrierPrefConstants, ConditionConstants } from '../../../../app.constants';
import { AppUtil } from '../../../../utility/app-util';

import { RuleDetailChildForm, ClassesComponentForm, ClassesFormGroup, ClassRow } from '../../../../models/rule-form.model';
import { IdValue, ComboBox } from '../../../../models/ui-model';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { AppValidator } from 'src/app/validators/app-validator';

@Component({
    selector: 'classes',
    templateUrl: 'classes.component.html',
    styleUrls: ['./classes.component.scss']
})
export class ClassesComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;
    @Input() public disableButton: boolean = false;

    // First level form group. The base for all the sub form groups of classes component
    public classesGroup: FormGroup;
    public classConditionDataArray: ClassCondition[];

    public operators: ComboBox[];
    public waitlistOptions: IdValue[];

    public bookingClassesInput: ClassRow[];
    public cabinClassesInput: IdValue[];
    public showWaitList: boolean = false;

    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class availability condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
        this.waitlistOptions = data.WaitLists;
    }

    public ngOnInit() {

        // Cabin and booking classes from carrier config
        this.cabinClassesInput = CarrierConfig.getCabinList(CarrierPrefConstants.CABIN_TYPES, this.singletonService.carrierPreferences);
        this.bookingClassesInput =
        CarrierConfig.getBookingClassesList(CarrierPrefConstants.CLASSES_SECTION_CLASSES, this.singletonService.carrierPreferences);

        if (this.childInput.type === AppConstants.ACTION_CLASS_CLOSSURE) {
            this.showWaitList = true;
        }
        this.classesGroup = this.fb.group({
            classesUnit: this.fb.array([this.createClassFormGroup()]),
            waitlistRdo: ['CLOSED']
        });

        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.classConditionDataArray = rule.condition.classCondition;
        }
        if (this.classConditionDataArray && this.classConditionDataArray.length > 0) {
            let actionInput: ClassClosureActionInput;
            if (rule.type === AppConstants.ACTION_CLASS_CLOSSURE) {
                actionInput = rule.action.classClosureActionInput;
            }
            this.setFormValuesFromData(actionInput);
        }
    }

    public getValues(): ClassCondition[] {

        this.validate();

        if (this.hasErrors) {
            return null;
        }

        if (this.isEmptyCondition) {
            if (this.singletonService.isRequiredCondition(this.childInput.type, ConditionConstants.CLASSES)) {
                this.messageService.addRequiredConditionError('Classes');
            }
            return null;
        }

        const classConditionArray = [];
        for (const classFormUnit of this.classFormArray.value) {
            const classCondition = {} as ClassCondition;
            classCondition.comparator = classFormUnit.condSelect;
            if (classFormUnit.bookedClasses !== '') {
                classCondition.classOfService = Array.isArray(classFormUnit.bookedClasses) ?
                classFormUnit.bookedClasses : classFormUnit.bookedClasses.split(',');
            }
            if (classFormUnit.cabinClasses !== '') {
                classCondition.cabin = classFormUnit.cabinClasses;
            }
            classConditionArray.push(classCondition);
        }
        return classConditionArray;
    }

    public getClassClossureActionInput(): ClassClosureActionInput {
        const classClosureActionInput = new ClassClosureActionInput();
        classClosureActionInput.waitlistClose = this.classesGroup.get('waitlistRdo').value === 'WAITLIST' ? true : false;
        return classClosureActionInput;
    }

    public getClassSuppressionActionInput(): ClassSuppressionActionInput {
        const classClosureActionInput = new ClassSuppressionActionInput();
        return classClosureActionInput;
    }

    public addClassesUnit(i) {
        const classFormArray = this.classesGroup.get('classesUnit') as FormArray;
        classFormArray.push(this.createClassFormGroup());
        if (classFormArray.controls[0].get('condSelect').value === 'EQ') {
            classFormArray.controls[1].get('condSelect').setValue('NEQ');
        } else {
            classFormArray.controls[1].get('condSelect').setValue('EQ');
        }

        // Disable the add button when 2 conditions added
        this.disableButton = classFormArray.controls.length >= 2 ? true : false;
    }

    /**
     * When user select the operator, make sure the operators are not same in all the conditions
     */
    public selectOperator(event, i) {
        const classFormArray = this.classesGroup.get('classesUnit') as FormArray;
        const index = i === 0 ? 1 : 0;
        if (classFormArray.controls[1] && event.value === classFormArray.controls[index].get('condSelect').value) {
            classFormArray.controls[i].get('condSelect').setErrors({ isError: true });
        } else if (classFormArray.controls[1]) {
            classFormArray.controls[index].get('condSelect').setErrors(null);
            classFormArray.controls[i].get('condSelect').setErrors(null);
        }
    }

    public removeClassesUnit(i: number) {
        const classFormArray = this.classesGroup.get('classesUnit') as FormArray;
        classFormArray.removeAt(i);
        this.disableButton = classFormArray.controls.length >= 2 ? true : false;
    }

    public clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    get classFormArray(): FormArray {
        return this.classesGroup.get('classesUnit') as FormArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        const validator = new AppValidator();

        if (!this.isEmptyCondition) {
            // Field level validations
            for (const classFormUnit of this.classFormArray.controls) {
                if (RuleUtil.isBookingClassSelected(classFormUnit)
                    && RuleUtil.isCabinSelected(classFormUnit, 'cabinClasses')) {
                    // When booking and cabin provided
                    classFormUnit.get('cabinClasses').setErrors({isError: true});
                    classFormUnit.get('bookedClasses').setErrors({isError: true});
                    this.hasErrors = true;
                } else {
                    classFormUnit.get('cabinClasses').setErrors(null);
                    classFormUnit.get('bookedClasses').setErrors(null);
                }
                if (classFormUnit.status.toLowerCase() === 'invalid') {
                    this.messageService.addErrorWithParam(
                        'acegui.rules.messages.form.validatiom.failed', 'Classes condition');
                    this.hasErrors = true;
                }
            }
        }
    }

    private setFormValuesFromData(actionInput) {
        const classesFormModel = new ClassesComponentForm();
        const classesFormUnitArray = [];

        for (const classDataUnit of this.classConditionDataArray) {
            this.cabinViewData.push(classDataUnit.cabin ? classDataUnit.cabin : '');
            this.bookingViewData.push(classDataUnit.classOfService ? classDataUnit.classOfService : '');
            const classFormUnit = new ClassesFormGroup();
            classFormUnit.condSelect = classDataUnit.comparator;
            classesFormUnitArray.push(classFormUnit);
        }
        if (actionInput) {
            classesFormModel.waitlistRdo = actionInput.waitlistClose ? 'WAITLIST' : 'CLOSED';
        }
        classesFormModel.classesUnit = classesFormUnitArray;
        if (classesFormModel) {
            this.setFormValues(classesFormModel);
        }
    }

    private setFormValues(classesFormModel: ClassesComponentForm) {
        // Create the empty forms first and then the patch it with the rule data
        const classFormArray = this.classesGroup.get('classesUnit') as FormArray;
        for (const classFormUnit of classesFormModel.classesUnit) {
            classFormArray.push(this.createClassFormGroup());
        }
        this.removeClassesUnit(0);
        (this.classesGroup as FormGroup).patchValue(classesFormModel, { onlySelf: true });
        let z = 0;
        for (const cabin of this.cabinViewData) {
            this.classFormArray.controls[z].get('cabinClasses').setValue(cabin);
            z++;
        }
        let q = 0;
        for (const booked of this.bookingViewData) {
            this.classFormArray.controls[q].get('bookedClasses').setValue(booked);
            q++;
        }
    }

    private setActionInputValues(actionInput) {
        this.classFormArray.controls[0].get('waitlistRdo').setValue(true);
    }

    private removeEmptyForms() {
        let i: number = 0;
        const emptyClassesFormunits = [];
        this.isEmptyCondition = false;

        for (const classFormUnit of this.classFormArray.controls) {
            let emptyForm = true;
            if (RuleUtil.isBookingClassSelected(classFormUnit)
                || AppUtil.isArrayValueExists(classFormUnit, 'cabinClasses')) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyClassesFormunits.push(i);
            }

            i++;
        }
        if (this.classFormArray.controls.length === emptyClassesFormunits.length) {
            this.isEmptyCondition = true;
            emptyClassesFormunits.splice(0, 1);
        }
        for (const emptyUnit of emptyClassesFormunits.reverse()) {
            this.removeClassesUnit(emptyUnit);
        }
    }

    private createClassFormGroup() {
        return this.fb.group({
            condSelect: 'EQ',
            bookedClasses: [''],
            cabinClasses: ''
        });
    }

}
