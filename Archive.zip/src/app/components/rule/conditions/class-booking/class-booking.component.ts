import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { Rule, ClassBookingCondition, Seat, OriginDestination } from '@dxc/tr-ux-ace-services/dist/lib';
import { RuleDetailChildForm,
            ClassBookingComponentForm,
            ClassBookingFormGroup,
            OriginDestinationFormGroup,
            ClassRow
        } from '../../../../models/rule-form.model';

import { ComboBox, AutoCompleteChip, IdValue } from '../../../../models/ui-model';

import { GroupType } from '../../../../models/group-type';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { RuleUtil } from '../../rule.util.ts';
import { AppUtil } from '../../../../utility/app-util';
import { AppValidator } from 'src/app/validators/app-validator';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector : 'class-booking',
    templateUrl : 'class-booking.component.html',
    styleUrls : ['./class-booking.component.scss']
})
export class ClassBookingComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public classesBookingGroup: FormGroup;
    public classBookingConditionDataArray: ClassBookingCondition[];

    public selectConds: ComboBox[] = [];
    public operators: ComboBox[] = [];
    public listOfAirport: AutoCompleteChip[];
    public bookingClassesInput: ClassRow[];
    public cabinClassesInput: IdValue[];
    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class booking condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        const data = singletonService.ruleJsonStore;
        // for class conditions
        this.selectConds = data.Operators;
        // for seats
        this.operators = data.AllOperators;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList(CarrierPrefConstants.CABIN_TYPES, this.singletonService.carrierPreferences);
        this.bookingClassesInput =
        CarrierConfig.getBookingClassesList(CarrierPrefConstants.CLASS_BOOKING_SECTION_CLASSES, this.singletonService.carrierPreferences);
        this.listOfAirport = this.singletonService.getCombinedAirportsAndLocations();

        this.classesBookingGroup = this.fb.group({classesBookingUnit: this.fb.array([this.createClassBookingUnit()])});
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.classBookingConditionDataArray = rule.condition.classBookingCondition;
        }
        if ( this.classBookingConditionDataArray && this.classBookingConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): ClassBookingCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Class booking condition');
            return null;
        }

        const classBookingConditionArray = [];
        for (const classBookingFormUnit of this.classBookingFormArray.value) {
            // const classBookingSeats = [];
            const classSegment = [];

            for (const originAndDestFormUnit of classBookingFormUnit.seatsUnit) {
                if (originAndDestFormUnit.origin.length > 0 || originAndDestFormUnit.destination.length > 0) {
                    const originDestinationData = RuleUtil.splitAirportAndLocationGroup(originAndDestFormUnit);
                    classSegment.push(originDestinationData);
                }
            }

            const seat = {
                seatComparator: classBookingFormUnit.operators,
                count: classBookingFormUnit.numbers,
                segment: classSegment
            } as Seat;

            const classBookingCondition = {} as ClassBookingCondition;
            classBookingCondition.seats = seat;
            classBookingCondition.comparator = classBookingFormUnit.condSelect;
            if (classBookingFormUnit.bookedClasses !== '') {
                classBookingCondition.classOfService = Array.isArray(classBookingFormUnit.bookedClasses) ?
                classBookingFormUnit.bookedClasses : classBookingFormUnit.bookedClasses.split(',');
            }
            if (classBookingFormUnit.cabinClasses !== '') {
                classBookingCondition.cabin = classBookingFormUnit.cabinClasses;
            }
            classBookingConditionArray.push(classBookingCondition);
        }

        return classBookingConditionArray;
    }

    public clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;
        const validator = new AppValidator();

        // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const classBookingFormUnit of this.classBookingFormArray.controls) {

                if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                     &&  RuleUtil.isCabinSelected(classBookingFormUnit, 'cabinClasses')) {
                         // When user selected both cabin and classes
                        classBookingFormUnit.get('cabinClasses').setErrors({isError: true});
                        classBookingFormUnit.get('bookedClasses').setErrors({isError: true});
                }  else if (!RuleUtil.isBookingClassSelected(classBookingFormUnit)
                        &&  !RuleUtil.isCabinSelected(classBookingFormUnit, 'cabinClasses')) {
                        // When user not selected the classes or cabin, and selected seats
                        if (AppUtil.isValueExists(classBookingFormUnit, 'numbers')) {
                            classBookingFormUnit.get('cabinClasses').setErrors({isError: true});
                            classBookingFormUnit.get('bookedClasses').setErrors({isError: true});
                        }
                } else {
                    classBookingFormUnit.get('cabinClasses').setErrors(null);
                    classBookingFormUnit.get('bookedClasses').setErrors(null);
                }

                if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                        || RuleUtil.isCabinSelected(classBookingFormUnit, 'cabinClasses') ) {
                    // When seats are not selected
                    if (AppUtil.isEmptyValue(classBookingFormUnit, 'numbers')) {
                        validator.setRequired(classBookingFormUnit.get('numbers'));
                    } else {
                        classBookingFormUnit.get('numbers').setErrors(null);
                    }
                }

                if (classBookingFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    private removeEmptyForms() {

        let i: number = 0;
        const emptyClassBkgFormUnits = [];
        this.isEmptyCondition = false;

        for (const classBookingFormUnit of this.classBookingFormArray.controls) {
            const originAndDestFormUnitArray = classBookingFormUnit.get('seatsUnit') as FormArray;

            // Remove the empty O&D fields
            let emptyOriginAndDestForm = false;
            const emptyOriginAndDestFormUnitArray = this.validateOriginAndDestination(originAndDestFormUnitArray);
            if (originAndDestFormUnitArray.controls.length === emptyOriginAndDestFormUnitArray.length) {
                emptyOriginAndDestForm = true;
                emptyOriginAndDestFormUnitArray.splice(0, 1);
            }

            for (const emptyOriginAndDestFormUnit of emptyOriginAndDestFormUnitArray){
                this.removeSeatsUnitFormGroup(i, emptyOriginAndDestFormUnit);
            }

            let emptyForm = true;
            // The form is not empty when user given any field input
            if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                 || AppUtil.isArrayValueExists(classBookingFormUnit, 'cabinClasses')
                 || AppUtil.isValueExists(classBookingFormUnit, 'numbers')
                 || !emptyOriginAndDestForm) {
                emptyForm = false;

            }

            if (emptyForm) {
                emptyClassBkgFormUnits.push(i);
            }

            i++;
        }

        if (this.classBookingFormArray.controls.length === emptyClassBkgFormUnits.length) {
            this.isEmptyCondition = true;
            emptyClassBkgFormUnits.splice(0, 1);
        }
        for (const emptyClassBkgFormUnit of emptyClassBkgFormUnits.reverse()){
            this.removeClassesBookingUnit(emptyClassBkgFormUnit);
        }
    }

    private validateOriginAndDestination(segmentFormUnit: FormArray) {
        let j: number = 0;
        const removableOAndDFormGroups = [];
        for (const originAndDestination of segmentFormUnit.controls) {
            if (originAndDestination.get('origin').value.length === 0 && originAndDestination.get('destination').value.length === 0) {
                removableOAndDFormGroups.push(j);
            }
            j++;
        }
        return removableOAndDFormGroups.reverse();
    }

    get classBookingFormArray(): FormArray{
        return this.classesBookingGroup.get('classesBookingUnit') as FormArray;
    }

    private setFormValuesFromData() {
        const classBookingFormGroupArray = [];

        for ( const classBkgDataUnit of this.classBookingConditionDataArray) {
            this.cabinViewData.push(classBkgDataUnit.cabin ? classBkgDataUnit.cabin : '');
            this.bookingViewData.push(classBkgDataUnit.classOfService ? classBkgDataUnit.classOfService : '');

            const segmentFormArray = [];
            if (classBkgDataUnit.seats.segment) {
                for (const classAvailabilitySeatData of classBkgDataUnit.seats.segment) {
                    const orginDestForm = RuleUtil.combineLocationGroupAndAirport(classAvailabilitySeatData);
                    segmentFormArray.push(orginDestForm);
                }
            } else {
                segmentFormArray.push( {
                    origin: [],
                    destination: []
                } as OriginDestinationFormGroup);
            }

            classBookingFormGroupArray.push({
                condSelect: classBkgDataUnit.comparator,
                seatsUnit: segmentFormArray,
                operators: classBkgDataUnit.seats.seatComparator,
                numbers: classBkgDataUnit.seats.count
            } as ClassBookingFormGroup);
        }

        const classBookingForm = {
            classesBookingUnit: classBookingFormGroupArray
        } as ClassBookingComponentForm;

        if (classBookingForm) {
            this.setFormValues(classBookingForm);
        }
    }

    private setFormValues(classBookingForm: ClassBookingComponentForm) {
        const classesBookingUnitsLength = classBookingForm.classesBookingUnit.length;
        const classBookingUnits = this.classesBookingGroup.get('classesBookingUnit') as FormArray;

        let i: number;
        let j: number;

        // Create empty class booking forms
        for (i = 0; i < classesBookingUnitsLength ; i++ ) {
            classBookingUnits.push(this.createClassBookingUnit());
        }

        classBookingUnits.removeAt(i);

        // create empty O&D forms
        i = 0;
        for (const classBookingFormUnit of classBookingForm.classesBookingUnit) {
            j = 0;
            const originAndDestFormUnits = this.classBookingFormArray.controls[i].get('seatsUnit') as FormArray;
            for ( const orginDestination of classBookingFormUnit.seatsUnit) {
                originAndDestFormUnits.push(this.createSeatsUnitFormGroup());
                j++;
            }
            this.removeSeatsUnitFormGroup(i, j);
            i++;
        }
          // Push service response data into empty forms
        (this.classesBookingGroup as FormGroup).patchValue(classBookingForm, { onlySelf: true });
        let z = 0;
        for (const cabin of this.cabinViewData) {
            this.classBookingFormArray.controls[z].get('cabinClasses').setValue(cabin);
            z++;
        }
        let q = 0;
        for (const booking of this.bookingViewData) {
            this.classBookingFormArray.controls[q].get('bookedClasses').setValue(booking);
            q++;
        }
    }

    private createClassBookingUnit() {
        return this.fb.group({
            condSelect : 'EQ',
            seatsUnit: this.fb.array([this.createSeatsUnitFormGroup()]),
            bookedClasses: [''],
            cabinClasses: [[]],
            numbers: ['', Validators.required],
            operators: ['GT']
        });
    }

    private createSeatsUnitFormGroup() {
        return this.fb.group({
            origin: [[]],
            destination: [[]]
        });
    }

    private addSeatsUnitFormGroup(j: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit')['controls'][j].get('seatsUnit') as FormArray;
        control.push(this.createSeatsUnitFormGroup());
    }

    private removeSeatsUnitFormGroup(j: number, i: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit')['controls'][j].get('seatsUnit') as FormArray;
        control.removeAt(i);
    }

    private addClassesBookingUnit() {
        const control = this.classesBookingGroup.get('classesBookingUnit') as FormArray;
        control.push(this.createClassBookingUnit());
    }

    private removeClassesBookingUnit(i: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit') as FormArray;
        control.removeAt(i);
    }
}
