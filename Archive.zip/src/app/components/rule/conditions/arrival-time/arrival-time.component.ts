import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, AbstractControl, Validators } from '@angular/forms';
import { TimeValidator } from '../../../../validators/rule/time-validator';
import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, ArrivalTimeComponentForm, TimeFormGroup } from '../../../../models/rule-form.model';
import { ComboBox } from '../../../../models/ui-model';

@Component({
    selector: 'arrival-time',
    templateUrl: 'arrival-time.component.html',
    styleUrls: ['./arrival-time.component.scss'],
    providers: [TimeValidator]
})
export class ArrivalTimeGroupComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public arrivalTimeGroup: FormGroup;
    private arrivalTimeComponentData: DateTimeCondition[];

    private operators: ComboBox[];
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private messageService: MessageTranslationService,
                private validator: TimeValidator) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators as ComboBox[];
    }

    public ngOnInit() {
        this.arrivalTimeGroup = this.fb.group({
            arrivalTime: this.fb.array([this.createArrivalTimeFormGroup()])
        });

        this.setValues();
    }

    get arrivalTimeFormArray(): FormArray {
        return this.arrivalTimeGroup.get('arrivalTime') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.arrivalTimeComponentData = rule.condition.arrivalTimeCondition;
        }
        if (this.arrivalTimeComponentData && this.arrivalTimeComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Arrival time condition');
            return null;
        }

        const arrivalTimeConditionDataArray = [];
        for (const arrivalTimeFormUnit of this.arrivalTimeFormArray.value) {
            const dateAndTime = new DateOrRange();
            if (arrivalTimeFormUnit.startHours) {
                dateAndTime.startDateTime = arrivalTimeFormUnit.startHours + ':' + arrivalTimeFormUnit.startMinutes + ':00';
            }
            if (arrivalTimeFormUnit.endHours) {
                dateAndTime.endDateTime = arrivalTimeFormUnit.endHours + ':' + arrivalTimeFormUnit.endMinutes + ':00';
            }
            arrivalTimeConditionDataArray.push({
                comparator: arrivalTimeFormUnit.operator,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return arrivalTimeConditionDataArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        // validate only when user provide input to any field
        if (!this.isEmptyCondition) {
            for (const timeFormUnit of this.arrivalTimeFormArray.controls) {
                 this.validator.triggerFieldValidation(timeFormUnit.get('endHours'));
                 this.validator.triggerFieldValidation(timeFormUnit.get('startHours'));
                 this.validator.triggerFieldValidation(timeFormUnit.get('endMinutes'));
                 this.validator.triggerFieldValidation(timeFormUnit.get('startMinutes'));

                 if (timeFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    private removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const arrivalTimeFormUnit of this.arrivalTimeFormArray.controls) {
            let emptyForm = true;
            if (arrivalTimeFormUnit.get('endHours').value || arrivalTimeFormUnit.get('startHours').value ||
                arrivalTimeFormUnit.get('startMinutes').value || arrivalTimeFormUnit.get('endMinutes').value) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyForm of emptyForms.reverse()) {
            this.removeArrivalTime(emptyForm);
        }
        if (this.arrivalTimeFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addArrivalTime();
        }
    }

    private setFormValuesFromData() {
        const arrivalTimeFormUnitArray = [];
        for (const arrivalTimeDataUnit of this.arrivalTimeComponentData) {
            const startTimeSplit = arrivalTimeDataUnit.dateOrRange.startDateTime ?
                arrivalTimeDataUnit.dateOrRange.startDateTime.split(':') : '';
            const endTimeSplit = arrivalTimeDataUnit.dateOrRange.endDateTime ?
                arrivalTimeDataUnit.dateOrRange.endDateTime.split(':') : '';

            const arrivalTimeFormUnit = {
                operator: arrivalTimeDataUnit.comparator,
                startHours: startTimeSplit[0],
                startMinutes: startTimeSplit[1],
                endHours: endTimeSplit[0],
                endMinutes: endTimeSplit[1]
            } as TimeFormGroup;

            arrivalTimeFormUnitArray.push(arrivalTimeFormUnit);
        }

        const arrTimeFormModel = {
            arrivalTime: arrivalTimeFormUnitArray
        } as ArrivalTimeComponentForm;

        if (arrTimeFormModel) {
            this.setFormValues(arrTimeFormModel);
        }
    }

    private createArrivalTimeFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            startHours: ['', [Validators.required, this.validator.validateStartTimeHours]],
            startMinutes: ['', [Validators.required, this.validator.validateStartTimeMinutes]],
            endHours: ['', [Validators.required, this.validator.validateEndTimeHours]],
            endMinutes: ['', [Validators.required, this.validator.validateEndTimeMinutes]]
        });
    }

    private setFormValues(arrivalTimeFormModel: ArrivalTimeComponentForm) {
        const arrivalTimeFormUnitArray = this.arrivalTimeGroup.get('arrivalTime') as FormArray;
        for (const arrivalTimeFormUnit of arrivalTimeFormModel.arrivalTime) {
            arrivalTimeFormUnitArray.push(this.createArrivalTimeFormGroup());
        }
        this.removeArrivalTime(0);
        (this.arrivalTimeGroup as FormGroup).patchValue(arrivalTimeFormModel, { onlySelf: true });
    }

    private addArrivalTime() {
        this.arrivalTimeFormArray.push(this.createArrivalTimeFormGroup());
    }

    private removeArrivalTime(i: number) {
        this.arrivalTimeFormArray.removeAt(i);
    }
}
