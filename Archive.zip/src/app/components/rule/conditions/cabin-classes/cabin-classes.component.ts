import { OnInit, OnDestroy, AfterViewInit, OnChanges, Component, Input, Output,
        SimpleChanges, EventEmitter, ChangeDetectorRef, ElementRef, forwardRef } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { IdValue } from '../../../../models/ui-model';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

export const CABIN_CLASSES_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    // tslint:disable-next-line:no-forward-ref
    useExisting: forwardRef(() => CabinClassesComponent),
    multi: true,
  };

@Component({
    selector: 'cabin-classes',
    templateUrl: 'cabin-classes.component.html',
    styleUrls: ['./cabin-classes.component.scss'],
    providers: [CABIN_CLASSES_ACCESSOR]
})

export class CabinClassesComponent implements ControlValueAccessor, OnInit, OnDestroy {
    @Input() public childInput: any;
    @Input() public cabinClassesInput: IdValue[];
    @Output() public subChildOutput = new EventEmitter();
    @Input() public disabled: boolean;
    public cabinClassesGroup: FormGroup;
    private subscription: Subscription;
    constructor(private fb: FormBuilder, private cdR: ChangeDetectorRef) {
    }

    public writeValue(obj: any): void {
        for (const cabin of obj) {
            this.cabinClassesGroup.get(cabin).setValue(true);
        }
        if (obj.length === this.cabinClassesInput.length) {
            this.cabinClassesGroup.get('allCabin').setValue(true);
        }
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public onChange: any = () => {
        // console
    }

    public registerOnTouched(fn: any): void {
        // console.log()
    }

    public setDisabledState?(isDisabled: boolean): void {
        if (isDisabled) {
            this.cabinClassesGroup.disable();
        }else {
            this.cabinClassesGroup.enable();
        }
    }

    public ngOnInit() {
        this.cabinClassesGroup = this.fb.group(this.dynamicFormFields());
        const checkedCabins = [];
        this.cabinClassesGroup.valueChanges.subscribe(cabinClasses => {
            Object.keys(cabinClasses).forEach(field => {
                if (cabinClasses[field] && cabinClasses[field] === true && field !== 'allCabin' && checkedCabins.indexOf(field) === -1) {
                    checkedCabins.push(field);
                } else if (field === 'allCabin' && !cabinClasses[field]) {
                    checkedCabins.length = 0;
                }
            });
            this.onChange(checkedCabins);
        });
    }

    public ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    public allCabinChecked() {
        for (const item of this.cabinClassesInput) {
            this.cabinClassesGroup.get(item.id).setValue(
                this.cabinClassesGroup.get('allCabin').value
            );
        }
    }

    private cabinsChecked() {
        const isAllChecked = [];
        for (const item of this.cabinClassesInput) {
            isAllChecked.push(this.cabinClassesGroup.get(item.id).value);
        }
        this.cabinClassesGroup.get('allCabin').setValue(
            isAllChecked.every(function(item: boolean) {
                return item === true;
            })
        );
    }

    private dynamicFormFields() {
        const allFormFields = {};
        allFormFields['allCabin'] = [false];
        for (const item of this.cabinClassesInput) {
            allFormFields[item.id] = [false];
        }
        return allFormFields;
    }
}
