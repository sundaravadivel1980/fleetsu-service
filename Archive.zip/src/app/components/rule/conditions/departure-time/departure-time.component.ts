import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, AbstractControl, Validators } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';

import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';
import { TimeValidator } from '../../../../validators/rule/time-validator';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DepartureTimeComponentForm, TimeFormGroup } from '../../../../models/rule-form.model';
import { MessageTranslationService } from '../../../../services/message-translation.service';

@Component({
    selector: 'departure-time',
    templateUrl: 'departure-time.component.html',
    styleUrls: ['./departure-time.component.scss'],
    providers: [TimeValidator]
})
export class DepartureTimeGroupComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public departureTimeGroup: FormGroup;
    private departTimeConditionDataArray: DateTimeCondition[];

    private operators: any;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private messageService: MessageTranslationService,
                private validator: TimeValidator) {
                this.operators = this.appSingletonService.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        this.departureTimeGroup = this.fb.group({
            departureTime: this.fb.array([this.createDepartureTimeFormGroup()])
        });
        this.setValues();
    }

    get departureTimeFormArray(): FormArray {
        return this.departureTimeGroup.get('departureTime') as FormArray;
    }

    public addDepartureTime() {
        this.departureTimeFormArray.push(this.createDepartureTimeFormGroup());
    }

    public removeDepartureTime(i: number) {
        this.departureTimeFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.departTimeConditionDataArray = rule.condition.departureTimeCondition;
        }
        if (this.departTimeConditionDataArray && this.departTimeConditionDataArray.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Departure time condition');
            return null;
        }

        const departureTimeConditionDataArray = [];
        for (const departTimeFormUnit of this.departureTimeFormArray.value) {
            const dateAndTime = new DateOrRange();
            if (departTimeFormUnit.startHours) {
                dateAndTime.startDateTime = departTimeFormUnit.startHours + ':' + departTimeFormUnit.startMinutes + ':00';
            }
            if (departTimeFormUnit.endHours) {
                dateAndTime.endDateTime = departTimeFormUnit.endHours + ':' + departTimeFormUnit.endMinutes + ':00';
            }
            departureTimeConditionDataArray.push({
                comparator: departTimeFormUnit.operator,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return departureTimeConditionDataArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        // validate only when user provide input to any field
        if (!this.isEmptyCondition) {
            for (const timeFormUnit of this.departureTimeFormArray.controls) {
                this.validator.triggerFieldValidation(timeFormUnit.get('endHours'));
                this.validator.triggerFieldValidation(timeFormUnit.get('startHours'));
                this.validator.triggerFieldValidation(timeFormUnit.get('endMinutes'));
                this.validator.triggerFieldValidation(timeFormUnit.get('startMinutes'));

                if (timeFormUnit.status.toLowerCase() === 'invalid') {
                   this.hasErrors = true;
               }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const departTimeFormUnit of this.departureTimeFormArray.controls) {
            let emptyForm = true;
            if (departTimeFormUnit.get('endHours').value || departTimeFormUnit.get('startHours').value ||
                departTimeFormUnit.get('startMinutes').value || departTimeFormUnit.get('endMinutes').value) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyForm of emptyForms.reverse()) {
            this.removeDepartureTime(emptyForm);
        }
        if (this.departureTimeFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addDepartureTime();
        }
    }

    private setFormValuesFromData() {
        const departureTimeFormUnitArray = [];

        for (const departCondDataUnit of this.departTimeConditionDataArray) {
            const startTimeSplit = departCondDataUnit.dateOrRange.startDateTime ?
                departCondDataUnit.dateOrRange.startDateTime.split(':') : '';
            const endTimeSplit = departCondDataUnit.dateOrRange.endDateTime ?
                departCondDataUnit.dateOrRange.endDateTime.split(':') : '';

            const departureTimeFormUnit = {
                operator: departCondDataUnit.comparator,
                startHours: startTimeSplit[0],
                startMinutes: startTimeSplit[1],
                endHours: endTimeSplit[0],
                endMinutes: endTimeSplit[1]
            } as TimeFormGroup;

            departureTimeFormUnitArray.push(departureTimeFormUnit);
        }

        const departTimeForm = {
            departureTime: departureTimeFormUnitArray
        } as DepartureTimeComponentForm;

        if (departTimeForm) {
            this.setFormValues(departTimeForm);
        }
    }

    private setFormValues(depatureDateTimeFormModel: DepartureTimeComponentForm) {
        const departureTimeFormUnitArray = this.departureTimeGroup.get('departureTime') as FormArray;
        for (const departureTimeFormUnit of depatureDateTimeFormModel.departureTime) {
            departureTimeFormUnitArray.push(this.createDepartureTimeFormGroup());
        }
        this.removeDepartureTime(0);
        (this.departureTimeGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }

    private createDepartureTimeFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            startHours: ['', [Validators.required, this.validator.validateStartTimeHours]],
            startMinutes: ['', [Validators.required, this.validator.validateStartTimeMinutes]],
            endHours: ['', [Validators.required, this.validator.validateEndTimeHours]],
            endMinutes: ['', [Validators.required, this.validator.validateEndTimeMinutes]]
        });
    }
}
