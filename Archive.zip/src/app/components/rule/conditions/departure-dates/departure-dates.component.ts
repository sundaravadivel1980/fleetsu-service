// Framework imports
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
// Third party and own lib imports
import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';
// Local imports
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DepartureDateTimeComponentForm, DateTimeFormGroup, DatePickerDateRange } from '../../../../models/rule-form.model';
import { ComboBox, IdValue } from '../../../../models/ui-model';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { DateFormat } from '../../../../validators/date-format';
import { DateConstants } from '../../../../app.constants';
import { AppValidator } from 'src/app/validators/app-validator';
import { FormControl } from '@angular/forms/src/model';
import { RuleDetailFieldValidator } from 'src/app/validators/rule/rule-detail-field-validator';

@Component({
    selector: 'departure-dates',
    templateUrl: 'departure-dates.component.html',
    styleUrls: ['./departure-dates.component.scss'],
    providers: [{ provide: DateAdapter, useClass: DateFormat },
    {
        provide: MAT_DATE_FORMATS, useValue: DateConstants.APP_DATE_FORMATS
    }, DateFormat]
})

export class DepartureDatesComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public departureDateGroup: FormGroup;
    private departDateTimeCondDataArray: DateTimeCondition[];
    private operators: ComboBox[];
    private days: IdValue[];
    private carrierPrefDateFormat: string;
    /** Used for setting the date picker start and end restriction for start date and end date */
    private formDatePickerRange: DatePickerDateRange[];
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;
    private todayDate: Date = new Date();

    private commonFieldValidator = new RuleDetailFieldValidator();

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private datePipe: DatePipe,
                private messageService: MessageTranslationService,
                private dateAdapter: DateAdapter<Date>,
                private dateFormat: DateFormat) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators;
        this.days = this.appSingletonService.ruleJsonStore.Days;

         // The start date should be greater than today date. The date picker of end date will start with given start date
        this.formDatePickerRange = [{ endDatePickerMinDate: new Date(), startDatePickerMaxDate: null } as DatePickerDateRange];
    }

    public ngOnInit() {
        this.carrierPrefDateFormat = this.appSingletonService.carrierDateFormat;
        if (!this.carrierPrefDateFormat) {
            this.carrierPrefDateFormat = DateConstants.MM_DD_YYYY;
        }
        if (this.carrierPrefDateFormat === DateConstants.DD_MM_YYYY) {
            this.dateAdapter.setLocale('en-IN');
        }

        this.departureDateGroup = this.fb.group({
            departureDataLogicalUnits: this.fb.array([this.createDepartureDateFormGroup()])
        });

        this.setValues();
    }

    get departureDateFormArray(): FormArray {
        return this.departureDateGroup.get('departureDataLogicalUnits') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.departDateTimeCondDataArray = rule.condition.departureDateCondition;
        }
        if (this.departDateTimeCondDataArray && this.departDateTimeCondDataArray.length > 0) {
            this.setFormValuesFromData();
        } else {
            // All the days should be selected by default
            this.allChecked(0);
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam('acegui.rules.messages.form.validatiom.failed', 'Departure date condition');
            return null;
        }

        const dateTimeCondArray = [];
        for (const dateTimeFormUnit of this.departureDateFormArray.value) {
            const daysArray = [];
            if (dateTimeFormUnit.allDay) {
                daysArray.push('ALL');
            } else {
                if (dateTimeFormUnit.monday) { daysArray.push('MON'); }
                if (dateTimeFormUnit.tuesday) { daysArray.push('TUE'); }
                if (dateTimeFormUnit.wednesday) { daysArray.push('WED'); }
                if (dateTimeFormUnit.thursday) { daysArray.push('THU'); }
                if (dateTimeFormUnit.friday) { daysArray.push('FRI'); }
                if (dateTimeFormUnit.saturday) { daysArray.push('SAT'); }
                if (dateTimeFormUnit.sunday) { daysArray.push('SUN'); }
            }
            let dateAndTime: DateOrRange;
            if (dateTimeFormUnit.startDate || dateTimeFormUnit.endDate) {
                dateAndTime = new DateOrRange();

                if (dateTimeFormUnit.startDate) {
                    dateAndTime.startDateTime = RuleUtil.startDateTimeString(dateTimeFormUnit, this.datePipe);
                }
                if (dateTimeFormUnit.endDate) {
                    dateAndTime.endDateTime = RuleUtil.endDateTimeString(dateTimeFormUnit, this.datePipe);
                }
            }
            dateTimeCondArray.push({
                comparator: dateTimeFormUnit.operators,
                dayOfWeek: daysArray,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return dateTimeCondArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        const validator = new AppValidator();

        // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const dateTimeForm of this.departureDateFormArray.controls) {
                // Days required
                if (!dateTimeForm.get('allDay').value
                    && !dateTimeForm.get('friday').value
                    && !dateTimeForm.get('monday').value
                    && !dateTimeForm.get('saturday').value
                    && !dateTimeForm.get('sunday').value
                    && !dateTimeForm.get('thursday').value
                    && !dateTimeForm.get('tuesday').value
                    && !dateTimeForm.get('wednesday').value) {
                    this.hasErrors = true;
                    this.messageService.addError('acegui.rules.messages.days.required');
                }

                // If user provide the time, then date is required. Otherwise not.
                if (dateTimeForm.get('startHour').value || dateTimeForm.get('startMinute').value) {
                    if (!dateTimeForm.get('startDate').value) {
                        validator.triggerFieldValidation(dateTimeForm.get('startDate'));
                    }
                }

                if (dateTimeForm.get('endHour').value || dateTimeForm.get('endMinute').value) {
                    if (!dateTimeForm.get('endDate').value) {
                        validator.triggerFieldValidation(dateTimeForm.get('endDate'));
                    }
                }

                if (dateTimeForm.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const departDateFormUnit of this.departureDateFormArray.controls) {
            let emptyForm = true;
            if (departDateFormUnit.get('allDay').value
                || departDateFormUnit.get('friday').value
                || departDateFormUnit.get('monday').value
                || departDateFormUnit.get('saturday').value
                || departDateFormUnit.get('sunday').value
                || departDateFormUnit.get('thursday').value
                || departDateFormUnit.get('tuesday').value
                || departDateFormUnit.get('wednesday').value
                || departDateFormUnit.get('startHour').value
                || departDateFormUnit.get('startMinute').value
                || departDateFormUnit.get('startDate').value
                || departDateFormUnit.get('endHour').value
                || departDateFormUnit.get('endMinute').value
                || departDateFormUnit.get('endDate').value) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyForms.reverse()) {
            this.removeDepartureDates(emptyGroup);
        }
        if (this.departureDateFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addDepartureDates();
        }
    }

    private setFormValuesFromData() {
        const departDateTimeFormUnitArray = [];
        for (const departDateTimeDataUnit of this.departDateTimeCondDataArray) {
            let startDateTimeSplit = [];
            let startTimeSplit = [];
            if (departDateTimeDataUnit.dateOrRange && departDateTimeDataUnit.dateOrRange.startDateTime) {
                startDateTimeSplit = departDateTimeDataUnit.dateOrRange.startDateTime.split('T');
                if (startDateTimeSplit[1]) {
                    startTimeSplit = startDateTimeSplit[1].split(':');
                }
            }

            let endDateTimeSplit = [];
            let endTimeSplit = [];
            if (departDateTimeDataUnit.dateOrRange && departDateTimeDataUnit.dateOrRange.endDateTime) {
                endDateTimeSplit = departDateTimeDataUnit.dateOrRange.endDateTime.split('T');
                if (endDateTimeSplit[1]) {
                    endTimeSplit = endDateTimeSplit[1].split(':');
                }
            }
            this.formDatePickerRange.push({ endDatePickerMinDate: startDateTimeSplit[0], startDatePickerMaxDate: endDateTimeSplit[0] });
            const departDateTimeFormUnit = {
                operators: departDateTimeDataUnit.comparator,
                startDate: startDateTimeSplit[0],
                startHour: startTimeSplit[0],
                startMinute: startTimeSplit[1],
                endDate: endDateTimeSplit[0],
                endHour: endTimeSplit[0],
                endMinute: endTimeSplit[1]
            } as DateTimeFormGroup;

            if (departDateTimeDataUnit.dayOfWeek) {
                for (const dayWeek of departDateTimeDataUnit.dayOfWeek) {
                    switch (dayWeek) {
                        case 'ALL':
                            departDateTimeFormUnit.allDay = true;
                            departDateTimeFormUnit.monday = true;
                            departDateTimeFormUnit.tuesday = true;
                            departDateTimeFormUnit.wednesday = true;
                            departDateTimeFormUnit.thursday = true;
                            departDateTimeFormUnit.friday = true;
                            departDateTimeFormUnit.saturday = true;
                            departDateTimeFormUnit.sunday = true;
                            break;
                        case 'MON':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.monday = true;
                            break;
                        case 'TUE':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.tuesday = true;
                            break;
                        case 'WED':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.wednesday = true;
                            break;
                        case 'THU':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.thursday = true;
                            break;
                        case 'FRI':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.friday = true;
                            break;
                        case 'SAT':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.saturday = true;
                            break;
                        case 'SUN':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.sunday = true;
                            break;
                    }
                }
            }
            departDateTimeFormUnitArray.push(departDateTimeFormUnit);
        }

        const departDateTimeComponentForm = {
            departureDataLogicalUnits: departDateTimeFormUnitArray
        } as DepartureDateTimeComponentForm;

        if (departDateTimeComponentForm) {
            this.setFormValues(departDateTimeComponentForm);
        }
    }

    private setFormValues(depatureDateTimeFormModel: DepartureDateTimeComponentForm) {
        const departureDateTimeFormArray = this.departureDateGroup.get('departureDataLogicalUnits') as FormArray;
        for (const departureDateTimeFormUnit of depatureDateTimeFormModel.departureDataLogicalUnits) {
            departureDateTimeFormArray.push(this.createDepartureDateFormGroup());
        }
        this.removeDepartureDates(0);
        (this.departureDateGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }

    /**
     * The begining of date picker for end date will start with given start date.
     * If the start date is given as 3/23/2018, then user cannot set the end date before 3/23/2018
     *
     * @param event
     * @param i
     */
    private setMinEndDate(event: MatDatepickerInputEvent<Date>, i: number) {
        this.formDatePickerRange[i].endDatePickerMinDate = event.value;
        const formattedValue = event.targetElement as HTMLInputElement;
        this.dateFormat.validateDate(formattedValue.value, i, 'startDate', this.departureDateFormArray, this.carrierPrefDateFormat);
    }

    /**
     * The max start date cannot be greater than end date
     *
     * @param event
     * @param i
     */
    private setMaxStartDate(event: MatDatepickerInputEvent<Date>, i: number) {
        this.formDatePickerRange[i].startDatePickerMaxDate = event.value;
        const formattedValue = event.targetElement as HTMLInputElement;
        this.dateFormat.validateDate(formattedValue.value, i, 'endDate', this.departureDateFormArray, this.carrierPrefDateFormat);
    }

    private createDepartureDateFormGroup() {
        return this.fb.group({
            allDay: ['true'],
            monday: [''],
            tuesday: [''],
            wednesday: [''],
            thursday: [''],
            friday: [''],
            saturday: [''],
            sunday: [''],
            operators: 'EQ',
            // startDate: ['', this.commonFieldValidator.validateDate(this.carrierPrefDateFormat)],
            startDate: [''],
            startHour: '',
            startMinute: '',
            // endDate: ['', this.commonFieldValidator.validateDate(this.carrierPrefDateFormat)],
            endDate: [''],
            endHour: '',
            endMinute: ''
        });
    }

    private addDepartureDates() {
        this.departureDateFormArray.push(this.createDepartureDateFormGroup());
        this.allChecked(this.departureDateFormArray.length - 1);
        this.formDatePickerRange.push({ endDatePickerMinDate: new Date(), startDatePickerMaxDate: null });
    }

    private removeDepartureDates(i: number) {
        this.departureDateFormArray.removeAt(i);
        this.formDatePickerRange.splice(i, 1);
    }

    private allChecked(i) {
        for (const item of this.days) {
            this.departureDateFormArray.controls[i].get(item.id).setValue(
                this.departureDateFormArray.controls[i].get('allDay').value
            );
        }
    }

    private dayChecked(i) {
        const isAllChecked = [];
        for (const item of this.days) {
            isAllChecked.push(this.departureDateFormArray.controls[i].get(item.id).value);
        }
        this.departureDateFormArray.controls[i].get('allDay').setValue(
            isAllChecked.every(function(value: boolean) {
                console.log(value);
                return value === true;
            })
        );
    }
}
