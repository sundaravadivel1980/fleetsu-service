import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, PointOfCommencementCondition } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    PointOfCommencementFormModel,
    PointOfCommencementFormModelGroup,
    RuleDetailChildForm,
    } from '../../../../models/rule-form.model';

import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';

import { RuleUtil } from '../../rule.util.ts';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppUtil } from 'src/app/utility/app-util';

@Component({
    selector: 'point-of-commencement',
    templateUrl: 'point-of-commencement.component.html',
    styleUrls: ['./point-of-commencement.component.scss']
})

export class PointOfCommencementComponent implements  RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public pointOfCommencementGroup: FormGroup;
    public pocConditionDataArray: PointOfCommencementCondition[];

    public operators: ComboBox[];
    public ruleJsonStore: any;
    public listOfAirport: AutoCompleteChip[];

    private isEmptyCondition: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        this.ruleJsonStore = singletonService.ruleJsonStore;
        this.operators = this.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        this.listOfAirport = this.singletonService.getCombinedAirportsAndLocations();

        this.pointOfCommencementGroup = this.fb.group({
            pointOfCommencementLogicalUnit: this.fb.array([this.createpointOfCommencementLogicalUnit()])
        });
        this.setValues();
    }

    get pocFormArray(): FormArray{
        return this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.pocConditionDataArray = rule.condition.pointOfCommencementCondition;
        }
        if ( this.pocConditionDataArray && this.pocConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): PointOfCommencementCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const pocDataArray = [];
        for (const pocFormUnit of this.pocFormArray.value) {
            const pointOfCommencement = {
                comparator: pocFormUnit.operators
            } as PointOfCommencementCondition;

            const returnedObject =  RuleUtil.splitGroupAndNonGroup(pocFormUnit.location);
            if (returnedObject && returnedObject.groupArray.length > 0) {
                pointOfCommencement.cityGrouping = returnedObject.groupArray;
            }
            if (returnedObject && returnedObject.nonGroupArray.length > 0) {
                pointOfCommencement.city = returnedObject.nonGroupArray;
            }

            pocDataArray.push(pointOfCommencement) ;
        }
        return pocDataArray;
    }

    public validate() {
        this.removeEmptyForms();
    }

    public isEmpty() {
        return this.isEmptyCondition;
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        // when there is no airport selected from the UI, then remove the empty condition
        for (const pointOfCommencementLogicalUnit of this.pocFormArray.controls) {
            let emptyForm = true;
            if (pointOfCommencementLogicalUnit.get('location').value.length > 0) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const removeGroup of emptyForms.reverse()){
            this.removePointOfCommencementLogicalUnit(removeGroup);
        }
        if (this.pocFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addPointOfCommencementLogicalUnit();
        }
    }

    private setFormValuesFromData() {
        const pocFormUnitArray = [];
        for (const pocDataUnit of this.pocConditionDataArray) {
            const pocFormUnit = {
                operators: pocDataUnit.comparator
            } as PointOfCommencementFormModelGroup;

            const grouping = pocDataUnit.cityGrouping;
            const city = pocDataUnit.city ? pocDataUnit.city : [];
            const groupingStringArray = AppUtil.numberToStringArray(grouping);
            pocFormUnit.location = city.concat(groupingStringArray);

            pocFormUnitArray.push(pocFormUnit);
        }
        const pocComponentForm = {
            pointOfCommencementLogicalUnit: pocFormUnitArray
        } as PointOfCommencementFormModel;

        if (pocComponentForm) {
            this.setFormValues(pocComponentForm);
        }
    }

    private setFormValues(pointOfCommencementFromModel: PointOfCommencementFormModel) {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        for (const pointOfCommencementLogicalUnit of pointOfCommencementFromModel.pointOfCommencementLogicalUnit){
            control.push(this.createpointOfCommencementLogicalUnit());
        }
        this.removePointOfCommencementLogicalUnit(0);
        (this.pointOfCommencementGroup as FormGroup).patchValue(pointOfCommencementFromModel, { onlySelf: true });
    }

    private addPointOfCommencementLogicalUnit() {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        control.push(this.createpointOfCommencementLogicalUnit());
    }

    private removePointOfCommencementLogicalUnit(i: number) {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        control.removeAt(i);
    }

    private createpointOfCommencementLogicalUnit() {
        // If we get the operator list from service, then the service should return which operator is the default operator
        return this.fb.group({
            operators: 'EQ',
            location: ''
        });
    }

}
