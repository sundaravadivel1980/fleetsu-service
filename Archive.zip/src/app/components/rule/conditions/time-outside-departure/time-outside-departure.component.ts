import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, TimeDepartureCondition, Time } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, TimeOutsideDepartureComponentForm, DaysAndHoursFormGroup } from '../../../../models/rule-form.model';
import { MessageTranslationService } from 'src/app/services/message-translation.service';

@Component({
    selector: 'time-outside-departure',
    templateUrl: 'time-outside-departure.component.html',
    styleUrls: ['./time-outside-departure.component.scss']
})

export class TimeOutsideDepartureComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public timeOutsideDepartureForm: FormGroup;
    private timeOutsideDepartCondDataArray: TimeDepartureCondition[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder, private messageService: MessageTranslationService) {
        // empty
    }

    public ngOnInit() {
        this.timeOutsideDepartureForm = this.fb.group({
            timeOutsideDepartureUnit: this.fb.array([this.createTimeOutsideDepartureFormGroup()])
        });
        this.setValues();
    }

    get timeOutsideDepartureArray(): FormArray {
        return this.timeOutsideDepartureForm.get('timeOutsideDepartureUnit') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.timeOutsideDepartCondDataArray = rule.condition.timeOutsideDepartureCondition;
        }
        if ( this.timeOutsideDepartCondDataArray && this.timeOutsideDepartCondDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): TimeDepartureCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }
        const timeOutsideDepartDataArray = [];
        for (const timeOutsideDepartFormUnit of this.timeOutsideDepartureArray.value) {
            let timeData: Time;
            timeData = {
                days: timeOutsideDepartFormUnit.days,
                hours: timeOutsideDepartFormUnit.hours,
                minutes: timeOutsideDepartFormUnit.minutes
            } as Time;
            timeOutsideDepartDataArray.push({
                comparator: 'EQ',
                time: timeData
            } as TimeDepartureCondition);
        }
        return timeOutsideDepartDataArray;
    }

    public validate() {
      this.removeEmptyForms();
      this.hasErrors = false;

      if (this.isEmptyCondition) {
        for (const timeOutsideDepartFormUnit of this.timeOutsideDepartureArray.controls) {
            if (timeOutsideDepartFormUnit.status.toLowerCase() === 'invalid') {
                this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Time outside departure condition');
                this.hasErrors = true;
            }
        }
      }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;
        for (const timeOutsideDepartFormUnit of this.timeOutsideDepartureArray.controls) {
            let emptyForm = true;
            if (timeOutsideDepartFormUnit.get('days').value
            || timeOutsideDepartFormUnit.get('hours').value || timeOutsideDepartFormUnit.get('minutes').value) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyForms.reverse()){
            this.removeTimeOutsideDeparture(emptyGroup);
        }
        if (this.timeOutsideDepartureArray.length === 0) {
            this.isEmptyCondition = true;
            this.addTimeOutsideDeparture();
        }
    }

    private setFormValuesFromData() {
        const timeOutsideDepartFormUnitArray = [];

        for ( const timeOutsideDepartDataUnit of this.timeOutsideDepartCondDataArray) {
            const timeOutsideDepartFormUnit = {
                days: timeOutsideDepartDataUnit.time.days,
                hours: timeOutsideDepartDataUnit.time.hours,
                minutes: timeOutsideDepartDataUnit.time.minutes
            } as DaysAndHoursFormGroup;
            timeOutsideDepartFormUnitArray.push(timeOutsideDepartFormUnit);
        }
        const timeOutsideDepartureTimeForm =  {
            timeOutsideDepartureUnit: timeOutsideDepartFormUnitArray
        } as TimeOutsideDepartureComponentForm;

        if (timeOutsideDepartureTimeForm) {
            this.setFormValues(timeOutsideDepartureTimeForm);
        }
    }

    private setFormValues(timeDepartureFromModel: TimeOutsideDepartureComponentForm) {
        const control = this.timeOutsideDepartureForm.get('timeOutsideDepartureUnit') as FormArray;
        for (const classesLogicalUnit of timeDepartureFromModel.timeOutsideDepartureUnit){
            control.push(this.createTimeOutsideDepartureFormGroup());
        }
        this.removeTimeOutsideDeparture(0);
        (this.timeOutsideDepartureForm as FormGroup).patchValue(timeDepartureFromModel, { onlySelf: true });
    }

    private createTimeOutsideDepartureFormGroup() {
        return this.fb.group({
            days: [''],
            hours: [''],
            minutes: ['']
        });
    }

    private addTimeOutsideDeparture() {
        this.timeOutsideDepartureArray.push(this.createTimeOutsideDepartureFormGroup());
    }

    private removeTimeOutsideDeparture(i: number) {
        this.timeOutsideDepartureArray.removeAt(i);
    }
}
