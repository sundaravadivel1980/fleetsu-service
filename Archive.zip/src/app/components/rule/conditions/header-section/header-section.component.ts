import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material';

import { TranslateService } from '@ngx-translate/core';
import { RuleService, Rule, RuleRs, RqStandardPayload, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';
import { DialogsService } from '@dxc/tr-ux-ace-core/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { environment } from '../../../../../environments/environment';
import { AppConstants, TransactionType, RuleStatus } from '../../../../app.constants';
import { RuleUtil } from '../../rule.util';
import { RuleParamsService } from '../../../../services/rule/rule-params.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { RuleDetailChildForm, RuleDetailForm } from '../../../../models/rule-form.model';
import { AutoCompleteChip, ComboBox } from '../../../../models/ui-model';
import { AppValidator } from 'src/app/validators/app-validator';

const COMMA = 188;
const ENTER = 13;

@Component({
    selector: 'header-section',
    templateUrl: 'header-section.component.html',
    styleUrls: ['./header-section.component.scss']
})
export class HeaderSectionComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public headerSection: FormGroup;

    public statuses: ComboBox[];
    public chipKeywords: any;
    public disableIcons: boolean = true;
    public types: ComboBox[];
    private hasErrors: boolean = false;

    private URL: string = environment.RULE_URL;

    constructor(
        private fb: FormBuilder,
        private singletonService: AppSingletonService,
        private router: Router,
        private dialogsService: DialogsService,
        private paramsService: RuleParamsService,
        private ruleService: RuleService,
        private translateService: TranslateService,
        private messageService: MessageTranslationService) {

        const data = singletonService.ruleJsonStore;
        this.statuses = data.Status;
    }

    public ngOnInit() {
        let defaultTransactionType = TransactionType.ALL;
        this.types = this.singletonService.ruleJsonStore.TransactionTypes;

        if (this.childInput.type === AppConstants.ACTION_PARTIAL_CANCELLATION) {
            this.types = [{id: TransactionType.SELL, value: 'Sell'}];
            defaultTransactionType = 'SELL';
        }
        this.chipKeywords = this.childInput.keyword ? this.childInput.keyword : []; // Keywords initializing
        this.headerSection = this.fb.group({
            Status: ['', Validators.required], // Status initializing
            RuleName: ['', Validators.required], // RuleName initializing
            Keywords: [''],
            transactionType: [[defaultTransactionType], Validators.required],
            disableIcons: ''
        });

        this.setValues();

    }

    public setValues() {
        if (this.childInput.action) {
            this.headerSection.patchValue({RuleName: this.childInput.name});
            this.headerSection.patchValue({Status: this.childInput.status});
            this.headerSection.patchValue({Keywords: this.childInput.keyword});

            if (this.childInput.type === AppConstants.ACTION_PARTIAL_CANCELLATION) {
                this.headerSection.patchValue({transactionType: this.childInput.transaction});
            } else {
                const transIds = [];
                for ( const transTypes of this.types) {
                    if (transTypes.id !== TransactionType.ALL) {
                        transIds.push(transTypes.id);
                    }
                }
                const notSelectedTransaction = transIds.filter(item => this.childInput.transaction.indexOf(item) < 0);
                // If there is not selected transaction, then show only the selected transaction.
                // Otherwise show 'ALL'
                const transaction = notSelectedTransaction.length > 0 ? this.childInput.transaction : [TransactionType.ALL];
                this.headerSection.patchValue({transactionType: transaction});
            }
        }
        this.headerSection.get('disableIcons').setValue(true);
        if (!this.childInput.status) {
            this.headerSection.get('Status').disable();
            this.headerSection.get('disableIcons').setValue(false);
        }
    }

    public getValues() {
        this.validate();

        if (this.hasErrors) {
            return null;
        }

        let transactionValue = this.headerSection.get('transactionType').value;
        if (this.childInput.type !== AppConstants.ACTION_PARTIAL_CANCELLATION) {
            const transIds = [];
            for ( const transTypes of this.types) {
              if (transTypes.id !== TransactionType.ALL) {
                transIds.push(transTypes.id);
              }
            }
            let transactionTypeCheck: any = [];
            if (transactionValue && transactionValue.length > 0) {
              transactionTypeCheck = transactionValue.find(function(obj) { return obj === TransactionType.ALL; });
            }
            transactionValue = transactionTypeCheck === TransactionType.ALL ? transIds : transactionValue;
        }

        const ruleName =  this.headerSection.get('RuleName').value;
        const returnObject = new RuleDetailForm();
        returnObject.name = ruleName;
        returnObject.transaction = transactionValue;
        if (this.headerSection.get('Status').value ) {
            returnObject.status = this.headerSection.get('Status').value;
        } else {
            returnObject.status = RuleStatus.INACTIVE;
        }
        if (this.headerSection.get('Keywords').value) {
            returnObject.keywords = this.headerSection.get('Keywords').value;
        }
        return returnObject;
    }

    public validate() {
        this.hasErrors = false;
        const validator = new AppValidator();

        if (!this.headerSection.get('RuleName').value) {
            validator.setRequired(this.headerSection.get('RuleName'));
            this.messageService.addError('acegui.rules.messages.header.rule.name.required');
            this.hasErrors = true;
        }
        if (this.headerSection.get('transactionType').value.length === 0) {
            validator.setRequired(this.headerSection.get('transactionType'));
            this.messageService.addError('acegui.rules.messages.header.transaction.type.required');
            this.hasErrors = true;
        }

        return this.hasErrors;
    }

    public add(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;
        if ((value || '').trim()) {
            this.chipKeywords.push(value.trim());
            this.headerSection.get('Keywords').setValue(this.chipKeywords);
        }
        if (input) {
            input.value = '';
        }
    }

    public remove(keyword: any): void {
        const index = this.chipKeywords.indexOf(keyword);
        if (index >= 0) {
            this.chipKeywords.splice(index, 1);
            this.headerSection.get('Keywords').setValue(this.chipKeywords);
        }
    }

    public enableIconLinks() {
        this.headerSection.get('Status').enable();
        // this.headerSection.get('Status').setValue('SAVED');
        this.headerSection.get('disableIcons').setValue(true);
    }

    public deleteRule(ruleId: number, status: string) {
        let confirmMsg: string;
        if (status === 'INACT' || status === 'SIMUL') {
        confirmMsg = 'This action will permanently delete this rule and will not be avaliable in the future to either copy or edit';
        } else {
        confirmMsg = 'Are you sure you want to do this?';
        }
        this.dialogsService
            .confirm('Confirm Dialog', confirmMsg)
            .subscribe(res => {
                if (res) {
                    this.ruleService.deleteRule(this.URL + '/' + ruleId).subscribe(
                        (ruleResponse: RuleRs) => {
                            if (ruleResponse.rsStandardPayload.success) {
                                this.messageService.success('Rule Deleted Successfully', true);
                                this.router.navigate(['/rule']);
                            } else {
                                this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                            }
                        },
                        (error: HttpErrorResponse ) => {
                            this.messageService.httpError(error);
                        }
                    );
                } else {
                    this.messageService.warn('Delete action cancelled');
                }
        });
    }

    public exportRule(ruleId: number, ruleVersion: number) {
        const ruleArray = [];
        const rule = new Rule();
        rule.gid = ruleId;
        rule.version = ruleVersion;
        ruleArray.push(rule);
        RuleUtil.downloadExportData(ruleArray, this.ruleService, this.messageService);
    }

    public deactivateRule(id: number, version: number) {
        this.dialogsService
            .confirm('Confirm Dialog', 'Are you sure you want to do this?')
            .subscribe(res => {
                if (res) {
                    this.childInput.status = 'INACT';
                    const requestPayload = {
                        correlationId: '1', pointOfSale: null
                    } as RqStandardPayload;

                    const ruleData =  {
                        rqStandardPayload: requestPayload,
                        rule: [this.childInput]
                    } as RuleRq;

                    this.ruleService.updateRule(this.URL, ruleData).subscribe(
                        (ruleResponse: RuleRs) => {
                            if (ruleResponse.rsStandardPayload.success) {
                                this.messageService.success('Rule Deactivated Successfully', true);
                                this.router.navigate(['/rule']);
                            } else {
                                this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                            }
                        },
                        (error: HttpErrorResponse) => {
                            this.messageService.httpError(error);
                        }
                    );
                }
        });
    }

    public copyRule(id: number, version: number) {
        this.paramsService.params = {ruleId: 0, ruleVersion: 0, ruleAction: this.childInput.type,
             ruleNew: true, ruleTime: null, copyId: id, copyRuleVersion: version};
        this.router.navigate(['/rule/detail', 0 ]);
    }
}
