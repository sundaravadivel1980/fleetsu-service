import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, MarketFareActionInput, ClassCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import { RuleDetailChildForm, MarketFareComponentForm, MarketFareFormGroup } from '../../../../models/rule-form.model';
import { ComboBox } from '../../../../models/ui-model';
import { RuleUtil } from '../../rule.util.ts';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { RuleDetailFieldValidator } from 'src/app/validators/rule/rule-detail-field-validator';
import { CarrierPrefConstants } from 'src/app/app.constants';

@Component({
    selector: 'base-fare-adjustment',
    templateUrl: 'base-fare-adjustment.component.html',
    styleUrls: ['base-fare-adjustment.component.scss']
})
export class BaseFareAdjustmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public baseFareAdjustmentGroup: FormGroup;
    public carrierPrefCurrency: string;
    private baseFareActionInput: MarketFareActionInput;
    private commonFieldValidator = new RuleDetailFieldValidator();
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;
    private carrierPrefPercentage: string;
    private carrierPrefAmount: string;
    private carrierPrefDecimal: string;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
    }

    public ngOnInit() {
        this.carrierPrefCurrency = this.singletonService.carrierCurrency;
        this.carrierPrefPercentage =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.PERCENTAGE_RESTRICTION, this.singletonService.carrierPreferences);
        // this.carrierPrefPercentage = '1-999';
        this.carrierPrefAmount =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.AMOUNT_RESTRICTION, this.singletonService.carrierPreferences);
        // this.carrierPrefAmount = '1-9999';
        this.carrierPrefDecimal =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.AMOUNT_DECIMAL_RESTRICTION, this.singletonService.carrierPreferences);
        // this.carrierPrefDecimal = '3';
        this.baseFareAdjustmentGroup = this.fb.group({
            baseFareAdjustmentUnit: this.fb.array([this.createBaseFareFormGroup()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.baseFareActionInput = rule.action.marketFareAdjustmentActionInput;
        }
        if (this.baseFareActionInput) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): MarketFareActionInput {
        this.validate();

        if (this.hasErrors) {
            return null;
        }
        const dataArray = [];
        for (const baseFareAdjustmentUnit of this.baseFareFormArray.value) {
            const baseFareeAdjustmentActionInputData = new MarketFareActionInput();
            baseFareeAdjustmentActionInputData.amount = baseFareAdjustmentUnit.setFare;
            baseFareeAdjustmentActionInputData.changeAmount = baseFareAdjustmentUnit.amount ?
                baseFareAdjustmentUnit.amountSign + baseFareAdjustmentUnit.amount : '';
            baseFareeAdjustmentActionInputData.changePercent = baseFareAdjustmentUnit.basefarePercentage ?
                baseFareAdjustmentUnit.basefarePercentageSign + baseFareAdjustmentUnit.basefarePercentage : '';
            baseFareeAdjustmentActionInputData.maximum = baseFareAdjustmentUnit.maxAmount;
            baseFareeAdjustmentActionInputData.minimum = baseFareAdjustmentUnit.minAmount;
            dataArray.push(baseFareeAdjustmentActionInputData);
        }

        return dataArray[0];
    }

    public validate() {
        this.hasErrors = false;
        this.removeEmptyForms();

        if (this.isEmptyCondition) {
            this.hasErrors = true;
            this.messageService.addError('acegui.rules.messages.base.fare.condition.required');
        } else {
            for (const baseFareFormUnit of this.baseFareFormArray.controls) {
                if (baseFareFormUnit.status.toLowerCase() === 'invalid') {
                    this.messageService.addErrorWithParam(
                    'acegui.rules.messages.form.validatiom.failed', 'Base fare adjustment');
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;
        for (const baseFareFormUnit of this.baseFareFormArray.controls) {
            let emptyForm = true;
            if (baseFareFormUnit.value.amount || baseFareFormUnit.value.basefarePercentage ||
                baseFareFormUnit.value.setFare || baseFareFormUnit.value.minAmount || baseFareFormUnit.value.maxAmount) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyForms.reverse()) {
            this.removeBaseFareAdjustmentUnit(emptyGroup);
        }
        if (this.baseFareFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addBaseFareAdjustmentUnit();
        }
    }

    public numberPercentageDisable(value, index, args) {
        if (value === '') {
            this.baseFareFormArray.controls[index].get(args).enable();
            this.baseFareFormArray.controls[index].get(args + 'Sign').enable();
        } else {
            this.baseFareFormArray.controls[index].get(args).reset();
            this.baseFareFormArray.controls[index].get(args + 'Sign').reset();
            this.baseFareFormArray.controls[index].get(args + 'Sign').disable();
            this.baseFareFormArray.controls[index].get(args).disable();
        }

    }

    public enableDisableFields(value) {
        const fieldsList = ['amount', 'basefarePercentage', 'basefarePercentageSign', 'amountSign', 'minAmount', 'maxAmount'];
        if (value === '') {
            for (const field of fieldsList) {
                // this.bidPriceFormArray.controls[0].get(field).reset();
                this.baseFareFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.baseFareFormArray.controls[0].get(field).reset();
                this.baseFareFormArray.controls[0].get(field).disable();
            }
        }
    }

    get baseFareFormArray(): FormArray {
        return this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
    }

    private createBaseFareFormGroup() {
        return this.fb.group({
            amount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            amountSign: [''],
            basefarePercentage: ['', this.commonFieldValidator.validateNumberRange(this.carrierPrefPercentage)],
            basefarePercentageSign: [''],
            minAmount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            maxAmount: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            setFare: ['', this.commonFieldValidator.validateAmount(this.carrierPrefAmount, this.carrierPrefDecimal)],
            bookedClasses: '',
            cabinClasses: ''
        });
    }

    get baseFareUnit(): FormArray {
        return this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
    }

    private addBaseFareAdjustmentUnit() {
        this.baseFareUnit.push(this.createBaseFareFormGroup());
    }

    private removeBaseFareAdjustmentUnit(i: number) {
        this.baseFareUnit.removeAt(i);
    }

    private setFormValuesFromData() {
        const marketFareFromModelGroupData = [];

        const marketFareFromModelGroup = {} as MarketFareFormGroup;
        if (this.baseFareActionInput.changeAmount) {
            marketFareFromModelGroup.amount = Math.abs(this.baseFareActionInput.changeAmount);
            marketFareFromModelGroup.amountSign = this.baseFareActionInput.changeAmount > 0 ? '+' : '-';
        }
        if (this.baseFareActionInput.changePercent) {
            marketFareFromModelGroup.basefarePercentageSign = this.baseFareActionInput.changePercent > 0 ? '+' : '-';
            marketFareFromModelGroup.basefarePercentage = Math.abs(this.baseFareActionInput.changePercent);
        }
        marketFareFromModelGroup.maxAmount = this.baseFareActionInput.maximum;
        marketFareFromModelGroup.minAmount = this.baseFareActionInput.minimum;
        marketFareFromModelGroup.setFare = this.baseFareActionInput.amount;
        marketFareFromModelGroupData.push(marketFareFromModelGroup);
        const baseFareFormModel = {
            baseFareAdjustmentUnit: marketFareFromModelGroupData
        } as MarketFareComponentForm;

        if (baseFareFormModel) {
            this.setFormValues(baseFareFormModel);
        }
        if (marketFareFromModelGroup.setFare) {
            this.enableDisableFields(marketFareFromModelGroup.setFare);
        }
    }

    private setFormValues(marketFareFromModel: MarketFareComponentForm) {
        const control = this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
        for (const baseFareAdjustmentUnit of marketFareFromModel.baseFareAdjustmentUnit) {
            control.push(this.createBaseFareFormGroup());
        }
        this.removeBaseFareAdjustmentUnit(0);
        (this.baseFareAdjustmentGroup as FormGroup).patchValue(marketFareFromModel, { onlySelf: true });
    }
}
