import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, PointOfSaleCondition } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    PointOfSaleComponentForm,
    PointOfSaleFormGroup,
    RuleDetailChildForm
} from '../../../../models/rule-form.model';

import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';

import { RuleUtil } from '../../rule.util.ts';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from 'src/app/services/message-translation.service';
import { REGEX_CONSTANTS, CarrierPrefConstants, ConditionConstants } from 'src/app/app.constants';

@Component({
    selector: 'point-of-sale',
    templateUrl: 'point-of-sale.component.html',
    styleUrls: ['./point-of-sale.component.scss']
})

export class PointOfSaleComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public pointOfSaleGroup: FormGroup;
    public pointOfSaleComponentData: PointOfSaleCondition[];

    public operators: ComboBox[];

    /** POS Group Name */
    private posGroupList: AutoCompleteChip[];
    /** Business ID */
    private businessIdList: AutoCompleteChip[];
    /** Airline/GDS Code */
    private airlineGds: AutoCompleteChip[];
    /** Geographical City Code */
    private geographicalCode: AutoCompleteChip[];
    /** Country Code */
    private countryCode: AutoCompleteChip[];
    /** User type */
    private userTypeList: AutoCompleteChip[];
    /** GDS/OA City Code */
    private iataCityCode: AutoCompleteChip[];
    /** Originating System */
    private airlineCode: AutoCompleteChip[];
    /** Currency Code */
    private currencyCode: AutoCompleteChip[];
    private posFields: string[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    private maxPosGroup: string;
    private maxBusinessID: string;
    private maxAirlineCode: string;
    private maxIataNumber: string;
    private maxUserType: string;
    private maxPseudoCity: string;
    private maxCountryCode: string;
    private maxGeoCity: string;
    private maxOACity: string;
    private maxOrigSys: string;
    private maxCurrencyCode: string;
    private maxCommNumber: string;
    private maxInHouseCode: string;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService,
                private messageService: MessageTranslationService) {
        this.operators = singletonService.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        // Groupname, BusinessID, UserType data got from ref table date thru singleton
        this.posGroupList = this.singletonService.posGroups;
        this.businessIdList = this.singletonService.businessIds;
        this.userTypeList = this.singletonService.userTypes;
        this.getCarrierPreferences();

        this.posFields = ['businessID', 'airlineGds', 'iataNumber', 'pseudoCode', 'geographicalCode',
        'countryCode', 'userType', 'iataCityCode', 'airlineCode', 'currencyCode', 'requestCode', 'communicationNumber',
        'inhouseID'];

        this.pointOfSaleGroup = this.fb.group({
            pointOfSaleLogicalUnit: this.fb.array([this.createpointOfSaleLogicalUnit()])
        });

        this.setValues();
    }

    get posFormArray(): FormArray {
        return this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.pointOfSaleComponentData = rule.condition.pointOfSaleCondition;
        }
        if (this.pointOfSaleComponentData && this.pointOfSaleComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): PointOfSaleCondition[] {
        this.validate();

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Point of sale condition');
            return null;
        }

        if (this.isEmptyCondition) {
            return null;
        }

        const posConditionArray = [];
        for (const posFormUnit of this.posFormArray.value) {
            const pointOfSaleConditionalData = {} as PointOfSaleCondition;
            pointOfSaleConditionalData.comparator = posFormUnit.operator;
            if (posFormUnit.businessID) { pointOfSaleConditionalData.businessId = posFormUnit.businessID; }
            if (posFormUnit.airlineGds) { pointOfSaleConditionalData.carrierOrGds = posFormUnit.airlineGds; }
            if (posFormUnit.communicationNumber) {
                pointOfSaleConditionalData.communicationNumber = posFormUnit.communicationNumber;
            }
            if (posFormUnit.countryCode) { pointOfSaleConditionalData.country = posFormUnit.countryCode; }
            if (posFormUnit.currencyCode) { pointOfSaleConditionalData.currency = posFormUnit.currencyCode; }
            if (posFormUnit.airlineCode) {
                pointOfSaleConditionalData.originatingSystem = posFormUnit.airlineCode;
            }
            if (posFormUnit.iataCityCode) { pointOfSaleConditionalData.gdsOaCity = posFormUnit.iataCityCode; }
            if (posFormUnit.geographicalCode) {
                pointOfSaleConditionalData.geographicalCity = posFormUnit.geographicalCode;
            }
            if (posFormUnit.iataNumber) { pointOfSaleConditionalData.iataNumber = posFormUnit.iataNumber; }
            if (posFormUnit.requestCode) {
                pointOfSaleConditionalData.originatorsRequest = posFormUnit.requestCode;
            }
            if (posFormUnit.groupName) { pointOfSaleConditionalData.posGrouping = posFormUnit.groupName; }
            if (posFormUnit.inhouseID) { pointOfSaleConditionalData.region = posFormUnit.inhouseID; }
            if (posFormUnit.userType) { pointOfSaleConditionalData.userType = posFormUnit.userType; }
            if (posFormUnit.pseudoCode) { pointOfSaleConditionalData.pseudoCity = posFormUnit.pseudoCode; }
            posConditionArray.push(pointOfSaleConditionalData);
        }
        return posConditionArray;
    }

    public validate() {
        this.removeEmptyForms();
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const posFormUnit of this.posFormArray.controls) {
                if (posFormUnit.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    public isEmpty() {
        return this.isEmptyCondition;
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const posFormUnit of this.posFormArray.controls) {
            let emptyForm = true;
            if (posFormUnit.get('businessID').value.length > 0 || posFormUnit.get('airlineGds').value.length > 0 ||
                posFormUnit.get('communicationNumber').value.length > 0 || posFormUnit.get('countryCode').value.length > 0 ||
                posFormUnit.get('currencyCode').value.length > 0 || posFormUnit.get('airlineCode').value.length > 0 ||
                posFormUnit.get('iataCityCode').value.length > 0 || posFormUnit.get('geographicalCode').value.length > 0 ||
                posFormUnit.get('iataNumber').value.length > 0 || posFormUnit.get('requestCode').value.length > 0 ||
                posFormUnit.get('groupName').value.length > 0 || posFormUnit.get('pseudoCode').value.length > 0 ||
                posFormUnit.get('inhouseID').value.length > 0 || posFormUnit.get('userType').value.length > 0) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()) {
            this.removePointOfSaleLogicalUnit(emptyFormGroup);
        }
        if (this.posFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addPointOfSaleLogicalUnit();
        }
    }

    private addPointOfSaleLogicalUnit() {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        control.push(this.createpointOfSaleLogicalUnit());
    }

    private removePointOfSaleLogicalUnit(i: number) {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        control.removeAt(i);
    }

    private createpointOfSaleLogicalUnit() {
        return this.fb.group({
            operator: 'EQ',
            groupName: ['', this.groupPOSValidation.bind(this)],
            businessID: ['', this.enableDisableFields],
            airlineGds: ['', this.enableDisableFields],
            iataNumber: ['', Validators.compose([this.iataNumberValidation, this.enableDisableFields, this.checkDuplicate])],
            pseudoCode: ['', Validators.compose([this.enableDisableFields, this.inHousePseudoCodeValidation, this.checkDuplicate])],
            geographicalCode: ['', this.enableDisableFields],
            countryCode: ['', this.enableDisableFields],
            userType: ['', this.enableDisableFields],
            iataCityCode: ['', this.enableDisableFields],
            airlineCode: ['', this.enableDisableFields],
            currencyCode: ['', this.enableDisableFields],
            requestCode: ['', Validators.compose([this.enableDisableFields, this.requestCodeValidation, this.checkDuplicate])],
            communicationNumber: ['', Validators.compose([this.enableDisableFields, this.communicationCodeValidation, this.checkDuplicate])],
            inhouseID: ['', Validators.compose([this.enableDisableFields, this.inHousePseudoCodeValidation, this.checkDuplicate])],
            label: [true]
        });
    }

    private enableDisableFields(formGroup: FormGroup) {
        const formParent = formGroup.parent ? formGroup.parent : null;
        if (formParent && formGroup.parent) {
            if (formGroup.value && formGroup.value.length) {
                formParent.get('groupName').disable();
            } else if (!formGroup.value.length && formParent.get('groupName').disabled
                && !(formParent.get('businessID').value.length || formParent.get('airlineGds').value.length ||
                    formParent.get('iataNumber').value.length ||
                    formParent.get('pseudoCode').value.length || formParent.get('geographicalCode').value.length ||
                    formParent.get('countryCode').value.length || formParent.get('userType').value.length ||
                    formParent.get('iataCityCode').value.length || formParent.get('airlineCode').value.length ||
                    formParent.get('currencyCode').value.length || formParent.get('requestCode').value.length ||
                    formParent.get('communicationNumber').value.length || formParent.get('inhouseID').value.length)) {
                formParent.get('groupName').enable();
            }
        }
        return null;
    }

    private checkDuplicate(formGroup: FormGroup) {
        const { value } = formGroup;
        let isDuplicate = false;
        for (const val of formGroup.value) {
            const duplicateValues = value.filter((items) => items === val);
            if (duplicateValues.length > 1) {
                isDuplicate = true;
            }
        }
        if (isDuplicate) {
            return { error: true, errorMsg: 'acegui.rules.messages.duplicate.error' };
        }
    }

    private communicationCodeValidation(formGroup: FormGroup) {
        if (formGroup.value) {
            const regex = REGEX_CONSTANTS.ALPHA_25;
            for (const val of formGroup.value) {
                if (!val.match(regex)) {
                    return { communicationCodeError: true, errorMsg: 'regex.pattern.error.alpha25' };
                }
            }
        }
    }

    private requestCodeValidation(formGroup: FormGroup) {
        if (formGroup.value) {
            const regex = REGEX_CONSTANTS.ALPHA_9;
            for (const val of formGroup.value) {
                if (!val.match(regex)) {
                    return { requestCodeError: true, errorMsg: 'regex.pattern.error.alpha9' };
                }
            }
        }
    }

    private inHousePseudoCodeValidation(formGroup: FormGroup) {
        if (formGroup.value) {
            const regex = REGEX_CONSTANTS.ALPHA_10_WILD;
            for (const val of formGroup.value) {
                if (!val.match(regex)) {
                    return { inHousePseudoError: true, errorMsg: 'regex.pattern.error.alpha10Wild' };
                }
            }
        }
    }

    private iataNumberValidation(formGroup: FormGroup) {
        if (formGroup.value) {
            for (const val of formGroup.value) {
                if (!val.match(REGEX_CONSTANTS.IATA_NUMBER_WILDCARD)) {
                    return { iataError: true, errorMsg: 'IATA number should be 7-8 digits with or without *' };
                }
                if (val.match(REGEX_CONSTANTS.IATA_NUMBER_8)) {
                    if (val.substr(0, 7) % 7 !== Number(val.substr(7, 8))) {
                        return { iataError: true, errorMsg: 'IATA number should be multiple of 7' };
                    }
                }
            }
        }
    }

    private groupPOSValidation(formGroup: FormGroup) {
        // formGroup.disable();
        const formParent = formGroup.parent ? formGroup.parent.controls : null;
        if (formGroup.parent && this.posFields) {
            for (const i of this.posFields) {
                if (formGroup.parent && formGroup.value
                    && formGroup.value.length && !formParent[i].disabled) {
                    formParent[i].disable();
                } else if (formGroup.parent && formParent[i].disabled) {
                    formParent[i].enable();
                }
            }
        }
    }

    private setFormValuesFromData() {
        const pointOfSaleLogicalUnitArray = [];
        for (const pointOfSaleLogicalUnitData of this.pointOfSaleComponentData) {
            const pointOfSaleLogicalUnit = {} as PointOfSaleFormGroup;
            pointOfSaleLogicalUnit.operator = pointOfSaleLogicalUnitData.comparator ? pointOfSaleLogicalUnitData.comparator : '';
            pointOfSaleLogicalUnit.businessID = pointOfSaleLogicalUnitData.businessId ? pointOfSaleLogicalUnitData.businessId : '';
            pointOfSaleLogicalUnit.airlineGds = pointOfSaleLogicalUnitData.carrierOrGds ? pointOfSaleLogicalUnitData.carrierOrGds : '';
            pointOfSaleLogicalUnit.communicationNumber = pointOfSaleLogicalUnitData.communicationNumber ?
                pointOfSaleLogicalUnitData.communicationNumber : '';
            pointOfSaleLogicalUnit.countryCode = pointOfSaleLogicalUnitData.country ? pointOfSaleLogicalUnitData.country : '';
            pointOfSaleLogicalUnit.currencyCode = pointOfSaleLogicalUnitData.currency ? pointOfSaleLogicalUnitData.currency : '';
            pointOfSaleLogicalUnit.airlineCode = pointOfSaleLogicalUnitData.originatingSystem ? pointOfSaleLogicalUnitData.originatingSystem : '';
            pointOfSaleLogicalUnit.iataCityCode = pointOfSaleLogicalUnitData.gdsOaCity ? pointOfSaleLogicalUnitData.gdsOaCity : '';
            pointOfSaleLogicalUnit.geographicalCode = pointOfSaleLogicalUnitData.geographicalCity ? pointOfSaleLogicalUnitData.geographicalCity : '';
            pointOfSaleLogicalUnit.iataNumber = pointOfSaleLogicalUnitData.iataNumber ? pointOfSaleLogicalUnitData.iataNumber : '';
            pointOfSaleLogicalUnit.requestCode = pointOfSaleLogicalUnitData.originatorsRequest ? pointOfSaleLogicalUnitData.originatorsRequest : '';
            pointOfSaleLogicalUnit.groupName = pointOfSaleLogicalUnitData.posGrouping ? pointOfSaleLogicalUnitData.posGrouping : '';
            pointOfSaleLogicalUnit.inhouseID = pointOfSaleLogicalUnitData.region ? pointOfSaleLogicalUnitData.region : '';
            pointOfSaleLogicalUnit.userType = pointOfSaleLogicalUnitData.userType ? pointOfSaleLogicalUnitData.userType : '';
            pointOfSaleLogicalUnit.pseudoCode = pointOfSaleLogicalUnitData.pseudoCity ? pointOfSaleLogicalUnitData.pseudoCity : '';
            pointOfSaleLogicalUnit.label = true;
            pointOfSaleLogicalUnitArray.push(pointOfSaleLogicalUnit);
        }
        const pointOfSaleComponentFormModel = {
            pointOfSaleLogicalUnit: pointOfSaleLogicalUnitArray
        } as PointOfSaleComponentForm;
        if (pointOfSaleComponentFormModel) {
            this.setFormValues(pointOfSaleComponentFormModel);
        }
    }

    private setFormValues(pointOfSaleComponentFormModel: PointOfSaleComponentForm) {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        for (const pointOfSaleLogicalUnit of pointOfSaleComponentFormModel.pointOfSaleLogicalUnit) {
            control.push(this.createpointOfSaleLogicalUnit());
        }
        this.removePointOfSaleLogicalUnit(0);
        (this.pointOfSaleGroup as FormGroup).patchValue(pointOfSaleComponentFormModel, { onlySelf: true });
    }

    private getCarrierPreferences() {
        this.maxPosGroup =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_POS_GROUP, this.singletonService.carrierPreferences);
        this.maxPosGroup = this.maxPosGroup ? this.maxPosGroup : '10';
        this.maxBusinessID =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_BUSI_ID, this.singletonService.carrierPreferences);
        this.maxBusinessID = this.maxBusinessID ? this.maxBusinessID : '100';
        this.maxAirlineCode =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_AIRLINE_CODE, this.singletonService.carrierPreferences);
        this.maxAirlineCode = this.maxAirlineCode ? this.maxAirlineCode : '100';
        this.maxIataNumber =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_IATA_NUMBER, this.singletonService.carrierPreferences);
        this.maxIataNumber = this.maxIataNumber ? this.maxIataNumber : '2000';
        this.maxPseudoCity =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_PSEUDO_CITY, this.singletonService.carrierPreferences);
        this.maxPseudoCity = this.maxPseudoCity ? this.maxPseudoCity : '100';
        this.maxCountryCode =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_COUNTRY_CODE, this.singletonService.carrierPreferences);
        this.maxCountryCode = this.maxCountryCode ? this.maxCountryCode : '100';
        this.maxGeoCity =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_GEO_CITY, this.singletonService.carrierPreferences);
        this.maxGeoCity = this.maxGeoCity ? this.maxGeoCity : '100';
        this.maxOACity =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_OA_CITY, this.singletonService.carrierPreferences);
        this.maxOACity = this.maxOACity ? this.maxOACity : '10';
        this.maxOrigSys =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_ORIGINATING_SYSTEM, this.singletonService.carrierPreferences);
        this.maxOrigSys = this.maxOrigSys ? this.maxOrigSys : '20';
        this.maxCurrencyCode =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_CURRENCY_CODE, this.singletonService.carrierPreferences);
        this.maxCurrencyCode = this.maxCurrencyCode ? this.maxCurrencyCode : '20';
        this.maxCommNumber =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_COMM_NUMBER, this.singletonService.carrierPreferences);
        this.maxCommNumber = this.maxCommNumber ? this.maxCommNumber : '10';
        this.maxInHouseCode =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_INHOUSE_CODE, this.singletonService.carrierPreferences);
        this.maxInHouseCode = this.maxInHouseCode ? this.maxInHouseCode : '20';
        this.maxUserType =
        CarrierConfig.getCarrierPreferenceValue(CarrierPrefConstants.MAX_USER_TYPE, this.singletonService.carrierPreferences);
        this.maxUserType = this.maxUserType ? this.maxUserType : '5';
        this.countryCode = this.singletonService.countires;
        this.currencyCode = this.singletonService.currencies;

        // airlineGds (Airline/GDS), airlineCode (Originating system)
        const airlinesList = this.singletonService.airlines;
        this.airlineGds = airlinesList;
        this.airlineCode = airlinesList;
        // for geographicalCode (Geographical city code), iataCityCode (GDS/other airline city code)
        const airportList = this.singletonService.airports;
        this.geographicalCode = airportList;
        this.iataCityCode = airportList;
    }
}
