import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, MarketCondition, Market, OriginDestination } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppUtil } from '../../../../utility/app-util';
import {
    MarketComponentForm, MarketFormGroup,
    OriginDestinationFormGroup,
    RuleDetailChildForm
} from '../../../../models/rule-form.model';

import { ComboBox, AutoCompleteChip } from '../../../../models/ui-model';

import { RuleUtil } from '../../rule.util.ts';
import { FormControl } from '@angular/forms/src/model';
import { AppConstants, ConditionConstants } from 'src/app/app.constants';

import { Store } from '@ngrx/store';
import { AppState, PostModel } from '../../../../state-management/app-store.model';
import * as AppStoreActions from '../../../../state-management/app-store.action';
import { OnDestroy, AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { AppValidator } from 'src/app/validators/app-validator';

@Component({
    selector: 'market',
    templateUrl: 'market.component.html',
    styleUrls: ['./market.component.scss']
})
export class MarketComponent implements OnInit, RuleDetailChildForm, OnDestroy {
    @Input() public childInput: Rule;

    public title: string;
    public showSegment: boolean = false;

    public marketForm: FormGroup;
    private marketComponentData: MarketCondition[];

    private listOfAirport: AutoCompleteChip[];
    private marketGroups: AutoCompleteChip[];
    private operators: ComboBox[];
    private bidPriceTypes: AutoCompleteChip[];

    private legOrOAndD: string;
    private placeholderOrgin: string = 'Origin';
    private placeholderDest: string = 'Destination';

    private ruleJsonStore: any;

    // Will be true when the input is given for any segment form
    private emptySegmentForms: boolean = false;
    // Will be true when the input is given for any market form
    private emptyMarketForms: boolean = false;
    private hasErrors: boolean = false;

    private subscription: Subscription;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageTranslationService,
                private appStore: Store<PostModel>) {

        this.ruleJsonStore = singletonService.ruleJsonStore;
        this.operators = this.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        this.marketGroups = this.singletonService.marketGroups;
        this.listOfAirport = this.singletonService.getCombinedAirportsAndLocations();

        let defaultSelection = 'Market';
        if (this.childInput.type === AppConstants.ACTION_BID_PRICE_ADJ) {
            // Show the 'Adjust O&D Bid Price' and 'Adjust Leg Bid Price' boolean flags for bid price adjustment action
            this.bidPriceTypes = this.ruleJsonStore.AdjustBidPriceTypes;
            this.title = 'Market';
            defaultSelection = 'LEG';
            this.showSegment = false;
        } else {
            // Segments applicable for all actions other than bid price
            this.title = 'Markets and Segments';
            this.showSegment = true;
        }

        this.marketForm = this.fb.group({
            legOrOAndDFlag: [defaultSelection],
            marketLogicalUnits: this.fb.array([this.createMarketLogicalUnitFormGroup()]),
            segmentLogicalUnits: this.fb.array([this.createSegmentLogicalUnitFormGroup()])
        });

        this.setValues();

        if (this.childInput.type === AppConstants.ACTION_BID_PRICE_ADJ) {
            this.subscribeLegOrOAndDFlagChange();
        }
    }

    public ngOnDestroy() {
        if (this.childInput.type === AppConstants.ACTION_BID_PRICE_ADJ) {
            this.subscription.unsubscribe();
        }
    }

    public getLegOrOAndDFlag() {
        if (this.marketFormArray.parent.value.legOrOAndDFlag === 'Market' || this.marketFormArray.parent.value.legOrOAndDFlag === 'LEG') {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Sets the form values by getting the values from rule service response
     */
    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.marketComponentData = rule.condition.marketCondition;
        }

        if (this.marketComponentData && this.marketComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    /**
     * constructs the market component service request for create/update rule
     */
    public getValues() {
        this.validate();

        if (this.showSegment) {
            if (this.emptyMarketForms && this.emptySegmentForms) {
                if (this.singletonService.isRequiredCondition(this.childInput.type, ConditionConstants.MARKET)) {
                    this.messageService.addRequiredConditionError('Market or Segment');
                }
                return null;
            }
        } else {
            if (this.singletonService.isRequiredCondition(this.childInput.type, ConditionConstants.MARKET)) {
                if (this.emptyMarketForms) {
                    this.messageService.addRequiredConditionError('Market');
                    return null;
                }
           }
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam(
                'acegui.rules.messages.form.validatiom.failed', 'Market condition');
            return null;
        }

        // Array for MarketCondition. MarketCondition is the data container for both selected market and segment
        const marketConditionArray = [];

        // Construct the market data to be sent in the rule request for create/update
        if (!this.emptyMarketForms) {
            for (const marketForm of this.marketFormArray.value) {
                const marketData = new Market();
                if (marketForm.groupName && marketForm.groupName.length > 0) {
                    marketData.marketGrouping = marketForm.groupName;
                }

                const originDestinationDataArray = [];
                for (const originDestinationForm of marketForm.originDestinations) {
                    const originDestinationData = RuleUtil.splitAirportAndLocationGroup(originDestinationForm);
                    originDestinationData.bidirectional = originDestinationForm.bidirectional ? true : false;
                    originDestinationDataArray.push(originDestinationData);
                }

                marketData.market = originDestinationDataArray;

                const marketConditionData = new MarketCondition();
                marketConditionData.comparator = marketForm.operators;
                marketConditionData.market = [marketData];
                marketConditionArray.push(marketConditionData);
            }
        }

        // Construct the segment data to be sent in the rule request for create/update
        if (this.showSegment && !this.emptySegmentForms) {
            for (const segmentForm of this.segmentFormArray.value) {
                const segmentDataArray = [];
                let checkSegmentValidation: boolean = false;

                for (const segmentOAndDForm of segmentForm.originDestinations) {
                    if (segmentOAndDForm.destination || segmentOAndDForm.origin) {
                        checkSegmentValidation = true;
                    }
                    const segmentData = RuleUtil.splitAirportAndLocationGroup(segmentOAndDForm);
                    segmentDataArray.push(segmentData);
                }
                if (checkSegmentValidation) {
                    const segmentConditionData = new MarketCondition();
                    segmentConditionData.comparator = segmentForm.operators;
                    segmentConditionData.segment = segmentDataArray;
                    marketConditionArray.push(segmentConditionData);
                }
            }
        }
        return marketConditionArray;
    }

    public validate() {
        this.messageService.clear();
        this.hasErrors = false;

        // Remove the segment section when the origin and destination not entered by the user
        if (this.showSegment) {
           this.validateSegment();
        }

        // Remove the market section when the origin and destination (or) market group not entered by the user
        this.validateMarket();
    }

    public validateMarket() {
       this.removeEmptyMarketForms();

       const validator = new AppValidator();

       if (!this.emptyMarketForms) {
        for (const marketForm of this.marketFormArray.controls) {
            const originDestinations = marketForm.get('originDestinations') as FormArray;
            for (const originAndDestinationForm of originDestinations.controls) {
                if (!AppUtil.isArrayValueExists(originAndDestinationForm, 'origin')
                        && AppUtil.isArrayValueExists(originAndDestinationForm, 'destination')) {
                    validator.setRequired(originAndDestinationForm.get('origin'));
                    this.hasErrors = true;
                } else if (!AppUtil.isArrayValueExists(originAndDestinationForm, 'destination')
                        && AppUtil.isArrayValueExists(originAndDestinationForm, 'origin')) {
                    validator.setRequired(originAndDestinationForm.get('destination'));
                    this.hasErrors = true;
                }
            }
        }
       }
    }

    public validateSegment() {
        this.removeEmptySegmentForms();

        const validator = new AppValidator();

        if (!this.emptySegmentForms) {
            for (const segmentForm of this.segmentFormArray.controls) {
                const originDestinations = segmentForm.get('originDestinations') as FormArray;
                for (const originAndDestinationForm of originDestinations.controls) {
                    if (AppUtil.isEmptyArrayField(originAndDestinationForm, 'origin')
                            && AppUtil.isArrayValueExists(originAndDestinationForm, 'destination')) {
                        validator.setRequired(originAndDestinationForm.get('origin'));
                        this.hasErrors = true;
                    } else if (AppUtil.isEmptyArrayField(originAndDestinationForm, 'destination')
                            && AppUtil.isArrayValueExists(originAndDestinationForm, 'origin')) {
                        validator.setRequired(originAndDestinationForm.get('destination'));
                        this.hasErrors = true;
                    }
                }
            }
        }
    }

    private removeEmptyMarketForms() {
        let i: number = 0;
        const removableMarketFormGroups = [];
        this.emptyMarketForms = false;
        // Remove the market section when the origin and destination (or) market group not entered by the user
        for (const marketForm of this.marketFormArray.controls) {
            const originDestinations = marketForm.get('originDestinations') as FormArray;
            let j: number = 0;
            const removableOAndDFormGroups = [];
            let emptyMarketForm = true;
            for (const originAndDestinationForm of originDestinations.controls) {
                if (AppUtil.isArrayValueExists(originAndDestinationForm, 'origin')
                    || AppUtil.isArrayValueExists(originAndDestinationForm, 'destination')) {
                    emptyMarketForm = false;
                } else {
                    removableOAndDFormGroups.push(j);
                }
                j++;
            }
            if (originDestinations.controls.length === removableOAndDFormGroups.length) {
                removableOAndDFormGroups.splice(0, 1);
            }

            for (const removableOAndFormGroup of removableOAndDFormGroups.reverse()) {
                this.removeOriginDestFormGroup(i, removableOAndFormGroup, 'marketLogicalUnits');
            }

            if (marketForm.get('groupName').value.length > 0) {
                emptyMarketForm = false;
            }

            if (emptyMarketForm) {
                removableMarketFormGroups.push(i);
            }
            i++;
        }

        if (this.marketFormArray.controls.length === removableMarketFormGroups.length) {
            removableMarketFormGroups.splice(0, 1);
            this.emptyMarketForms = true;
            this.subscribeLegOrOAndDFlagChange();
        }
        for (const removableMarketFormGroup of removableMarketFormGroups.reverse()) {
            this.removeMarketLogicalUnit(removableMarketFormGroup, 'marketLogicalUnits');
        }
    }

    private removeEmptySegmentForms() {
        let n: number = 0;
        const removableSegmentFormGroups = [];
        this.emptySegmentForms = false;

        for (const segmentForm of this.segmentFormArray.controls) {
            let k: number = 0;
            let emptySegmentForm = true;
            const removableSegmentOAndDFormGroups = [];
            const originDestinations = segmentForm.get('originDestinations') as FormArray;

            for (const originDestinationForm of originDestinations.controls) {
                if (AppUtil.isArrayValueExists(originDestinationForm, 'origin')
                || AppUtil.isArrayValueExists(originDestinationForm, 'destination')) {
                    emptySegmentForm = false;
                } else {
                    removableSegmentOAndDFormGroups.push(k);
                }
                k++;
            }

            if (originDestinations.controls.length === removableSegmentOAndDFormGroups.length) {
                removableSegmentOAndDFormGroups.splice(0, 1);
            }

            for (const removableOAndDFormGroup of removableSegmentOAndDFormGroups.reverse()) {
                this.removeOriginDestFormGroup(n, removableOAndDFormGroup, 'segmentLogicalUnits');
            }
            if (emptySegmentForm) {
                removableSegmentFormGroups.push(n);
            }
            n++;
        }
        if (this.segmentFormArray.controls.length === removableSegmentFormGroups.length) {
            this.emptySegmentForms = true;
            removableSegmentFormGroups.splice(0, 1);
        }
        for (const removeGroup of removableSegmentFormGroups.reverse()) {
            this.removeMarketLogicalUnit(removeGroup, 'segmentLogicalUnits');
        }
    }

    private setFormValuesFromData() {
        // Array of maket and segment forms
        const marketLogicalUnitArray = [];
        const segmentLogicalUnitArray = [];

        // Construct the form values for edit from the service data
        for (const marketComponent of this.marketComponentData) {
            if (this.childInput.action.bidPriceAdjustmentActionInput) {
                this.legOrOAndD = this.childInput.action.bidPriceAdjustmentActionInput.adjustLeg ? 'LEG' : 'O&D';
            }

            // Market or segment form
            const marketOrSegmentLogicalUnit = new MarketFormGroup();
            const originDestinationArray = [];

            // Construct the segment form
            if (marketComponent.hasOwnProperty('segment')) {
                marketOrSegmentLogicalUnit.operators = marketComponent.comparator;
                for (const originDestination of marketComponent.segment) {
                    const originDestinationArrayData = RuleUtil.combineLocationGroupAndAirport(originDestination);
                    originDestinationArray.push(originDestinationArrayData);
                }
                marketOrSegmentLogicalUnit.originDestinations = originDestinationArray;
                segmentLogicalUnitArray.push(marketOrSegmentLogicalUnit);
            } else {
                // Construct the market form
                marketOrSegmentLogicalUnit.operators = marketComponent.comparator;

                for (const marketData of marketComponent.market) {
                    if (marketData.market) {
                        // Market has nested market. See the rules.xsd for more details
                        for (const originDestination of marketData.market) {
                            const originDestinationArrayData = RuleUtil.combineLocationGroupAndAirport(originDestination);
                            originDestinationArrayData.bidirectional = originDestination.bidirectional;
                            originDestinationArray.push(originDestinationArrayData);
                        }
                    } else {
                        const originDestinationArrayData = new OriginDestinationFormGroup();
                        originDestinationArray.push(originDestinationArrayData);
                    }
                    marketOrSegmentLogicalUnit.groupName = AppUtil.numberToStringArray(marketData.marketGrouping);
                }
                marketOrSegmentLogicalUnit.originDestinations = originDestinationArray;
                marketLogicalUnitArray.push(marketOrSegmentLogicalUnit);
            }
        }

        // Push the array of market forms and segment forms to market section for display
        const marketComponentFormModel = {
            legOrOAndDFlag: this.legOrOAndD,
            segmentLogicalUnits: segmentLogicalUnitArray,
            marketLogicalUnits: marketLogicalUnitArray
        } as MarketComponentForm;

        this.setFormValues(marketComponentFormModel);
    }

    private setFormValues(marketComponentFormModel: MarketComponentForm) {
        const segmentLogicalUnitsLength = marketComponentFormModel.segmentLogicalUnits.length;
        const controlSegmentLogicalUnits = this.marketForm.get('segmentLogicalUnits') as FormArray;
        let i: number;
        let j: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < segmentLogicalUnitsLength; i++) {
            controlSegmentLogicalUnits.push(this.createSegmentLogicalUnitFormGroup());
        }
        if (segmentLogicalUnitsLength > 0) {
            controlSegmentLogicalUnits.removeAt(i);
        }
        // generate fields for orginDestination
        i = 0;
        for (const segmentLogicalUnits of marketComponentFormModel.segmentLogicalUnits) {
            j = 0;
            const controlOrginDest = this.segmentFormArray.controls[i].get('originDestinations') as FormArray;
            for (const orginDestination of segmentLogicalUnits.originDestinations) {
                controlOrginDest.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j, 'segmentLogicalUnits');
            i++;
        }

        const marketLogicalUnitsLength = marketComponentFormModel.marketLogicalUnits.length;
        const controlMarketLogicalUnits = this.marketForm.get('marketLogicalUnits') as FormArray;

        // generate fields for marketLogic Unit
        for (i = 0; i < marketLogicalUnitsLength; i++) {
            controlMarketLogicalUnits.push(this.createMarketLogicalUnitFormGroup());
        }
        if (marketLogicalUnitsLength > 0) {
            controlMarketLogicalUnits.removeAt(i);
        }
        // generate fields for orginDestination
        i = 0;
        for (const marketLogicalUnits of marketComponentFormModel.marketLogicalUnits) {
            j = 0;
            const controlOrginDest = this.marketFormArray.controls[i].get('originDestinations') as FormArray;
            for (const orginDestination of marketLogicalUnits.originDestinations) {
                controlOrginDest.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j, 'marketLogicalUnits');
            i++;
        }
        // Push service response data into generated fields
        (this.marketForm as FormGroup).patchValue(marketComponentFormModel, { onlySelf: true });
    }

    get marketFormArray(): FormArray {
        return this.marketForm.get('marketLogicalUnits') as FormArray;
    }

    get segmentFormArray(): FormArray {
        return this.marketForm.get('segmentLogicalUnits') as FormArray;
    }

    private createMarketLogicalUnitFormGroup() {
        return this.fb.group({
            operators: ['EQ'],
            groupName: [[]],
            originDestinations: this.fb.array([this.createOriginDestFormGroup()])
        });
    }

    private createSegmentLogicalUnitFormGroup() {
        return this.fb.group({
            operators: ['EQ'],
            originDestinations: this.fb.array([this.createOriginDestFormGroup()])
        });
    }

    private createOriginDestFormGroup() {
        return this.fb.group({
            origin: [''],
            destination: [[]],
            bidirectional: ['']
        });
    }

    private addMarketLogicalUnit(formName) {
        const control = this.marketForm.get(formName) as FormArray;
        control.push(this.createMarketLogicalUnitFormGroup());
    }

    private removeMarketLogicalUnit(i: number, formName) {
        const control = this.marketForm.get(formName) as FormArray;
        control.removeAt(i);
    }

    private addOriginDestFormGroup(j: number, fromName) {
        const control = this.marketForm.get(fromName)['controls'][j].get('originDestinations') as FormArray;
        control.push(this.createOriginDestFormGroup());
    }

    private removeOriginDestFormGroup(j: number, i: number, fromName) {
        const control = this.marketForm.get(fromName)['controls'][j].get('originDestinations') as FormArray;
        control.removeAt(i);
    }

    private subscribeLegOrOAndDFlagChange() {
        this.subscription =  this.marketForm.get('legOrOAndDFlag').valueChanges.subscribe(
            (data: string) => {
                if (data === 'LEG') {
                    this.title = 'Market';
                    this.placeholderOrgin = 'Leg Origin';
                    this.placeholderDest = 'Leg Destination';
                } else {
                    this.title = 'Market';
                    this.placeholderOrgin = 'Origin';
                    this.placeholderDest = 'Destination';
                }
                // Store the leg or O&D selection in the appstore, so that bid price component can subscribe the flag and enable/disable GSA fields.
                // Bid price GSA applicable only for leg based bid price adjustment
                this.appStore.dispatch(new AppStoreActions.MarketLegOrOD(data));
            }
        );
    }

}
