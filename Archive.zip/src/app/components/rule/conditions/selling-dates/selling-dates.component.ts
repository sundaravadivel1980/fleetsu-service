import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, SellingDateTimeComponentForm, DateTimeFormGroup, DatePickerDateRange } from '../../../../models/rule-form.model';
import { ComboBox, IdValue } from '../../../../models/ui-model';
import { AppSingletonService } from '../../../../app-singleton.service';
import { MessageTranslationService } from '../../../../services/message-translation.service';
import { DateFormat } from '../../../../validators/date-format';
import { DateConstants } from '../../../../app.constants';
import { FormControl } from '@angular/forms/src/model';
import { AppValidator } from 'src/app/validators/app-validator';

@Component({
    selector: 'selling-dates',
    templateUrl: 'selling-dates.component.html',
    styleUrls: ['./selling-dates.component.scss'],
    providers: [{ provide: DateAdapter, useClass: DateFormat },
    {
        provide: MAT_DATE_FORMATS, useValue: DateConstants.APP_DATE_FORMATS
    }, DateFormat]
})
export class SellingDatesComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public sellingDateGroup: FormGroup;
    public carrierPrefCurrency: string;
    private sellingDateTimeCondDataArray: DateTimeCondition[];

    private operators: ComboBox[];
    private days: IdValue[];
    private todayDate: Date = new Date();
    private formDateLimitArray: DatePickerDateRange[];
    private carrierPrefDateFormat: string;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private datePipe: DatePipe,
                private messageService: MessageTranslationService,
                private dateAdapter: DateAdapter<Date>,
                private dateFormat: DateFormat) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators;
        this.days = this.appSingletonService.ruleJsonStore.Days;

        this.formDateLimitArray = [{ endDatePickerMinDate: new Date(), startDatePickerMaxDate: null } as DatePickerDateRange];
    }

    public ngOnInit() {
        this.carrierPrefDateFormat = this.appSingletonService.carrierDateFormat;
        this.carrierPrefCurrency = this.appSingletonService.carrierCurrency;

        if (!this.carrierPrefDateFormat) {
            this.carrierPrefDateFormat = DateConstants.MM_DD_YYYY;
        }
        if (this.carrierPrefDateFormat === DateConstants.DD_MM_YYYY) {
            this.dateAdapter.setLocale('en-IN');
        }
        this.sellingDateGroup = this.fb.group({
            sellingDateArray: this.fb.array([this.createSellingDateFormGroup()])
        });

        this.setValues();
    }

    get sellingDateFormArray() {
        return this.sellingDateGroup.get('sellingDateArray') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.condition) {
            this.sellingDateTimeCondDataArray = rule.condition.sellingDateTimeCondition;
        }
        if ( this.sellingDateTimeCondDataArray && this.sellingDateTimeCondDataArray.length > 0 ) {
            this.setFormValuesFromData();
        } else {
            this.selectAllDays(0);
        }
    }

    public getValues() {

        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            this.messageService.addErrorWithParam('acegui.rules.messages.form.validatiom.failed', 'Selling date condition');
            return null;
        }

        // Array of values to be sent in the rule request to service
        const sellingDateConditionArray = [];

        for (const sellDateFormUnit of this.sellingDateFormArray.value) {
            const daysArray = [];
            if (sellDateFormUnit.allDay) {
                daysArray.push('ALL');
            } else {
                if (sellDateFormUnit.monday) { daysArray.push('MON'); }
                if (sellDateFormUnit.tuesday) { daysArray.push('TUE'); }
                if (sellDateFormUnit.wednesday) { daysArray.push('WED'); }
                if (sellDateFormUnit.thursday) { daysArray.push('THU'); }
                if (sellDateFormUnit.friday) { daysArray.push('FRI'); }
                if (sellDateFormUnit.saturday) { daysArray.push('SAT'); }
                if (sellDateFormUnit.sunday) { daysArray.push('SUN'); }
            }
            let dateAndTime: DateOrRange;
            if (sellDateFormUnit.startDate || sellDateFormUnit.endDate) {
                dateAndTime = new DateOrRange();

                if (sellDateFormUnit.startDate) {
                    dateAndTime.startDateTime = RuleUtil.startDateTimeString(sellDateFormUnit, this.datePipe);
                }
                if (sellDateFormUnit.endDate) {
                    dateAndTime.endDateTime = RuleUtil.endDateTimeString(sellDateFormUnit, this.datePipe);
                }
            }
            sellingDateConditionArray.push( {
                comparator: sellDateFormUnit.operators,
                dayOfWeek: daysArray,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return sellingDateConditionArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        const validator = new AppValidator();

         // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const dateTimeForm of this.sellingDateFormArray.controls) {
                if (!dateTimeForm.get('allDay').value
                            && !dateTimeForm.get('friday').value
                            && !dateTimeForm.get('monday').value
                            && !dateTimeForm.get('saturday').value
                            && !dateTimeForm.get('sunday').value
                            && !dateTimeForm.get('thursday').value
                            && !dateTimeForm.get('tuesday').value
                            && !dateTimeForm.get('wednesday').value) {
                                this.hasErrors = true;
                                this.messageService.addError('acegui.rules.messages.days.required');
                }

                // If user provide the time, then date is required. Otherwise not.
                if (dateTimeForm.get('startHour').value || dateTimeForm.get('startMinute').value) {
                    if (!dateTimeForm.get('startDate').value) {
                        validator.triggerFieldValidation(dateTimeForm.get('startDate'));
                    }
                }

                if (dateTimeForm.get('endHour').value || dateTimeForm.get('endMinute').value) {
                    if (!dateTimeForm.get('endDate').value) {
                        validator.triggerFieldValidation(dateTimeForm.get('endDate'));
                    }
                }

                if (dateTimeForm.status.toLowerCase() === 'invalid') {
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        // Remove the selling dates component from the array when there is no day selected
        for (const sellDateFormUnit of this.sellingDateFormArray.controls) {
            let emptyForm = true;
            if (sellDateFormUnit.get('allDay').value
                 || sellDateFormUnit.get('friday').value
                 || sellDateFormUnit.get('monday').value
                 || sellDateFormUnit.get('saturday').value
                 || sellDateFormUnit.get('sunday').value
                 || sellDateFormUnit.get('thursday').value
                 || sellDateFormUnit.get('tuesday').value
                 || sellDateFormUnit.get('wednesday').value
                 || sellDateFormUnit.get('startHour').value
                 || sellDateFormUnit.get('startMinute').value
                 || sellDateFormUnit.get('startDate').value
                 || sellDateFormUnit.get('endHour').value
                 || sellDateFormUnit.get('endMinute').value
                 || sellDateFormUnit.get('endDate').value) {
                    emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i) ;
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()){
            this.removeSellingDates(emptyFormGroup);
        }
        if (this.sellingDateFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addSellingDates();
        }
    }

    private setFormValuesFromData() {
        const sellingDateTimeFormUnitArray = [];

        for ( const sellingDateTimeDataUnit of this.sellingDateTimeCondDataArray) {

            let startDateTimeSplit = [];
            let startTimeSplit = [];
            if (sellingDateTimeDataUnit.dateOrRange && sellingDateTimeDataUnit.dateOrRange.startDateTime) {
                startDateTimeSplit =  sellingDateTimeDataUnit.dateOrRange.startDateTime.split('T');
                if (startDateTimeSplit[1]) {
                    startTimeSplit =  startDateTimeSplit[1].split(':');
                }
            }

            let endDateTimeSplit = [];
            let endTimeSplit = [];
            if (sellingDateTimeDataUnit.dateOrRange && sellingDateTimeDataUnit.dateOrRange.endDateTime) {
                endDateTimeSplit = sellingDateTimeDataUnit.dateOrRange.endDateTime.split('T');
                if (endDateTimeSplit[1]) {
                    endTimeSplit = endDateTimeSplit[1].split(':');
                }
            }
            this.formDateLimitArray.push({ endDatePickerMinDate: startDateTimeSplit[0], startDatePickerMaxDate: endDateTimeSplit[0] });
            const sellDateTimeFormUnit = {
                operators: sellingDateTimeDataUnit.comparator,
                startDate: startDateTimeSplit[0],
                startHour: startTimeSplit[0],
                startMinute: startTimeSplit[1],
                endDate: endDateTimeSplit[0],
                endHour: endTimeSplit[0],
                endMinute: endTimeSplit[1]
            } as DateTimeFormGroup;

            if (sellingDateTimeDataUnit.dayOfWeek) {
                for ( const dayWeek of sellingDateTimeDataUnit.dayOfWeek) {
                    switch (dayWeek) {
                        case 'ALL':
                            sellDateTimeFormUnit.allDay = true;
                            sellDateTimeFormUnit.monday = true;
                            sellDateTimeFormUnit.tuesday = true;
                            sellDateTimeFormUnit.wednesday = true;
                            sellDateTimeFormUnit.thursday = true;
                            sellDateTimeFormUnit.friday = true;
                            sellDateTimeFormUnit.saturday = true;
                            sellDateTimeFormUnit.sunday = true;
                            break;
                        case 'MON':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.monday = true;
                            break;
                        case 'TUE':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.tuesday = true;
                            break;
                        case 'WED':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.wednesday = true;
                            break;
                        case 'THU':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.thursday = true;
                            break;
                        case 'FRI':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.friday = true;
                            break;
                        case 'SAT':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.saturday = true;
                            break;
                        case 'SUN':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.sunday = true;
                            break;
                    }
                }
            }
            sellingDateTimeFormUnitArray.push(sellDateTimeFormUnit);
        }

        const sellingDateTimeFormModel = {
            sellingDateArray: sellingDateTimeFormUnitArray
        } as SellingDateTimeComponentForm;

        if (sellingDateTimeFormModel) {
            this.setFormValues(sellingDateTimeFormModel);
        }
    }

    private setFormValues(depatureDateTimeFormModel: SellingDateTimeComponentForm) {
        const sellingDateFormArray = this.sellingDateGroup.get('sellingDateArray') as FormArray;
        for (const sellingDateFormUnit of depatureDateTimeFormModel.sellingDateArray){
            sellingDateFormArray.push(this.createSellingDateFormGroup());
        }
        this.removeSellingDates(0);
        (this.sellingDateGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }

    /**
     * The begining of date picker for end date will start with given start date.
     * If the start date is given as 3/23/2018, then user cannot set the end date before 3/23/2018
     *
     * @param event
     * @param i
     */
    private setMinEndDate(event: MatDatepickerInputEvent<Date>, i: number) {
        this.formDateLimitArray[i].endDatePickerMinDate = event.value;
        const formattedValue = event.targetElement as HTMLInputElement;
        this.dateFormat.validateDate(formattedValue.value, i, 'startDate', this.sellingDateFormArray, this.carrierPrefDateFormat);
    }

    /**
     * The max start date cannot be greater than end date
     *
     * @param event
     * @param i
     */
    private setMaxStartDate(event: MatDatepickerInputEvent<Date>, i: number) {
        this.formDateLimitArray[i].startDatePickerMaxDate = event.value;
        const formattedValue = event.targetElement as HTMLInputElement;
        this.dateFormat.validateDate(formattedValue.value, i, 'endDate', this.sellingDateFormArray, this.carrierPrefDateFormat);
    }

    private createSellingDateFormGroup() {
        return this.fb.group({
            allDay: ['true'],
            monday: [''],
            tuesday: [''],
            wednesday: [''],
            thursday: [''],
            friday: [''],
            saturday: [''],
            sunday: [''],
            operators: 'EQ',
            startDate: '',
            startHour: '',
            startMinute: '',
            endDate: '',
            endHour: '',
            endMinute: ''
        });
    }

    private addSellingDates() {
        this.sellingDateFormArray.push(this.createSellingDateFormGroup());
        this.selectAllDays(this.sellingDateFormArray.length - 1);
        this.formDateLimitArray.push({ endDatePickerMinDate: new Date(), startDatePickerMaxDate: null });
    }

    private removeSellingDates(i: number) {
        this.sellingDateFormArray.removeAt(i);
        this.formDateLimitArray.splice(i, 1);
    }

    private selectAllDays(i) {
        for (const item of this.days) {
            this.sellingDateFormArray.controls[i].get(item.id).setValue(
                this.sellingDateFormArray.controls[i].get('allDay').value
            );
        }
    }

    private selectDay(i) {
        const selectedDays = [];
        for (const item of this.days) {
            selectedDays.push(this.sellingDateFormArray.controls[i].get(item.id).value);
        }
        this.sellingDateFormArray.controls[i].get('allDay').setValue(
            selectedDays.every(function(value: boolean){
                return value === true;
            })
        );
    }
}
