/**
 * Angular 2 decorators and services
 */
import {
  Component,
  OnInit,
  ViewEncapsulation
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { Router } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';

import { AppSingletonService } from '../../app-singleton.service';
import { AppJsonDataService } from '../../app-json-data.service';
import { environment } from '../../../environments/environment';

/**
 * App Component
 * Top Level Component
 */
@Component({
  selector: 'app',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './app.component.scss'
  ],
  templateUrl: './app.component.html',
  providers: []

})
export class AppComponent implements OnInit, AfterViewInit {
  public appName = 'ACE Application';
  // public selectedNavItem: number = 1;
  public isMarketSearchEnabled: boolean = false;
  public currentApp: string = 'Rule Engine';

  constructor(
    public router: Router,
    public translate: TranslateService,
    private jsonService: AppJsonDataService,
    private singletonService: AppSingletonService) {

    console.log('Appcomponent constructor ');
    translate.setDefaultLang('en');
    translate.use('en');

    this.jsonService.getRuleJson().subscribe(
      (data: any) => {
        singletonService.ruleJsonStore = data;
      },
      (error: any) => {
        console.log(error);
      }
    );

    this.jsonService.getConfigJson().subscribe(
      (configData: any) => {
        singletonService.configJsonStore = configData;
      },
      (error: any) => {
        console.log(error);
      }
    );

    this.jsonService.getMarketSearchJson().subscribe(
      (data: any) => {
        singletonService.marketSearchStore = data;
        this.isMarketSearchEnabled = this.singletonService.marketSearchStore.isMarketSearchEnabled;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  public ngOnInit() {
    console.log('AppComponent is initialized');
    this.singletonService.loadAll();
  }

  public ngAfterViewInit() {
    console.log('Appcomponent after view init');
  }

  public navigateToPage($event) {
    // this.selectedNavItem = $event.value;
    // this.router.navigate([this.navItems[$event.value].Link]);
  }

  public navigateToModule(moduleName: string) {
    if (moduleName === 'RE') {
      this.singletonService.currentApp = 'Rule Engine';
      this.router.navigate(['/rule']);
    } else {
      this.singletonService.currentApp = 'Market Search';
      this.router.navigate(['/marketsearch']);
    }
  }

}
