import { Directive, TemplateRef, ViewContainerRef, Input, HostListener, HostBinding } from '@angular/core';

@Directive({
    selector: '[showIfAdditional]'
})

export class ShowIfAdditionalDirective {
    private component: any;
    private tRef: TemplateRef<any>;
    private opened: boolean;
    private vRef: ViewContainerRef;

    constructor(public vcRef: ViewContainerRef) { }

    @Input() set showIfAdditional(value: any) {
        if (value !== this.component) {
            this.component = value;
        }
    }
    @Input('showIfAdditionalContent') set template(value: TemplateRef<any>) {
        if (value !== this.tRef) {
            this.tRef = value;
        }
    }

    @Input('contRef') set containerRefContent(value: ViewContainerRef) {
        this.vRef = value as ViewContainerRef;
        if (value !== this.vRef) {
            this.vRef = value;
        }
    }

    @HostListener('click') public onClick(): void {
        this.toggle();
    }

    public toggle(): void {
        if (this.opened) {
            this.vRef.clear();
        } else {
            if (this.tRef && this.component) {
                this.vRef.createEmbeddedView(this.tRef, { $implicit: this.component });
            }
        }
        this.opened = this.vRef.length > 0;
    }
}
