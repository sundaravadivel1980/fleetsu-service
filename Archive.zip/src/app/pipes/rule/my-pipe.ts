import { Pipe, PipeTransform } from '@angular/core';
import { AppSingletonService } from '../../app-singleton.service';

@Pipe({ name: 'myPipe' })

export class MyPipe implements PipeTransform {
  private ruleTypes: any;
  private ruleStatus: any;
  public constructor(private singletonService: AppSingletonService) {
    this.ruleTypes = singletonService.ruleJsonStore.RuleTypes;
    this.ruleStatus = singletonService.ruleJsonStore.RuleStatus;
  }
  public transform(value: any, args: string): string {
    let transformedData: string;
    switch (args) {
      case 'ruleType': {
        transformedData = this.getRuleType(value);
        break;
      }
      case 'ruleStatus': {
        transformedData = this.getRuleStatus(value);
        break;
      }
      case 'arrayToString': {
        transformedData = value ? value.join() : '';
        break;
      }
      default: {
        transformedData = 'Not valid pipe';
        break;
      }
    }
    return transformedData;
  }

  private getRuleType(value: string): string {
    let transformedData: string;
    for (const item of this.ruleTypes) {
      if (item.id === value) {
        transformedData = item.name;
      }
    }
    return transformedData;
  }

  private getRuleStatus(value: string): string {
    let transformedData: string;
    for (const item of this.ruleStatus) {
      if (item.id === value) {
        transformedData = item.value;
      }
    }
    return transformedData;
  }

}
