import { Routes } from '@angular/router';
import { NoContentComponent } from './components/no-content';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './services/auth.guard';

export const ROUTES: Routes = [
  { path: '', redirectTo: '/rule',  pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'rule', loadChildren: './components/rule#RuleModule'},
  // { path: 'rule', canActivate: [AuthGuard], loadChildren: './components/rule#RuleModule'},
  // { path: 'groups', loadChildren: './components/grouping#GroupingModule'},
  { path: 'marketsearch',  loadChildren: './components/marketsearch#MarketSearchModule'},
  { path: '**',    component: NoContentComponent }
];
