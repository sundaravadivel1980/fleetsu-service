import { NgModule, ModuleWithProviders } from '@angular/core';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { AppSingletonService } from './app-singleton.service';
import { MessageTranslationService } from './services/message-translation.service';

@NgModule({
  imports: [ ],
  declarations: [],
  exports: []
})
export class SharedModule {
  // Should be called once inside the app module
  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [ MessageService, AppSingletonService, MessageTranslationService ]
    };
  }
}
