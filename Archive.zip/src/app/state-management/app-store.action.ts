import { Action } from '@ngrx/store';
import { GroupModel, Group } from './app-store.model';

export const MARKET_LEGOROD = '[Post] MarketLegOrOD';
export class MarketLegOrOD implements Action {
    public readonly type = MARKET_LEGOROD;

    constructor(public payload: string) {
    }
}

export const NEW_ACTION = '[Group] NewAction';
export const EDIT_ACTION = '[Group] EditAction';
export const SAVE_ACTION = '[Group] SaveAction';

export class NewAction implements Action {
    public readonly type = NEW_ACTION;
    constructor(public payload: GroupModel) {
        console.log(this.type);
    }
}
export class EditAction implements Action {
    public readonly type = EDIT_ACTION;
    constructor(public payload: GroupModel) {
    }
}
export class SaveAction implements Action {
    public readonly type = SAVE_ACTION;
    constructor(public payload: GroupModel) {
    }
}
export type All = MarketLegOrOD | NewAction | EditAction | SaveAction;
// export type All = MarketLegOrOD;
