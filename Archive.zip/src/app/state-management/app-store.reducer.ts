import * as Actions from './app-store.action';
import { PostModel, GroupModel } from './app-store.model';

export type Action = Actions.All;

// Helper function to create new state
const newState = (state, newData) => {
    return Object.assign({}, state, newData);
};

const defaultPostState: PostModel = {
    marketLegOrOD: 'O&D',
};

export function postReducer(state: string, action: Action) {
    switch (action.type) {
        case Actions.MARKET_LEGOROD:
            return newState(state, { marketLegOrOD: action.payload });
        default:
            return defaultPostState;
    }
}

const defaultGroupState: GroupModel = {
    type: null
} as GroupModel;

export function groupReducer(state: string, action: Action) {
    console.log(action);
    switch (action.type) {
        case Actions.NEW_ACTION:
            return newState(state, action.payload);
            // return defaultGroupState;
        case Actions.EDIT_ACTION:
            return newState(state, action.payload);
        case Actions.SAVE_ACTION:
            return newState(state, action.payload);
        default:
            return defaultGroupState;
    }
}
