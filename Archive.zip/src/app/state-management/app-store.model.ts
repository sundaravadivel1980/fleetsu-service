export interface PostModel {
    marketLegOrOD: string;
    //  other: any;
}

export interface AppState {
    post: PostModel;
}

export interface Group {
    group: GroupModel;
}

export interface GroupModel {
    actionType: 'new' | 'edit';
    id?: string;
    gid?: number;
    version?: number;
    status?: string;
    time?: string;
    bame?: string;
    type: string;
    userId?: string;
    keyword?: string;
}
