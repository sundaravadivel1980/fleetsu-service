import { Injectable } from '@angular/core';
import { AbstractControl } from '@angular/forms/src/model';
import { Validators } from '@angular/forms';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { RsStandardPayload } from '@dxc/tr-ux-ace-services';

@Injectable()
export class MessageTranslationService {

    /** The consolidated errors. This will be displayed only when user use the addError and showConsolidatedErrors */
    private consolidatedErrorList: string[] = [];

    constructor(public messageService: MessageService, public translateService: TranslateService) {
        // empty const
    }

    /**
     * Will add the translated error message to the list. This error will not be displayed immediately
     * The errors will be displayed when showErrorList method is called.
     *
     * @param errorKey
     */
    public addError(errorKey: string) {
        this.translateService.get(errorKey).subscribe(
            translatedText => {
                this.consolidatedErrorList.push(translatedText);
        });
    }

    public addErrorWithParam(errorKey: string, param: string) {
        this.translateService.get(errorKey, {value: param}).subscribe(
            translatedText => {
                this.consolidatedErrorList.push(translatedText);
        });
    }

    public addRequiredConditionError(param: string) {
        this.translateService.get('acegui.rules.messages.required.component', {value1: param}).subscribe(
            translatedText => {
                this.consolidatedErrorList.push(translatedText);
        });
    }

    /**
     * System failure error
     * @param response
     */
    public httpError(response: HttpErrorResponse) {
        this.messageService.error('NOT ABLE TO CONNECT TO THE SERVICE -- ' + response.error.target.__zone_symbol__xhrURL);
    }

    public serviceError(serviceURL: string, payload: RsStandardPayload) {
        if (payload.success === false && payload.errors && payload.errors.error.length > 0) {
            payload.errors.error.forEach((error) => {
                if (error.code) {
                    this.messageService.error('APPLICATION ERROR -- '  + serviceURL + ' -  ' + error.code + ' - ' + error.message);
                } else {
                    this.messageService.error('APPLICATION ERROR -- ' + serviceURL + ' -  ' + error.message );
                }
            });
        }
    }

    public success(message: string, keepAfterRouteChange = false) {
        this.messageService.success(message, keepAfterRouteChange);
    }

    public successKey(key: string, keepAfterRouteChange = false) {
        this.translateService.get(key).subscribe(
            translatedText => {
                this.messageService.success(translatedText, keepAfterRouteChange);
        });
    }

    public error(message: string, keepAfterRouteChange = false) {
        this.messageService.error(message, keepAfterRouteChange);
    }

    public errorKey(key: string, keepAfterRouteChange = false) {
        this.translateService.get(key).subscribe(
            translatedText => {
                this.messageService.error(translatedText, keepAfterRouteChange);
        });
    }

    public info(message: string, keepAfterRouteChange = false) {
        this.messageService.info(message, keepAfterRouteChange);
    }

    public warn(message: string, keepAfterRouteChange = false) {
        this.messageService.warn(message, keepAfterRouteChange);
    }

    public hasConsolidatedErrors() {
        return this.consolidatedErrorList.length > 0;
    }

    public clearConsolidatedErrors() {
        this.consolidatedErrorList = [];
    }

    public clear() {
        // clear the red messages
        this.messageService.clear();
    }

    public showConsolidatedErrors() {
        this.messageService.clear();

        for (const errorMsg of this.consolidatedErrorList) {
            this.messageService.error(errorMsg);
        }

        this.consolidatedErrorList = [];
    }

    public getTranslatedMsg(key: string) {
        // need to write logic
    }
}
