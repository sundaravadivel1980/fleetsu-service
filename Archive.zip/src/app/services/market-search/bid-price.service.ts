import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { baseFareConstants } from '../../app.constants';
import { BaseFareInfo } from '../../services/market-search/marketsearch-params.model';

@Injectable()
export class BidPriceService {
    private BID_PRICE_JSON_URL: string = 'http://localhost:9080/api/bidprices/';
    // private BID_PRICE_JSON_URL: string =
    // '../../../../assets/jsons/bid-price.json';
    constructor(private http: HttpClient) { }

    public getBidPriceDetails(args) {
        const params = args.params;
        return this.http.get(this.BID_PRICE_JSON_URL + args.url, {params});
    }

    public generateUrlAndRequest(args) {
        const returnParams = { url: '', params: new HttpParams()};
        const date = new Date(args.departuredate);
        const month = date.getMonth().toString().length === 1 ? ('0' + (date.getMonth() + 1)) : date.getMonth();
        const day = date.getDate().toString().length === 1 ? ('0' + date.getDate()) : date.getDate();
        const newDate = date.getFullYear() + '-' + month + '-' + day;
        const flightNumber = args.flightNumber.length === 4 ? args.flightNumber : ('0' + args.flightNumber);
        returnParams.url = `${args.fltOptCarrier}/${flightNumber}/${newDate}/${args.origin}/${args.destination}`;
        return returnParams;
    }

    public getBidPriceReport(respLeft, respRight) {
        // let bidPriceTabList = [];
        let bidPriceTabs = this.getDataForView(respLeft, respRight);
        for (const bid in bidPriceTabs) {
            if (bid) {
                bidPriceTabs[bid].leftCabins = Object.keys(bidPriceTabs[bid].leftCabins).map(function(personNamedIndex){
                    const person = bidPriceTabs[bid].leftCabins[personNamedIndex];
                    return person;
                });
            }
        }
        bidPriceTabs = Object.keys(bidPriceTabs).map((k) => bidPriceTabs[k]);
        return bidPriceTabs;
    }

    private getDataForView(response4Left, response4Right) {
        const tabs = {};
        if (!response4Left.bidprices.length) {
            response4Left.bidprices = [response4Left.bidprices];
        }
        for (const bidPrice of response4Left.bidprices) {
            const key = bidPrice.legboardpoint + bidPrice.legoffpoint;
            if (!tabs[key]) {
                tabs[key] = {};
                tabs[key].leftCabins = {};

                tabs[key].origin = bidPrice.legboardpoint;
                tabs[key].destination = bidPrice.legoffpoint;
                tabs[key].flightNo = bidPrice.flightnumber;
                tabs[key].carrier = bidPrice.carrier;
            }
            for (const cabin of bidPrice.cabins) {
                cabin.showAll = false;
                cabin.revdsp = Number(cabin.revdsp);
                cabin.revcarrycost = Number(cabin.revcarrycost);
                cabin.maxcap = Number(cabin.maxcap);
                cabin.rewarddsp = Number(cabin.rewarddsp);
                cabin.rewardcarrycost = Number(cabin.rewardcarrycost);
                for (const cabinbidprice of cabin.cabinbidprices) {
                    cabinbidprice.bpgsa = Number(cabinbidprice.bpgsa);
                    cabinbidprice.cbp = Number(cabinbidprice.cbp);
                    cabinbidprice.lbp = Number(cabinbidprice.lbp);
                    cabinbidprice.obp = Number(cabinbidprice.obp);
                    cabinbidprice.rbp = Number(cabinbidprice.rbp);
                }
            }
            Object.assign(tabs[key].leftCabins, bidPrice.cabins);
        }
        return tabs;
    }
}
