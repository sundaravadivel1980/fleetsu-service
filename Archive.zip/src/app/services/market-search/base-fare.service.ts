import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { baseFareConstants } from '../../app.constants';
import { BaseFareInfo } from '../../services/market-search/marketsearch-params.model';

@Injectable()
export class BaseFareService {
    private BASE_FARE_JSON_URL: string = 'http://localhost:9080/api/basefares/';
    // private BASE_FARE_JSON_URL: string =
    //     '../../../../assets/jsons/base-fare.json';
    constructor(private http: HttpClient) { }

    public getBaseFareDetails(args) {
        const params = args.params;
        return this.http.get(this.BASE_FARE_JSON_URL + args.url, {params});
    }

    public generateUrlAndRequest(args) {
        const returnParams = { url: '', params: new HttpParams()};
        const date = new Date(args.departuredate);
        const month = date.getMonth().toString().length === 1 ? ('0' + (date.getMonth() + 1)) : date.getMonth();
        const day = date.getDate().toString().length === 1 ? ('0' + date.getDate()) : date.getDate();
        const newDate = date.getFullYear() + '-' + month + '-' + day;
        returnParams.url = `${args.fltOptCarrier}/${args.origin}/${args.destination}/${newDate}`;
        returnParams.params = new HttpParams()
        .set('POSCountry', args.countryCode ? args.countryCode : 'us');
        if (args.firstconnect) {
            returnParams.params = returnParams.params.set('Connection1', args.firstconnect);
        }
        if (args.secondconnect) {
            returnParams.params = returnParams.params.set('Connection2', args.secondconnect);
        }
        return returnParams;
    }

    public generateResponse(args) {
        if (args.length === undefined) {
            const temp = [];
            temp.push(args);
            args = temp;
        }
        args.basefareInfo = [];
        args.firstClass = [];
        args.businessClass = [];
        args.economyClass = [];

        const tmpfirstClass = [];
        const tmpbusinessClass = [];
        const tmpeconomyClass = [];
        for (let i = 0; i < args.length; i++) {
            const basefareInfo = new BaseFareInfo();
            basefareInfo.origin = args[i].origin;
            basefareInfo.destination = args[i].destination;
            basefareInfo.bftOrigin = args[i].bft_origin;
            basefareInfo.bftDestination = args[i].bft_destination;
            basefareInfo.firstconnect = args[i].firstconnectpoint;
            basefareInfo.secondconnect = args[i].secondconnectpoint;
            basefareInfo.departuredate = args[i].departuredate;
            basefareInfo.effStartDate = args[i].bft_eff_date;
            basefareInfo.effEndDate = args[i].bft_disc_date;
            basefareInfo.dayOfWeek = this.formatData(args[i].bft_daysofweek);
            basefareInfo.countryCode = args[i].country;
            basefareInfo.matchedCuntryCode = args[i].bft_country;
            args.basefareInfo.push(basefareInfo);
            for (const j of args[i].basefares) {
                const bfClass = j;
                bfClass.class = bfClass.class.toUpperCase();

                if (baseFareConstants.threeCabinFirstClassList.indexOf(bfClass.class) > -1) {
                    this.processBaseFareList(bfClass, tmpfirstClass, i, baseFareConstants.threeCabinFirstClassList.indexOf(bfClass.class));

                } else if (baseFareConstants.threeCabinBusinessClassList.indexOf(bfClass.class) > -1) {
                    this.processBaseFareList(bfClass, tmpbusinessClass, i, baseFareConstants.threeCabinBusinessClassList.indexOf(bfClass.class));

                } else if (baseFareConstants.threeCabinEconClassList.indexOf(bfClass.class) > -1) {
                    this.processBaseFareList(bfClass, tmpeconomyClass, i, baseFareConstants.threeCabinEconClassList.indexOf(bfClass.class));
                }
            }
        }

        args.firstClass = tmpfirstClass;
        args.businessClass = tmpbusinessClass;
        args.economyClass = tmpeconomyClass;
        return args;

    }

    private processBaseFareList(bfClass, classList, index, order) {
        const aClass = this.getExistingClass(bfClass, classList);
        const bfValue = {
            changedFlag: false,
            value: []
        };
        bfValue.changedFlag = false;
        bfValue.value = bfClass.value;
        if (aClass !== null) {
            aClass.value[index] = bfValue;
        } else {
            const newClass = {
                class: '',
                order: '',
                value: [],
            };
            newClass.class = bfClass.class;
            newClass.order = order;
            newClass.value[index] = bfValue;
            classList.push(newClass);
        }
    }

    private getExistingClass(bfClass, fbList) {
        for (const i of fbList) {
            if (i.class === bfClass.class) {
                return i;
            }
        }
        return null;
    }
    private formatData(daysOfWeek) {
        let strTemp = '';
        for (let i = 0; i < daysOfWeek.length; i++) {
            if (daysOfWeek[i] !== '-' && i < 7) {
                strTemp += baseFareConstants.weekList[daysOfWeek[i]] + ' ';
            }
        }
        return strTemp;
    }
}
