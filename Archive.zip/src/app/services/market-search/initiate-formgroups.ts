import { Injectable } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

@Injectable()
export class InitiateFormGroups {
    constructor(public fb: FormBuilder) {
        // empty
    }

    public initSearchBar() {
        return this.fb.group({
            marketReward: true,
            marketOrgin: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDestination: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDepDate: '',
            depStartTime: '',
            depEndTime: '',
            fltOptConnection1: '',
            fltOptConnection2: '',
            fltOptFlightNumber: '',
            fltOptCarrier: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
            posCountry: '',
            posAirport: '',
            posIataCode: '',
            posGds: '',
            comparePos: false,
            comparePosCountry: '',
            comparePosAirport: '',
            comparePosIataCode: '',
            comparePosGds: '',
        });
    }

    public initBidPrice() {
        return this.fb.group({
            marketOrgin: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDestination: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDepDate: ['', Validators.required],
            fltOptFlightNumber: ['', Validators.required],
            fltOptCarrier: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
        });
    }

    public initBaseFare() {
        return this.fb.group({
            marketOrgin: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDestination: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDepDate: '',
            fltOptConnection1: '',
            fltOptConnection2: '',
            countryCode: '',
            fltOptCarrier: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
        });
    }

    public initSeamlessSearch() {
        return this.fb.group({
            edifact: ''
        });
    }

    public initCustomSeamlessSearch() {
        return this.fb.group({
            flightDetails: this.fb.array([this.createFlightDetails()]),
            marketDepDate: '',
            posCountry: '',
            posAirport: '',
            posIataCode: '',
            posGds: '',
            comparePos: true,
            comparePosCountry: '',
            comparePosAirport: '',
            comparePosIataCode: '',
            comparePosGds: 'tx'
        });
    }

    public createFlightDetails() {
        return this.fb.group({
            marketOrgin: ['ord', Validators.compose([Validators.required, Validators.minLength(3)])],
            marketDestination: ['hnl', Validators.compose([Validators.required, Validators.minLength(3)])],
            fltOptFlightNumber: ['219', Validators.compose([Validators.required, Validators.minLength(2)])],
            marketDepDate: new Date(),
        });
    }
 }
