import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable()
export class FullMarketService {
    private FULL_MARKET_SEARCH_JSON_URL: string = '../../../../assets/jsons/seamles.json';
    private GET_SEAMLESS_RESPONSE: string = 'http://localhost:9080/api/availability';
    private FULL_MARKET_SEARCH_JSON_URL1: string = '../../../../assets/jsons/full-market-search-results.json';
    // private FULL_MARKET_SEARCH_JSON_URL: string =
    //     `http://acem.airservices.eds.com:23103/tr-rest-pss-services/availability/`;
    constructor(private http: HttpClient) { }

    public getFullMarketDetails(params): any {
        return this.http.get(this.FULL_MARKET_SEARCH_JSON_URL, { params });
    }
    public getFullMarketDetails1(params): any {
        return this.http.get(this.FULL_MARKET_SEARCH_JSON_URL1, { params });
    }

    public postEdifactRequest(args) {
        return this.http.post(this.GET_SEAMLESS_RESPONSE, JSON.stringify({ edifact: args.edifact }));
    }

    public getDataFromSeamless(seamlessResp) {
        const newODI = [];
        let newSeg = [];
        let seqnumber;
        let preSegmentSeq = 0;
        let segmentSeq = 1;

        for (const travelsegment of seamlessResp[0].travelsegments) {
            seqnumber = parseInt(travelsegment.groupnumber.seqnumber, 10);

            if (seqnumber !== preSegmentSeq) {
                preSegmentSeq = seqnumber;
                newSeg = [];
                newSeg.push(travelsegment);

                const aODI = {
                    origin: '',
                    destination: '',
                    travelsegments: [],
                    segmentSequenceNumber: 0,
                    isError: false

                };
                aODI.origin = seamlessResp.origin;
                aODI.destination = seamlessResp.destination;
                aODI.travelsegments = newSeg;
                aODI.segmentSequenceNumber = segmentSeq++;
                aODI.isError = false;
                if (travelsegment.productdetaillist == null) {
                    aODI.isError = true;
                }
                newODI.push(aODI);
            } else {
                newSeg.push(travelsegment);
                // if (travelsegment.productdetaillist == null) {
                //     markErrorForFlightInGroup(newODI, seqnumber);
                // }
            }
        }
        return newODI;
    }

    public getData(flightData) {
        flightData.ux = {
            orgDests: []
        };

        if (flightData && flightData.OTA_AirAvailRS && flightData.OTA_AirAvailRS.Errors) {
            flightData = { errors: flightData.OTA_AirAvailRS.Errors };
        } else {
            if (flightData && flightData.OTA_AirAvailRS && flightData.OTA_AirAvailRS.OriginDestinationInformation
                && flightData.OTA_AirAvailRS.OriginDestinationInformation.length > 0) {

                flightData.OTA_AirAvailRS.OriginDestinationInformation.forEach(orgDestInfo => {
                    flightData.ux.orgDests.push(orgDestInfo);
                });

            }
            flightData = this.parseFlights(flightData);
        }
        return flightData;
    }

    public generateRequest(parms, isPos): HttpParams {
        const { fullMarket } = parms;
        const fullMarReq: any = {};
        const date = new Date(fullMarket.marketDepDate);
        const newDate = date.getFullYear() + '-' + (date.getMonth() - 1) + '-' + date.getDate();
        let params = new HttpParams()
            .set('maxresponses', '40')
            .set('odi1ddate', newDate)
            .set('odi1dest', fullMarket.marketDestination)
            .set('odi1orig', fullMarket.marketOrgin)
            .set('vendorid', fullMarket.fltOptCarrier);
        if (fullMarket.marketReward) {
            params = params.append('procinfo', 'Reward');
        }
        if (fullMarket.fltOptConnection1 !== null &&
            fullMarket.fltOptConnection1.length) {
            params = params.append('odi1loc1code', fullMarket.fltOptConnection1)
                .append('odi1loc1minctime', '30')
                .append('odi1loc1ctype', 'Interline');
        }
        if (fullMarket.fltOptConnection2 !== null &&
            fullMarket.fltOptConnection2.length) {
            params = params.append('odi1loc2code', fullMarket.fltOptConnection1)
                .append('odi1loc2minctime', '30')
                .append('odi1loc2ctype', 'Interline');
        }
        if (isPos) {
            if (fullMarket.comparePosCountry) {
                params = params.append('posisocountry', fullMarket.comparePosCountry);
            }
            if (fullMarket.comparePosAirport) {
                params = params.append('pospseudocitycode', fullMarket.comparePosAirport);
            }
            if (fullMarket.comparePosIataCode) {
                params = params.append('posrequestorid', fullMarket.comparePosIataCode);
            }
            if (fullMarket.comparePosGds) {
                params = params.append('poscompanycode', fullMarket.comparePosGds);
            }
        } else {
            fullMarket.posCountry = fullMarket.posCountry ? fullMarket.posCountry : 'US';
            fullMarket.posAirport = fullMarket.posAirport ? fullMarket.posAirport : 'IAH';
            fullMarket.posGds = fullMarket.posGds ? fullMarket.posGds : 'UA'; // Need to get from carrier
            params = params.append('posisocountry', fullMarket.posCountry)
                .append('pospseudocitycode', fullMarket.posAirport)
                .append('poscompanycode', fullMarket.posGds);
            if (fullMarket.posIataCode) {
                params = params.append('posrequestorid', 'fullMarket.posIataCode');
            }
        }
        return params;
    }

    public classifyCabinClass(avlData) {
        const flights = {
            flightList: [],
        };
        for (const avl of avlData) {
            for (const fs of avl.travelsegments) {
                const flight: any = {};
                flight.flightNumber = fs.flightdetail.flightnumber;
                flight.eqp = flight.flightNumber;
                flight.from = fs.boardpoint.location.toUpperCase();
                flight.to = fs.offpoint.location.toUpperCase();
                flight.marketingAirlineCode = fs.company.companyid.toUpperCase();
                // flight.stops = srcModel.StopQuantity;
                flight.departureDateTime = fs.arrdeptimes.depdate + 'T' + fs.arrdeptimes.deptime;
                flight.arrivalDateTime = fs.arrdeptimes.arrdate + 'T' + fs.arrdeptimes.arrtime;
                flight.bookingClassList = fs.productdetaillist ? fs.productdetaillist.productdetails : null;
                flight.firstClass = [];
                flight.economyClass = [];
                let isFirstClass = true;
                fs.economyClass = [];
                fs.error = null;
                if (fs.productdetaillist == null) {
                    console.error('errrorrr');
                } else {
                    for (const bkClass of fs.productdetaillist.productdetails) {
                        if (bkClass.bookingclass.toUpperCase() === 'Y') {
                            isFirstClass = false;
                        }
                        bkClass.bookingclass = bkClass.bookingclass.toUpperCase();
                        bkClass.seatsavailable = bkClass.seatsavailable;
                        if (isFirstClass) {
                            flight.firstClass.push(bkClass);
                        } else {
                            flight.economyClass.push(bkClass);
                        }
                    }
                    flights.flightList.push({ flight: [flight] });
                }
            }
            return flights;
        }
    }

    private parseFlights(flightData) {
        //  var orgDestOpts = flightData.ux.orgDests.
        const flights: any = {};
        const curOrgDest = flightData.ux.orgDests[0];
        flights.departure = curOrgDest.OriginLocation.LocationCode;
        flights.arrival = curOrgDest.DestinationLocation.LocationCode;
        flights.flightList = [];

        curOrgDest.OriginDestinationOptions.OriginDestinationOption.forEach(orgDestInfo => {
            if (orgDestInfo.FlightSegment.length === 1) {
                const flight: any = {};
                const srcModel = orgDestInfo.FlightSegment[0];
                flight.flightNumber = srcModel.FlightNumber;
                flight.eqp = srcModel.Equipment[0].AirEquipType;
                flight.from = srcModel.DepartureAirport.LocationCode;
                flight.to = srcModel.ArrivalAirport.LocationCode;
                flight.stops = srcModel.StopQuantity;
                flight.departureDateTime = srcModel.DepartureDateTime;
                flight.arrivalDateTime = srcModel.ArrivalDateTime;
                flight.bookingClassList = srcModel.BookingClassAvail;
                flight.firstClass = [];
                flight.economyClass = [];
                let isFirstClass = true;
                srcModel.BookingClassAvail.forEach(bookingclass => {
                    if (bookingclass.ResBookDesigCode === 'Y') {
                        isFirstClass = false;
                    }
                    const avail: any = {};
                    avail.bookingclass = bookingclass.ResBookDesigCode;
                    avail.seatsavailable = bookingclass.ResBookDesigQuantity;
                    if (isFirstClass) {
                        flight.firstClass.push(avail);
                    } else {
                        flight.economyClass.push(avail);
                    }
                });
                flight.marketingAirlineCode = srcModel.MarketingAirline.Code;
                flight.OperatingAirline = srcModel.OperatingAirline;
                flights.flightList.push({ flight: [flight] });
            } else {
                const flightChain = [];
                orgDestInfo.FlightSegment.forEach(curFlightRoute => {
                    const flight: any = {};
                    const srcModel = orgDestInfo.FlightSegment[0];
                    flight.flightNumber = srcModel.FlightNumber;
                    flight.eqp = srcModel.Equipment[0].AirEquipType;
                    flight.from = srcModel.DepartureAirport.LocationCode;
                    flight.to = srcModel.ArrivalAirport.LocationCode;
                    flight.stops = srcModel.StopQuantity;
                    flight.departureDateTime = srcModel.DepartureDateTime;
                    flight.arrivalDateTime = srcModel.ArrivalDateTime;
                    flight.bookingClassList = srcModel.BookingClassAvail;
                    flight.firstClass = [];
                    flight.economyClass = [];
                    let isFirstClass = true;
                    srcModel.BookingClassAvail.forEach(bookingclass => {
                        if (bookingclass.ResBookDesigCode === 'Y') {
                            isFirstClass = false;
                        }
                        const avail: any = {};
                        avail.bookingclass = bookingclass.ResBookDesigCode;
                        avail.seatsavailable = bookingclass.ResBookDesigQuantity;
                        if (isFirstClass) {
                            flight.firstClass.push(avail);
                        } else {
                            flight.economyClass.push(avail);
                        }
                    });
                    flight.marketingAirlineCode = srcModel.MarketingAirline.Code;
                    flight.OperatingAirline = srcModel.OperatingAirline;
                    flights.flightList.push({ flight: [flight] });
                    flightChain.push(flight);
                });
                flights.flightList.push({ flight: flightChain });
            }
        });
        return flights;
    }
}
