export class MarketSearchParams {
    public type: string;
    public fullMarket: FullMarketSearch;
}

export class FullMarketSearch {
    public marketReward: boolean;
    public marketOrgin: string;
    public marketDestination: string;
    public marketDepDate: string;
    public depStartTime: string;
    public depEndTime: string;
    public fltOptConnection1: string;
    public fltOptConnection2: string;
    public fltOptFlightNumber: string;
    public fltOptCarrier: string;
    public posCountry: string;
    public posAirport: string;
    public posIataCode: string;
    public posGds: string;
    public comparePos: boolean;
    public comparePosCountry: string;
    public comparePosAirport: string;
    public comparePosIataCode: string;
    public comparePosGds: string;
}

export class BaseFareInfo {
    public origin: string;
    public destination: string;
    public bftOrigin: string;
    public secondconnect: string;
    public departuredate: string;
    public effStartDate: string;
    public effEndDate: string;
    public firstconnect: string;
    public bftDestination: string;
    public dayOfWeek: string;
    public countryCode: string;
    public matchedCuntryCode: string;
}

export class BaseFareRequestParams {
    public origin: string;
    public destination: string;
    public firstconnect: string;
    public secondconnect: string;
    public departuredate: string;
    public countryCode: string;
    public fltOptCarrier: string;
}

export class BidPriceRequestParams {
    public origin: string;
    public destination: string;
    public departuredate: string;
    public flightNumber: string;
    public fltOptCarrier: string;
}

export class BaseFareUrlAndParams {
    public url: string;
    public params: any;
}

export class Reports {
    public name: string;
    public value: string;
}

export class NavigationTabs {
    public Name: string;
}

export class Flight {
    public firstConnection;
    public secondConnection;
    public flightNumber;
    public carrier: string;
    public carrierName: string;
    public countryCode;
    public boardOn;
    public boardOff;
    public isBoardOn;
    public isBoardOff;
}

export class PriPos {
    public country: string;
    public cityCode;
    public iataCode;
    public gdsCarrier: string;
    public gdsCarrierName;
    public savedGroup;
    public savedGroups;
    public airportCode: string;
    public compare: boolean;
}
