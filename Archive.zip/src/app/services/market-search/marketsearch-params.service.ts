import { Injectable } from '@angular/core';
import { MarketSearchParams } from './marketsearch-params.model';

@Injectable()
export class MarketSearchParamsService {
    public params: any;
    public baseFareParams: any;
    public bidPriceParams: any;
    public seatCalculationParams: SeatCalParams;
    public jsonRequest: any;
}
export class SeatCalParams {
    public leftCabins: any;
    public rightCabins: any;
}
