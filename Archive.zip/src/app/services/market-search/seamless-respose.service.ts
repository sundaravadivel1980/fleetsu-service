import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { JsonReq } from './market-model';

@Injectable()
export class SeamlessAvailabilityService {
    // private GET_ALL_REPORTS_URL: string = '../../../../assets/jsons/all-reports.json';
    private GET_ALL_REPORTS_URL: string = 'http://localhost:9080/api/availability';
    constructor(private http: HttpClient) {
        // empty
    }

    public getAllReports(args: JsonReq) {
        const params = JSON.stringify(args);
        return this.http.post(this.GET_ALL_REPORTS_URL, params);
    }

    public getAvailabilityJsonRequest(ctrlAttrs, isPos) {
        const tvl = [];
        let error = false;
        for (let i = 0; i < ctrlAttrs.flightOptions.length; i++) {
          ctrlAttrs.flightOptions[i].invalidField = undefined;
          const { departureDate } = ctrlAttrs.departWindow[i];
          if (i > 0) {
            if (ctrlAttrs.flightOptions[i - 1].boardOff !== ctrlAttrs.flightOptions[i].boardOn) {
              ctrlAttrs.flightOptions[i].invalidField = 'Board-on must match Board-off point from previous flight leg';
              error = true;
            }
            // let cDate = $filter('date')(new Date(ctrlAttrs.departWindow[i].departureDate), 'yyyy-MM-ddThh:mm');
            // let pDate = $filter('date')(new Date(ctrlAttrs.departWindow[i-1].departureDate), 'yyyy-MM-ddThh:mm');
            const cDate = departureDate.getFullYear() + '-' + departureDate.getDate() +  '-' +
             (departureDate.getMonth() + 1) + 'T' + departureDate.getHours() + ':' + departureDate.getMinutes();
            const pDate = ctrlAttrs.departWindow[i - 1].departureDate.getFullYear() + '-' +
             ctrlAttrs.departWindow[i - 1].departureDate.getDate() +  '-' +
            (ctrlAttrs.departWindow[i - 1].departureDate.getMonth() + 1) + 'T' +
             ctrlAttrs.departWindow[i - 1].departureDate.getHours() + ':' + ctrlAttrs.departWindow[i - 1].departureDate.getMinutes();
            if (cDate < pDate) {
              const text = 'Departure date cannot be earlier than the departure date from previous flight leg';
              ctrlAttrs.flightOptions[i].invalidField =
                ctrlAttrs.flightOptions[i].invalidField ? (ctrlAttrs.flightOptions[i].invalidField + ';  ' + text) : text;
              error = true;
            }
          }
          if (!error) {
            // odi
            const productDatetime = {
                departure: null
            };
            // productDatetime.departure = $filter('date')(new Date(ctrlAttrs.departWindow[i].departureDate), 'yyyy-MM-ddThh:mm');
            productDatetime.departure = departureDate.getFullYear() + '-' + departureDate.getDate() +  '-' +
            (departureDate.getMonth() + 1) + 'T' + departureDate.getHours() + ':' + departureDate.getMinutes();
            const boardLocation = {
              identification: ctrlAttrs.flightOptions[i].boardOn
            };
            const offLocation = {
              identification: ctrlAttrs.flightOptions[i].boardOff
            };
            const companyIdentification = {
              marketing_airline: ctrlAttrs.flightOptions[i].carrier,
              operating_airline: ctrlAttrs.flightOptions[i].carrier
            };
            const productIdentificationDetails = {
              flight: parseInt(ctrlAttrs.flightOptions[i].flightNumber, 10),
              flight_suffix: 'a'
            };
            const groupnumber = { seqnumber : 1};
            const tvl1 = {
              product_datetime: productDatetime,
              board_location: boardLocation,
              off_location: offLocation,
              company_identification: companyIdentification,
              product_identification_details: productIdentificationDetails,
              groupnumber,
              lineitemnumber : i + 1
            };
            tvl.push(tvl1);
          }
        }
        if (error) {
          return;
        }
        const odi = [];
        const odi1 = {
          origin: ctrlAttrs.flightOptions[0].boardOn,
          destination: ctrlAttrs.flightOptions[ctrlAttrs.flightOptions.length - 1].boardOff,
          tvl
        };
        odi.push(odi1);
        const request = {
          sender: '1y',
          recipient: ctrlAttrs.flightOptions[0].carrier,
          org: this.getRequestOrgElement(ctrlAttrs, isPos),
          odi
        };
        return request;
      }

    public getJsonRequestFromSelectedFlight(ctrlAttrs, isPos, trapType) {
        const selectedFlight = ctrlAttrs.selectedFlight;
        if (selectedFlight == null || selectedFlight[0] == null) {
            alert('No flight is selected');
            return null;
        }
        const groupnumber = { seqnumber: 1 };
        // tvl
        const tvl = [];
        let itemNum = 0;
        for (const flight of selectedFlight) {
            const tDate = flight.departureDateTime;
            const productDatetime = {
                departure: tDate.replace('null', '00:00')
            };
            const boardLocation = {
                identification: flight.from
            };
            const offLocation = {
                identification: flight.to
            };
            const companyIdentification = {
                marketing_airline: flight.marketingAirlineCode,
                operating_airline: flight.marketingAirlineCode
            };
            const productIdentificationDetails = {
                flight: parseInt(flight.flightNumber, 10),
                flight_suffix: 'a'
            };

            const atvl = {
                product_datetime: productDatetime,
                board_location: boardLocation,
                off_location: offLocation,
                company_identification: companyIdentification,
                product_identification_details: productIdentificationDetails,
                groupnumber,
                lineitemnumber: 1 + itemNum++
            };
            tvl.push(atvl);
        }
        // odi
        const odi = [];
        const oneodi = {
            origin: selectedFlight[0].from,
            destination: selectedFlight[selectedFlight.length - 1].to,
            tvl
        };
        odi.push(oneodi);
        // traps
        let traps = [];
        switch (trapType) {
            case 'all':
                traps = ['bft', 'bid2', 'compseats', 'bfa'];
                break;
            case 'base':
                traps = ['bft'];
                break;
            case 'bid':
                traps = ['bid2'];
                break;
            case 'seat':
                traps = ['compseats'];
                break;
            default:
        }
       // const receipient = ctrlAttrs.flightOptions[0].carrier ? ctrlAttrs.flightOptions[0].carrier : angular.copy(appConfig.getCarrier());
        const receipient = ctrlAttrs.flightOptions[0].carrier ? ctrlAttrs.flightOptions[0].carrier : 'UA';
        const request = {
            sender: '1y',
            recipient: receipient,
            org: this.getRequestOrgElement(ctrlAttrs, isPos),
            odi,
            traps
        };

        return request;
    }

    private getRequestOrgElement(ctrlAttrs, isPos) {
        // if isPos is false, use defaul location (IAH) and country (US).
        // override gdsCarrier, location, country, and iata when isPos is true and POS field's value is provided.
        let companyId = ctrlAttrs.priPOS.gdsCarrier ? ctrlAttrs.priPOS.gdsCarrier : 'UA';
        if (isPos && ctrlAttrs.secPOS.gdsCarrier !== null && ctrlAttrs.secPOS.gdsCarrier.length > 0) {
          companyId = ctrlAttrs.secPOS.gdsCarrier;
        }
        let iataCode = ctrlAttrs.priPOS.iataCode;
        if (isPos && ctrlAttrs.secPOS.iataCode !== null && ctrlAttrs.secPOS.iataCode.length > 0) {
            iataCode = ctrlAttrs.secPOS.iataCode;
        }
        let country = ctrlAttrs.priPOS.country ? ctrlAttrs.priPOS.country : 'US';
        if (isPos && ctrlAttrs.secPOS.country !== null && ctrlAttrs.secPOS.country.length > 0) {
            country = ctrlAttrs.secPOS.country;
        }
        let airportCode = ctrlAttrs.priPOS.airportCode ? ctrlAttrs.priPOS.airportCode : 'IAH';
        if (isPos && ctrlAttrs.secPOS.airportCode !== null && ctrlAttrs.secPOS.airportCode.length > 0) {
            airportCode = ctrlAttrs.secPOS.airportCode;
        }
        // org
        const deliveringSystemDetails = {
          company_identification: companyId,
          location : 'hdq',
          location_name : '00'
        };
        let deliveringOrinatorDetails = null;
        if (iataCode) {
          deliveringOrinatorDetails = {
            travel_agent_identification: iataCode
          };
        }
        const originatingSystemDetails = {
          company_identification: companyId
        };
        const location = {
          location: airportCode
        };
        const originatorDetails = {
            country,
            currency: 'usd'    // hard code this for now
        };
        const org = {
          delivering_system_details : deliveringSystemDetails,
          delivering_originator_details : deliveringOrinatorDetails !== null ? deliveringOrinatorDetails : undefined,
          location,
          originating_system_details: originatingSystemDetails,
          originator_type_code: 'a',
          originator_details: originatorDetails,
          originator_authority_request_code: 'su'
        };
        return org;
      }
    }
