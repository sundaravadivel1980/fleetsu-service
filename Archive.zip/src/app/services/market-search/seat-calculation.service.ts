import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable()
export class SeatCalculationService {
    private SEAT_CALCULATION_REPORT: string = '../../../../assets/jsons/seamles.json';
    constructor(private http: HttpClient) {

    }
    public getSeatCalculationReport() {
        this.http.get(this.SEAT_CALCULATION_REPORT);
    }

    public getSeatCalculation(resp, side) {
        const tabs = {};
        let key = null;
        for (const seatComp of resp.data.seatcomputation) {
            key = seatComp.origin + seatComp.destination;
            if (!tabs[key]) {
                tabs[key] = {};
                if (side === 'left') {
                tabs[key].classitems = [];
                } else {
                    tabs[key].rightClassItems = [];
                }
                tabs[key].origin = seatComp.origin;
                tabs[key].destination = seatComp.destination;
                tabs[key].flightnumber = seatComp.flightnumber;
            }
            if (side === 'left') {
            tabs[key].classitems.push(seatComp.classitem);
            } else {
                tabs[key].rightClassItems.push(seatComp.classitem);
            }
        }
        return tabs;
    }

    public getFilteredData(classItems, cabinClass) {
        const classItemsFiltered = [];
        for (const ci of classItems) {
            if (ci.class.toLowerCase() === cabinClass.toLowerCase()) {
                classItemsFiltered.push(ci);
            }
        }
        return classItemsFiltered;
    }
}
